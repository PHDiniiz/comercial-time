/**
 * Exemplo simples de uso do módulo @phdiniiz/comercialTime com timezone obrigatório
 */

import { inicializar } from "../dist/index.js";

async function exemploSimples() {
  console.log("🌍 Exemplo de inicialização com timezone obrigatório\n");

  try {
    // Inicializar com timezone do Brasil
    console.log("1️⃣ Inicializando para Brasil (pt-BR):");
    const resultado = await inicializar("America/Sao_Paulo");

    console.log("✅ Sucesso:", resultado.sucesso);
    console.log("🌍 Timezone:", resultado.timezone);
    console.log("🏳️ País:", resultado.pais);
    console.log("📍 Locale:", resultado.locale);
    console.log("🏛️ Capital:", resultado.capital);
    console.log("⏰ CRONJOB iniciado:", resultado.cronJobIniciado);
    console.log("💬 Mensagem:", resultado.mensagem);

    console.log("\n✅ Exemplo concluído com sucesso!");
    console.log("📝 Lembre-se: O timezone é OBRIGATÓRIO para inicializar o módulo");
    console.log("🇧🇷 Padrão pt-BR: America/Sao_Paulo");

  } catch (error) {
    console.error("❌ Erro no exemplo:", error.message);
  }
}

// Executar exemplo
exemploSimples();
