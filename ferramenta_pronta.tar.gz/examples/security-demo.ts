/**
 * Demonstração Prática - Validações de Segurança
 *
 * Este exemplo mostra como funcionam as validações de segurança
 * implementadas no sistema.
 */

import { AdvancedRateLimiter } from "../src/security/advanced-rate-limiter.js";
import { InputValidator } from "../src/security/validators/input.validator.js";

// Função para simular delay
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function demonstrateRateLimiting() {
  console.log("🔒 DEMONSTRAÇÃO: Rate Limiting vs Debounce\n");

  // 1. Rate Limiting (Sliding Window)
  console.log("📊 1. RATE LIMITING (Sliding Window)");
  console.log(
    "   Como funciona: Conta requisições em uma janela de tempo que 'desliza'"
  );
  console.log("   Exemplo: Máximo 3 requisições em 10 segundos\n");

  const rateLimiter = new AdvancedRateLimiter({
    maxRequests: 3, // Máximo 3 requisições
    windowMs: 10000, // Em 10 segundos
    debounceMs: 0, // SEM debounce
    throttleMs: 0, // SEM throttle
  });

  console.log("   Tentando 5 requisições rapidamente:");
  for (let i = 1; i <= 5; i++) {
    const result = rateLimiter.isAllowed("user1");
    console.log(
      `   Requisição ${i}: ${
        result.allowed ? "✅ PERMITIDA" : "❌ BLOQUEADA"
      } (${result.reason || "OK"})`
    );
    await delay(100);
  }

  console.log("\n   ⏳ Aguardando 11 segundos para resetar a janela...");
  await delay(11000);

  console.log("   Tentando novamente após reset:");
  for (let i = 1; i <= 3; i++) {
    const result = rateLimiter.isAllowed("user1");
    console.log(
      `   Requisição ${i}: ${result.allowed ? "✅ PERMITIDA" : "❌ BLOQUEADA"}`
    );
    await delay(100);
  }
}

async function demonstrateDebounce() {
  console.log("\n⏱️ 2. DEBOUNCE (Anti-Repetition)");
  console.log("   Como funciona: Previne requisições muito próximas no tempo");
  console.log("   Exemplo: Máximo 1 requisição por segundo\n");

  const debounceLimiter = new AdvancedRateLimiter({
    maxRequests: 1000, // Limite alto para focar no debounce
    windowMs: 60000, // 1 minuto
    debounceMs: 1000, // 1 segundo de debounce
    throttleMs: 0, // SEM throttle
  });

  console.log("   Tentando 5 requisições com 500ms de intervalo:");
  for (let i = 1; i <= 5; i++) {
    const result = debounceLimiter.isAllowed("user2");
    console.log(
      `   Requisição ${i}: ${
        result.allowed ? "✅ PERMITIDA" : "❌ BLOQUEADA"
      } (${result.reason || "OK"})`
    );
    if (!result.allowed && result.retryAfter) {
      console.log(`      ⏰ Próxima tentativa em: ${result.retryAfter}ms`);
    }
    await delay(500);
  }

  console.log("\n   ⏳ Aguardando 1.5 segundos...");
  await delay(1500);

  console.log("   Tentando após o debounce:");
  const result = debounceLimiter.isAllowed("user2");
  console.log(
    `   Requisição: ${result.allowed ? "✅ PERMITIDA" : "❌ BLOQUEADA"}`
  );
}

async function demonstrateDoSProtection() {
  console.log("\n🛡️ 3. PROTEÇÃO CONTRA DoS");
  console.log("   Como funciona: Múltiplas camadas de proteção\n");

  // Simula diferentes tipos de ataques
  console.log("   🎯 Ataque 1: Spam de requisições (Rate Limiting)");
  const spamProtection = new AdvancedRateLimiter({
    maxRequests: 5,
    windowMs: 60000,
    debounceMs: 100,
    throttleMs: 50,
  });

  console.log("   Tentando 10 requisições em 1 segundo:");
  for (let i = 1; i <= 10; i++) {
    const result = spamProtection.isAllowed("attacker");
    console.log(
      `   ${i}: ${result.allowed ? "✅" : "❌"} ${result.reason || "OK"}`
    );
    await delay(100);
  }

  console.log("\n   🎯 Ataque 2: Entrada maliciosa (Input Validation)");
  const maliciousInputs = [
    "08:00<script>alert('xss')</script>",
    "12:30'; DROP TABLE users; --",
    "15:45&malicious=1",
    "09:00",
    "25:00", // Hora inválida
  ];

  console.log("   Testando entradas maliciosas:");
  for (const input of maliciousInputs) {
    const isValid = InputValidator.validateHorarioInput(input);
    console.log(`   "${input}": ${isValid ? "✅ VÁLIDA" : "❌ BLOQUEADA"}`);
  }

  console.log("\n   🎯 Ataque 3: Circuit Breaker (Proteção contra falhas)");
  const circuitBreaker = new AdvancedRateLimiter({
    maxRequests: 100,
    windowMs: 60000,
    debounceMs: 0,
    throttleMs: 0,
    circuitBreakerThreshold: 3,
    circuitBreakerTimeout: 5000,
  });

  console.log("   Simulando falhas consecutivas:");
  for (let i = 1; i <= 5; i++) {
    circuitBreaker.recordFailure("service");
    const result = circuitBreaker.isAllowed("service");
    console.log(
      `   Falha ${i}: ${result.allowed ? "✅ PERMITIDA" : "❌ BLOQUEADA"} (${
        result.reason || "OK"
      })`
    );
  }
}

async function demonstrateInputValidation() {
  console.log("\n🔍 4. VALIDAÇÃO DE ENTRADA");
  console.log("   Como funciona: Verifica e sanitiza dados de entrada\n");

  const testCases = [
    {
      type: "Horário",
      input: "14:30",
      validator: InputValidator.validateHorarioInput,
    },
    {
      type: "Horário",
      input: "25:00",
      validator: InputValidator.validateHorarioInput,
    },
    {
      type: "Horário",
      input: "12:60",
      validator: InputValidator.validateHorarioInput,
    },
    {
      type: "Horário",
      input: "08:00<script>",
      validator: InputValidator.validateHorarioInput,
    },
    {
      type: "Dia",
      input: "segunda-feira",
      validator: InputValidator.validateDiaInput,
    },
    {
      type: "Dia",
      input: "monday<script>",
      validator: InputValidator.validateDiaInput,
    },
    {
      type: "Data",
      input: "2024-01-08",
      validator: InputValidator.validateDateInput,
    },
    {
      type: "Data",
      input: "1800-01-01",
      validator: InputValidator.validateDateInput,
    },
    {
      type: "Data",
      input: "invalid-date",
      validator: InputValidator.validateDateInput,
    },
  ];

  console.log("   Testando validações:");
  for (const test of testCases) {
    const isValid = test.validator(test.input);
    console.log(
      `   ${test.type} "${test.input}": ${
        isValid ? "✅ VÁLIDA" : "❌ BLOQUEADA"
      }`
    );
  }
}

async function main() {
  console.log("🚀 DEMONSTRAÇÃO COMPLETA DE VALIDAÇÕES DE SEGURANÇA\n");
  console.log("=" * 60);

  await demonstrateRateLimiting();
  await demonstrateDebounce();
  await demonstrateDoSProtection();
  await demonstrateInputValidation();

  console.log("\n" + "=" * 60);
  console.log("✅ Demonstração concluída!");
  console.log("\n📋 RESUMO DAS PROTEÇÕES:");
  console.log("   • Rate Limiting: Controla volume de requisições");
  console.log("   • Debounce: Previne requisições muito frequentes");
  console.log("   • Input Validation: Bloqueia entradas maliciosas");
  console.log("   • Circuit Breaker: Protege contra falhas em cascata");
  console.log("   • DoS Prevention: Combinação de todas as proteções");
}

// Executa a demonstração
if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch(console.error);
}

export { main as demonstrateSecurity };
