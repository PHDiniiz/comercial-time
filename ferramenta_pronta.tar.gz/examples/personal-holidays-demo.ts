/**
 * Exemplo de uso de feriados personalizados
 *
 * Este exemplo demonstra como usar a variável de ambiente
 * PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON para definir feriados personalizados.
 */

import {
  incluir,
  feriadosPersonalizadosDisponiveis,
  obterInfoFeriadosPersonalizados,
} from "../src/index.js";

// Configurar variável de ambiente com feriados personalizados
process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON = JSON.stringify([
  {
    nome: "Dia da Empresa",
    data: "2025-03-15",
    observacoes: "Aniversário da nossa empresa - feriado corporativo.",
  },
  {
    nome: "Dia do Desenvolvedor",
    data: "2025-09-13",
    observacoes: "Celebração do dia do programador - feriado técnico.",
  },
  {
    nome: "Black Friday Personalizada",
    data: "2025-11-28",
    observacoes: "Nossa própria Black Friday - feriado comercial.",
  },
]);

console.log("=== DEMONSTRAÇÃO DE FERIADOS PERSONALIZADOS ===\n");

// Verificar se há feriados personalizados disponíveis
const disponivel = feriadosPersonalizadosDisponiveis();
console.log("Feriados personalizados disponíveis:", disponivel);

if (disponivel) {
  // Obter informações sobre os feriados personalizados
  const info = obterInfoFeriadosPersonalizados();
  console.log("Informações dos feriados personalizados:", info);
  console.log("");

  // Criar instância com feriados personalizados
  const horarioPersonalizado = incluir({ nacionais: true });

  console.log(
    "Localização em uso:",
    horarioPersonalizado.obterLocalizacaoUsada()
  );
  // O método 'usandoFeriadosPersonalizados' é privado e não deve ser acessado diretamente.
  // Utilizando a propriedade pública 'usandoPersonalizados' do método 'obterInfoFeriados' para obter essa informação.
  const infoFeriados = horarioPersonalizado.obterInfoFeriados();
  console.log(
    "Usando feriados personalizados:",
    infoFeriados.usandoPersonalizados
  );
  console.log("");
  const infoDetalhada = horarioPersonalizado.obterInfoFeriados();
  console.log("Informações detalhadas dos feriados:");
  console.log("- Total de feriados:", infoDetalhada.total);
  console.log("- Feriados nacionais:", infoDetalhada.nacionais);
  console.log("- Feriados estaduais:", infoDetalhada.estaduais);
  console.log("- Localização:", infoDetalhada.localizacao);
  console.log("- Usando personalizados:", infoDetalhada.usandoPersonalizados);
  console.log("");

  // Listar todos os feriados
  const feriados = horarioPersonalizado.nacionais();
  console.log("Feriados carregados:");
  feriados.forEach((feriado, index) => {
    console.log(`${index + 1}. ${feriado.nome} - ${feriado.data}`);
    console.log(`   ${feriado.observacoes}`);
  });
  console.log("");

  // Criar horário comercial
  const horario = horarioPersonalizado.criarHorarioComercial({
    segunda: { abertura: "08:00", fechamento: "18:00" },
    terca: { abertura: "08:00", fechamento: "18:00" },
    quarta: { abertura: "08:00", fechamento: "18:00" },
    quinta: { abertura: "08:00", fechamento: "18:00" },
    sexta: { abertura: "08:00", fechamento: "18:00" },
  });

  // Verificar se está aberto em uma data específica
  const dataEmpresa = "2025-03-15";
  const estaAberto = horario.estaAberto(dataEmpresa);
  console.log(`Está aberto no dia da empresa (${dataEmpresa})?`, estaAberto);

  // Verificação segura e tipada para existência do método 'obterFeriadoPorData'
  // Utiliza abordagem TypeScript para evitar erro de propriedade inexistente
  type HorarioComercialComFeriado = typeof horario & {
    obterFeriadoPorData?: (data: string) => { nome: string; observacoes?: string } | undefined;
  };

  const horarioComFeriado = horario as HorarioComercialComFeriado;

  if (typeof horarioComFeriado.obterFeriadoPorData === "function") {
    const feriadoEmpresa = horarioComFeriado.obterFeriadoPorData(dataEmpresa);
    if (feriadoEmpresa) {
      console.log(`Feriado encontrado: ${feriadoEmpresa.nome}`);
      console.log(`Observações: ${feriadoEmpresa.observacoes}`);
    } else {
      console.log("Nenhum feriado encontrado para a data informada.");
    }
  } else {
    console.warn("Método 'obterFeriadoPorData' não está disponível na instância de HorarioComercial.");
  }
} else {
  console.log("Nenhum feriado personalizado encontrado.");
  console.log(
    "Defina a variável PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON para usar feriados personalizados."
  );
}

console.log("\n=== COMPARAÇÃO COM FERIADOS PADRÃO ===\n");

// Limpar variável de ambiente para demonstrar fallback
delete process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON;

// Criar instância sem feriados personalizados
const horarioPadrao = incluir({ nacionais: true });
console.log(
  "Localização em uso (sem personalizados):",
  horarioPadrao.obterLocalizacaoUsada()
);
// Como 'usandoFeriadosPersonalizados' é privado, utilize o método público 'obterInfoFeriados' para acessar essa informação de forma segura e tipada.
const infoPadrao = horarioPadrao.obterInfoFeriados();
console.log(
  "Usando feriados personalizados:",
  infoPadrao.usandoPersonalizados
);

console.log("Informações dos feriados padrão:");
console.log("- Total de feriados:", infoPadrao.total);
console.log("- Localização:", infoPadrao.localizacao);
console.log("- Usando personalizados:", infoPadrao.usandoPersonalizados);
