/**
 * Exemplo de Demonstração - Rate Limiter com Debounce
 *
 * Este exemplo demonstra como o sistema de rate limiting
 * com debounce funciona na prática.
 */

import { AdvancedRateLimiter } from "../src/security/advanced-rate-limiter.js";
import { RateLimiterManager } from "../src/security/rate-limiter-integration.js";

// Função para simular delay
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// Função para simular requisições
async function simulateRequests(
  limiter: AdvancedRateLimiter,
  identifier: string,
  count: number,
  intervalMs: number = 10
) {
  console.log(
    `\n🔄 Simulando ${count} requisições com intervalo de ${intervalMs}ms...`
  );

  for (let i = 0; i < count; i++) {
    const result = limiter.isAllowed(identifier);

    if (result.allowed) {
      console.log(`✅ Requisição ${i + 1}: PERMITIDA`);
    } else {
      console.log(
        `❌ Requisição ${i + 1}: BLOQUEADA (${result.reason}) - Retry em ${
          result.retryAfter
        }ms`
      );
    }

    await delay(intervalMs);
  }
}

async function demonstrateRateLimiting() {
  console.log("🚀 Demonstração do Sistema de Rate Limiting com Debounce\n");

  // 1. Demonstração básica de Rate Limiting
  console.log("📊 1. Rate Limiting Básico (Sliding Window)");
  const basicLimiter = new AdvancedRateLimiter({
    maxRequests: 5,
    windowMs: 10000, // 10 segundos
    debounceMs: 0, // Sem debounce
    throttleMs: 0, // Sem throttle
  });

  await simulateRequests(basicLimiter, "user1", 8, 100);

  // 2. Demonstração de Debounce
  console.log("\n⏱️ 2. Debounce (Prevenção de Operações Muito Frequentes)");
  const debounceLimiter = new AdvancedRateLimiter({
    maxRequests: 100,
    windowMs: 60000,
    debounceMs: 1000, // 1 segundo de debounce
    throttleMs: 0,
  });

  await simulateRequests(debounceLimiter, "user2", 5, 100);

  // 3. Demonstração de Throttle
  console.log("\n🚦 3. Throttle (Suavização de Picos de Tráfego)");
  const throttleLimiter = new AdvancedRateLimiter({
    maxRequests: 100,
    windowMs: 60000,
    debounceMs: 0,
    throttleMs: 500, // 500ms de throttle
  });

  await simulateRequests(throttleLimiter, "user3", 5, 100);

  // 4. Demonstração de Circuit Breaker
  console.log("\n🔌 4. Circuit Breaker (Proteção contra Falhas em Cascata)");
  const circuitLimiter = new AdvancedRateLimiter({
    maxRequests: 100,
    windowMs: 60000,
    debounceMs: 0,
    throttleMs: 0,
    circuitBreakerThreshold: 3,
    circuitBreakerTimeout: 5000,
  });

  // Simula algumas falhas
  for (let i = 0; i < 4; i++) {
    circuitLimiter.recordFailure("user4");
    console.log(`💥 Falha ${i + 1} registrada`);
  }

  // Tenta fazer requisições após as falhas
  await simulateRequests(circuitLimiter, "user4", 3, 100);

  // 5. Demonstração com Rate Limiter Manager
  console.log("\n🎛️ 5. Rate Limiter Manager (Diferentes Cenários)");
  const manager = new RateLimiterManager();

  // Testa diferentes tipos de operação
  const operations = [
    { type: "horario", user: "user5", count: 3 },
    { type: "validacao", user: "user6", count: 3 },
    { type: "admin", user: "user7", count: 3 },
  ];

  for (const op of operations) {
    console.log(`\n📋 Testando operações ${op.type} para ${op.user}:`);

    for (let i = 0; i < op.count; i++) {
      const result = manager[
        `check${
          op.type.charAt(0).toUpperCase() + op.type.slice(1)
        }` as keyof RateLimiterManager
      ](op.user);

      if (result.allowed) {
        console.log(`✅ Operação ${i + 1}: PERMITIDA`);
      } else {
        console.log(`❌ Operação ${i + 1}: BLOQUEADA (${result.reason})`);
      }

      await delay(100);
    }
  }

  // 6. Estatísticas finais
  console.log("\n📈 6. Estatísticas Finais");
  const stats = manager.getGlobalStats();
  console.log("Estatísticas globais:", JSON.stringify(stats, null, 2));

  console.log("\n✅ Demonstração concluída!");
}

// Executa a demonstração se este arquivo for executado diretamente
if (import.meta.url === `file://${process.argv[1]}`) {
  demonstrateRateLimiting().catch(console.error);
}

export { demonstrateRateLimiting };
