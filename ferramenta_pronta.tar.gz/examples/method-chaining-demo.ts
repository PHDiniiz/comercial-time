/**
 * Demonstração - Method Chaining com setTimezone
 *
 * Este exemplo demonstra como usar o method chaining
 * para configurar timezone diretamente na instância.
 */

import { HorarioComercial } from "../dist/index.js";

async function demonstrateMethodChaining() {
  console.log("🚀 Demonstração do Method Chaining com setTimezone\n");

  // 1. Method Chaining Básico
  console.log("🔗 1. Method Chaining Básico");
  const horario = new HorarioComercial({
    segunda: { abertura: "08:00", fechamento: "18:00" },
    terca: { abertura: "08:00", fechamento: "18:00" },
    quarta: { abertura: "08:00", fechamento: "18:00" },
    quinta: { abertura: "08:00", fechamento: "18:00" },
    sexta: { abertura: "08:00", fechamento: "18:00" },
  }).setTimezone("America/Sao_Paulo");

  console.log(`   Timezone configurado: ${horario.getTimezone()}`);
  console.log(
    `   Status atual: ${horario.openedNow ? "🟢 ABERTO" : "🔴 FECHADO"}\n`
  );

  // 2. Múltiplas Instâncias com Diferentes Timezones
  console.log("🌍 2. Múltiplas Instâncias com Diferentes Timezones");

  const horarios = [
    {
      nome: "Brasil",
      timezone: "America/Sao_Paulo",
      horario: new HorarioComercial({
        segunda: { abertura: "08:00", fechamento: "18:00" },
        terca: { abertura: "08:00", fechamento: "18:00" },
        quarta: { abertura: "08:00", fechamento: "18:00" },
        quinta: { abertura: "08:00", fechamento: "18:00" },
        sexta: { abertura: "08:00", fechamento: "18:00" },
      }).setTimezone("America/Sao_Paulo"),
    },
    {
      nome: "EUA (Nova York)",
      timezone: "America/New_York",
      horario: new HorarioComercial({
        segunda: { abertura: "09:00", fechamento: "17:00" },
        terca: { abertura: "09:00", fechamento: "17:00" },
        quarta: { abertura: "09:00", fechamento: "17:00" },
        quinta: { abertura: "09:00", fechamento: "17:00" },
        sexta: { abertura: "09:00", fechamento: "17:00" },
      }).setTimezone("America/New_York"),
    },
    {
      nome: "Reino Unido",
      timezone: "Europe/London",
      horario: new HorarioComercial({
        segunda: { abertura: "09:00", fechamento: "17:30" },
        terca: { abertura: "09:00", fechamento: "17:30" },
        quarta: { abertura: "09:00", fechamento: "17:30" },
        quinta: { abertura: "09:00", fechamento: "17:30" },
        sexta: { abertura: "09:00", fechamento: "17:30" },
      }).setTimezone("Europe/London"),
    },
    {
      nome: "Japão",
      timezone: "Asia/Tokyo",
      horario: new HorarioComercial({
        segunda: { abertura: "09:00", fechamento: "18:00" },
        terca: { abertura: "09:00", fechamento: "18:00" },
        quarta: { abertura: "09:00", fechamento: "18:00" },
        quinta: { abertura: "09:00", fechamento: "18:00" },
        sexta: { abertura: "09:00", fechamento: "18:00" },
      }).setTimezone("Asia/Tokyo"),
    },
  ];

  for (const { nome, timezone, horario: h } of horarios) {
    console.log(`   ${nome} (${timezone}):`);
    console.log(`     Timezone: ${h.getTimezone()}`);
    console.log(`     Status: ${h.openedNow ? "🟢 ABERTO" : "🔴 FECHADO"}`);
    console.log(
      `     Próxima abertura: ${
        h.proximaAbertura()?.toLocaleString("pt-BR") || "N/A"
      }`
    );
  }

  // 3. Method Chaining Avançado
  console.log("\n🔗 3. Method Chaining Avançado");

  const horarioAvancado = new HorarioComercial({
    segunda: { abertura: "08:00", fechamento: "18:00" },
    terca: { abertura: "08:00", fechamento: "18:00" },
    quarta: { abertura: "08:00", fechamento: "18:00" },
    quinta: { abertura: "08:00", fechamento: "18:00" },
    sexta: { abertura: "08:00", fechamento: "18:00" },
    sabado: { abertura: "09:00", fechamento: "13:00" },
  }).setTimezone("America/Sao_Paulo");

  // Verificar status em diferentes momentos
  const agora = new Date();
  const em2Horas = horarioAvancado.adicionarMinutosUteis(agora, 120);
  const em1Dia = horarioAvancado.adicionarMinutosUteis(agora, 480); // 8 horas

  console.log(`   Agora: ${agora.toLocaleString("pt-BR")}`);
  console.log(
    `   Status atual: ${horarioAvancado.openedNow ? "🟢 ABERTO" : "🔴 FECHADO"}`
  );
  console.log(`   Em 2 horas: ${em2Horas.toLocaleString("pt-BR")}`);
  console.log(`   Em 1 dia útil: ${em1Dia.toLocaleString("pt-BR")}`);

  // 4. Vantagens do Method Chaining
  console.log("\n💡 4. Vantagens do Method Chaining");
  console.log("   ✅ Código mais limpo e legível");
  console.log("   ✅ Configuração em uma única linha");
  console.log("   ✅ Fácil de manter e modificar");
  console.log("   ✅ Suporte a múltiplas instâncias com diferentes timezones");
  console.log("   ✅ Compatível com a API existente");

  // 5. Exemplo de Uso em Aplicação Real
  console.log("\n🏢 5. Exemplo de Uso em Aplicação Real");

  // Simulação de diferentes filiais
  const filiais = [
    {
      nome: "São Paulo",
      horario: new HorarioComercial({
        segunda: { abertura: "08:00", fechamento: "18:00" },
        terca: { abertura: "08:00", fechamento: "18:00" },
        quarta: { abertura: "08:00", fechamento: "18:00" },
        quinta: { abertura: "08:00", fechamento: "18:00" },
        sexta: { abertura: "08:00", fechamento: "18:00" },
      }).setTimezone("America/Sao_Paulo"),
    },
    {
      nome: "Nova York",
      horario: new HorarioComercial({
        segunda: { abertura: "09:00", fechamento: "17:00" },
        terca: { abertura: "09:00", fechamento: "17:00" },
        quarta: { abertura: "09:00", fechamento: "17:00" },
        quinta: { abertura: "09:00", fechamento: "17:00" },
        sexta: { abertura: "09:00", fechamento: "17:00" },
      }).setTimezone("America/New_York"),
    },
  ];

  console.log("   Status das filiais:");
  for (const { nome, horario: h } of filiais) {
    const status = h.openedNow ? "🟢 ABERTO" : "🔴 FECHADO";
    const proximaAbertura = h.proximaAbertura();
    const proximaAberturaStr = proximaAbertura
      ? proximaAbertura.toLocaleString("pt-BR")
      : "N/A";

    console.log(`   ${nome}: ${status} (Próxima: ${proximaAberturaStr})`);
  }

  console.log("\n🎉 Demonstração do Method Chaining concluída!");
}

// Executa a demonstração
if (import.meta.url === `file://${process.argv[1]}`) {
  demonstrateMethodChaining().catch(console.error);
}

export { demonstrateMethodChaining };
