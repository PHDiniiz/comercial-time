/**
 * Exemplo de inicialização rápida do módulo @phdiniiz/comercialTime
 * 
 * Este exemplo demonstra como inicializar o módulo de forma rápida
 * sem aguardar a atualização de feriados, ideal para aplicações
 * que precisam de inicialização rápida.
 */

import { inicializarRapido, inicializarCronJobFeriados } from "../dist/index.js";

async function exemploInicializacaoRapida() {
  console.log("⚡ Exemplo de inicialização rápida\n");

  const inicio = Date.now();

  try {
    // Inicialização rápida sem CRONJOB
    console.log("1️⃣ Inicializando módulo rapidamente...");
    const resultado = await inicializarRapido("America/Sao_Paulo");

    const tempoInicializacao = Date.now() - inicio;

    console.log("✅ Sucesso:", resultado.sucesso);
    console.log("🌍 Timezone:", resultado.timezone);
    console.log("🏳️ País:", resultado.pais);
    console.log("⏰ CRONJOB iniciado:", resultado.cronJobIniciado);
    console.log("⏱️ Tempo de inicialização:", tempoInicializacao + "ms");
    console.log("💬 Mensagem:", resultado.mensagem);

    console.log("\n2️⃣ Iniciando CRONJOB em background...");

    // Iniciar CRONJOB em background após a inicialização rápida
    setTimeout(() => {
      inicializarCronJobFeriados();
      console.log("✅ CRONJOB iniciado em background");
    }, 100);

    console.log("\n✅ Aplicação pronta para uso!");
    console.log("📝 CRONJOB será iniciado em background em 100ms");
    console.log("🚀 Inicialização rápida concluída com sucesso!");

  } catch (error) {
    console.error("❌ Erro na inicialização:", error.message);
  }
}

// Executar exemplo
exemploInicializacaoRapida();
