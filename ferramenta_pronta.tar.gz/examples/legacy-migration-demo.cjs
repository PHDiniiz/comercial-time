/**
 * Exemplo de Migração do Código Legado (JavaScript)
 * 
 * Este exemplo demonstra como migrar do código legado para a nova arquitetura
 * modular do ComercialTime.
 */

// Importar usando CommonJS
const {
  HorarioComercialFactory,
  HorarioComercialUseCaseImpl,
  inicializarParaBrasil
} = require("../dist/index.cjs.cjs");

// Configuração de horário comercial
const horarioComercial = {
  "0": { abertura: "09:00", fechamento: "18:00" }, // Domingo
  "1": { abertura: "08:00", fechamento: "18:00" }, // Segunda
  "2": { abertura: "08:00", fechamento: "18:00" }, // Terça
  "3": { abertura: "08:00", fechamento: "18:00" }, // Quarta
  "4": { abertura: "08:00", fechamento: "18:00" }, // Quinta
  "5": { abertura: "08:00", fechamento: "18:00" }, // Sexta
  "6": { abertura: "09:00", fechamento: "17:00" }, // Sábado
};

async function demonstrarMigracao() {
  console.log("🚀 Demonstração de Migração do Código Legado\n");

  try {
    // 1. Inicializar o módulo
    console.log("1️⃣ Inicializando módulo...");
    const inicializacao = await inicializarParaBrasil();
    console.log(`✅ ${inicializacao.mensagem}\n`);

    // 2. Usar a Factory Moderna (Recomendado)
    console.log("2️⃣ Usando HorarioComercialFactory moderna...");
    const factory = HorarioComercialFactory.createParaBrasil(horarioComercial, ["SP", "RJ"]);

    console.log("📊 Informações dos feriados:");
    console.log(factory.obterInfoFeriados());

    console.log("\n🏛️ Estados disponíveis:");
    console.log(factory.obterEstadosDisponiveis());

    console.log("\n⏰ Status atual:");
    console.log(`Está aberto agora: ${factory.horarioComercial.openedNow}`);

    console.log("\n📅 Próxima abertura:");
    const proximaAbertura = factory.horarioComercial.proximaAbertura();
    console.log(proximaAbertura?.toLocaleString("pt-BR"));

    // 3. Usar o Caso de Uso Moderno
    console.log("\n3️⃣ Usando HorarioComercialUseCaseImpl moderno...");
    const useCase = HorarioComercialUseCaseImpl.create(horarioComercial, {
      location: "pt-br",
      nacionais: true,
      estaduais: ["SP"],
      fallbackToPtBr: true,
    });

    console.log("📊 Informações dos feriados (UseCase):");
    console.log(useCase.obterInfoFeriados());

    console.log("\n🏛️ Estados disponíveis (UseCase):");
    console.log(useCase.obterEstadosDisponiveis());

    console.log("\n⏰ Status atual (UseCase):");
    console.log(`Está aberto agora: ${useCase.obterStatusAtual()}`);

    console.log("\n📅 Próxima abertura (UseCase):");
    const proximaAberturaUseCase = useCase.obterProximaAbertura();
    console.log(proximaAberturaUseCase?.toLocaleString("pt-BR"));

    // 4. Usar Factory Simplificada
    console.log("\n4️⃣ Usando Factory simplificada...");
    const factorySimples = HorarioComercialFactory.createSimple(horarioComercial, {
      location: "pt-br",
      nacionais: true,
    });

    console.log("⏰ Status atual (Factory Simples):");
    console.log(`Está aberto agora: ${factorySimples.openedNow}`);

    // 5. Comparar com código legado (para referência)
    console.log("\n5️⃣ Comparação com código legado:");
    console.log("❌ Código legado (não recomendado):");
    console.log("   import { HorarioComercial } from './legacy/horario-comercial.legacy.js';");
    console.log("   const legado = new HorarioComercial(horarioComercial, feriados);");

    console.log("\n✅ Código moderno (recomendado):");
    console.log("   import { HorarioComercialFactory } from './presentation/factories/horario-comercial.factory.js';");
    console.log("   const moderno = HorarioComercialFactory.createParaBrasil(horarioComercial, ['SP']);");

    console.log("\n🎉 Migração concluída com sucesso!");
    console.log("\n📋 Benefícios da nova arquitetura:");
    console.log("   • Sistema modular de importação de feriados");
    console.log("   • Suporte a múltiplos países e localizações");
    console.log("   • Factory pattern para criação de instâncias");
    console.log("   • Casos de uso bem definidos");
    console.log("   • Melhor separação de responsabilidades");
    console.log("   • Tipagem TypeScript mais robusta");

  } catch (error) {
    console.error("❌ Erro durante a demonstração:", error.message);
    console.error("Stack:", error.stack);
  }
}

// Executar demonstração
demonstrarMigracao();
