/**
 * Teste Completo de Migração
 * 
 * Este teste valida que toda a migração do código legado para a nova arquitetura
 * modular está funcionando corretamente.
 */

console.log("🚀 Teste Completo de Migração do Código Legado\n");

// Teste 1: Importar classes modernas
try {
  const { 
    HorarioComercialFactory,
    HorarioComercialUseCaseImpl,
    HorarioComercialControllerImpl,
    inicializarParaBrasil 
  } = require("../dist/index.cjs.cjs");
  
  console.log("✅ 1. Classes modernas importadas com sucesso");
  
  // Teste 2: Inicializar módulo
  async function testarInicializacao() {
    try {
      const inicializacao = await inicializarParaBrasil();
      console.log(`✅ 2. Módulo inicializado: ${inicializacao.mensagem}`);
      return true;
    } catch (error) {
      console.log(`❌ 2. Erro na inicialização: ${error.message}`);
      return false;
    }
  }
  
  // Teste 3: Factory moderna
  function testarFactory() {
    try {
      const horarioComercial = {
        "0": { abertura: "09:00", fechamento: "18:00" },
        "1": { abertura: "08:00", fechamento: "18:00" },
        "2": { abertura: "08:00", fechamento: "18:00" },
        "3": { abertura: "08:00", fechamento: "18:00" },
        "4": { abertura: "08:00", fechamento: "18:00" },
        "5": { abertura: "08:00", fechamento: "18:00" },
        "6": { abertura: "09:00", fechamento: "17:00" },
      };
      
      const factory = HorarioComercialFactory.createParaBrasil(horarioComercial, ["SP"]);
      
      // Testar métodos básicos
      const estaAberto = factory.horarioComercial.estaAberto();
      const proximaAbertura = factory.horarioComercial.proximaAbertura();
      const infoFeriados = factory.obterInfoFeriados();
      const estados = factory.obterEstadosDisponiveis();
      
      console.log("✅ 3. Factory moderna funcionando:");
      console.log(`   - estaAberto(): ${estaAberto}`);
      console.log(`   - proximaAbertura(): ${proximaAbertura?.toLocaleString("pt-BR")}`);
      console.log(`   - infoFeriados: ${infoFeriados.total} feriados carregados`);
      console.log(`   - estados disponíveis: ${estados.length} estados`);
      
      return true;
    } catch (error) {
      console.log(`❌ 3. Erro na factory: ${error.message}`);
      return false;
    }
  }
  
  // Teste 4: Caso de uso moderno
  function testarUseCase() {
    try {
      const horarioComercial = {
        "0": { abertura: "09:00", fechamento: "18:00" },
        "1": { abertura: "08:00", fechamento: "18:00" },
        "2": { abertura: "08:00", fechamento: "18:00" },
        "3": { abertura: "08:00", fechamento: "18:00" },
        "4": { abertura: "08:00", fechamento: "18:00" },
        "5": { abertura: "08:00", fechamento: "18:00" },
        "6": { abertura: "09:00", fechamento: "17:00" },
      };
      
      const useCase = HorarioComercialUseCaseImpl.create(horarioComercial, {
        location: "pt-br",
        nacionais: true,
        estaduais: ["SP"],
      });
      
      // Testar métodos básicos
      const estaAberto = useCase.verificarSeEstaAberto();
      const proximaAbertura = useCase.obterProximaAbertura();
      const infoFeriados = useCase.obterInfoFeriados();
      const feriadosNacionais = useCase.obterFeriadosNacionais();
      const feriadosEstaduais = useCase.obterFeriadosEstaduais("SP");
      
      console.log("✅ 4. UseCase moderno funcionando:");
      console.log(`   - verificarSeEstaAberto(): ${estaAberto}`);
      console.log(`   - obterProximaAbertura(): ${proximaAbertura?.toLocaleString("pt-BR")}`);
      console.log(`   - infoFeriados: ${infoFeriados.total} feriados`);
      console.log(`   - feriados nacionais: ${feriadosNacionais.length}`);
      console.log(`   - feriados estaduais SP: ${feriadosEstaduais.length}`);
      
      return true;
    } catch (error) {
      console.log(`❌ 4. Erro no useCase: ${error.message}`);
      return false;
    }
  }
  
  // Teste 5: Controller moderno
  function testarController() {
    try {
      const horarioComercial = {
        "0": { abertura: "09:00", fechamento: "18:00" },
        "1": { abertura: "08:00", fechamento: "18:00" },
        "2": { abertura: "08:00", fechamento: "18:00" },
        "3": { abertura: "08:00", fechamento: "18:00" },
        "4": { abertura: "08:00", fechamento: "18:00" },
        "5": { abertura: "08:00", fechamento: "18:00" },
        "6": { abertura: "09:00", fechamento: "17:00" },
      };
      
      const useCase = HorarioComercialUseCaseImpl.create(horarioComercial, {
        location: "pt-br",
        nacionais: true,
      });
      
      const controller = new HorarioComercialControllerImpl(useCase);
      
      // Testar métodos do controller
      const status = controller.verificarStatus();
      const horario = controller.obterHorario();
      const statusAtual = controller.obterStatusAtual();
      
      console.log("✅ 5. Controller moderno funcionando:");
      console.log(`   - verificarStatus(): ${JSON.stringify(status)}`);
      console.log(`   - obterHorario(): ${Object.keys(horario).length} dias configurados`);
      console.log(`   - obterStatusAtual(): ${statusAtual}`);
      
      return true;
    } catch (error) {
      console.log(`❌ 5. Erro no controller: ${error.message}`);
      return false;
    }
  }
  
  // Teste 6: Compatibilidade com código legado
  function testarCompatibilidade() {
    try {
      const { HorarioComercial } = require("../dist/legacy/horario-comercial.legacy.js");
      
      const horarioComercial = {
        "0": { abertura: "09:00", fechamento: "18:00" },
        "1": { abertura: "08:00", fechamento: "18:00" },
        "2": { abertura: "08:00", fechamento: "18:00" },
        "3": { abertura: "08:00", fechamento: "18:00" },
        "4": { abertura: "08:00", fechamento: "18:00" },
        "5": { abertura: "08:00", fechamento: "18:00" },
        "6": { abertura: "09:00", fechamento: "17:00" },
      };
      
      const legado = new HorarioComercial(horarioComercial, []);
      
      const estaAberto = legado.estaAberto();
      const proximaAbertura = legado.proximaAbertura();
      const statusAtual = legado.openedNow;
      
      console.log("✅ 6. Compatibilidade com código legado:");
      console.log(`   - estaAberto(): ${estaAberto}`);
      console.log(`   - proximaAbertura(): ${proximaAbertura?.toLocaleString("pt-BR")}`);
      console.log(`   - openedNow: ${statusAtual}`);
      
      return true;
    } catch (error) {
      console.log(`❌ 6. Erro na compatibilidade: ${error.message}`);
      return false;
    }
  }
  
  // Executar todos os testes
  async function executarTestes() {
    const resultados = [];
    
    resultados.push(await testarInicializacao());
    resultados.push(testarFactory());
    resultados.push(testarUseCase());
    resultados.push(testarController());
    resultados.push(testarCompatibilidade());
    
    const sucessos = resultados.filter(r => r).length;
    const total = resultados.length;
    
    console.log(`\n📊 Resultado dos Testes: ${sucessos}/${total} passaram`);
    
    if (sucessos === total) {
      console.log("\n🎉 MIGRAÇÃO COMPLETA VALIDADA COM SUCESSO!");
      console.log("\n📋 Resumo da Migração:");
      console.log("   ✅ Sistema modular ComercialTime funcionando");
      console.log("   ✅ HorarioComercialFactory moderna funcionando");
      console.log("   ✅ HorarioComercialUseCase moderno funcionando");
      console.log("   ✅ HorarioComercialController moderno funcionando");
      console.log("   ✅ Compatibilidade com código legado mantida");
      console.log("   ✅ Inicialização do módulo funcionando");
      console.log("   ✅ Suporte a múltiplos países funcionando");
      console.log("   ✅ Sistema de feriados modular funcionando");
      
      console.log("\n🚀 O módulo está pronto para uso com a nova arquitetura!");
    } else {
      console.log("\n❌ Alguns testes falharam. Verifique os erros acima.");
    }
  }
  
  executarTestes().catch(console.error);
  
} catch (error) {
  console.error("❌ Erro crítico na importação:", error.message);
  console.error("Stack:", error.stack);
}
