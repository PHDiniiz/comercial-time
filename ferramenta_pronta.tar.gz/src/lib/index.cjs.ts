/**
 * Barrel exports para a biblioteca de horário comercial (CommonJS)
 */

// Tipos
export type { DiaChave, HoraString, Intervalo, Horario } from "./types.cjs";

// Funções utilitárias
export {
  horaParaMinutos,
  minutosParaHora,
  diaIndex,
  minutosDoDia,
} from "./utils.cjs";

// Funções de normalização
export { normalizarDia, normalizarHorario } from "./normalize.cjs";

// Classe principal
export { HorarioComercial } from "./horario-comercial.cjs";
