/**
 * Tipos para o módulo de horário comercial
 */

/** Tipo que representa uma chave de dia da semana (número ou nome) */
export type DiaChave = number | string; // 0 (domingo) - 6 (sábado) ou nomes 'segunda', 'monday', etc

/** Tipo que representa uma string de hora no formato HH:mm */
export type HoraString = string; // "HH:mm"

/**
 * Interface que representa um feriado com informações completas.
 * Contém nome, data e observações.
 */
export interface Feriado {
  /** Nome do feriado */
  readonly nome: string;
  /** Data do feriado no formato YYYY-MM-DD */
  readonly data: string;
  /** Observações sobre o feriado */
  readonly observacoes: string;
}

/** Tipo que representa um intervalo de horário comercial */
export type Intervalo = {
  /** Horário de abertura no formato HH:mm */
  readonly abertura: HoraString;
  /** Horário de fechamento no formato HH:mm */
  readonly fechamento: HoraString;
};

/** Tipo que representa o horário comercial completo */
export type Horario = Readonly<Record<string, readonly Intervalo[]>>; // chaves dia (string do número) -> intervalos
