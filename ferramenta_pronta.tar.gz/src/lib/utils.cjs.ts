/**
 * Funções utilitárias para manipulação de horários (CommonJS)
 */

import type { HoraString } from "./types.cjs";

const pad2 = (n: number): string => n.toString().padStart(2, "0");

export const horaParaMinutos = (h: HoraString): number => {
  const [hStr, mStr] = h.split(":");
  const hh = Number(hStr ?? 0);
  const mm = Number(mStr ?? 0);
  if (Number.isNaN(hh) || Number.isNaN(mm)) {
    throw new Error(`Formato de hora inválido: ${h}`);
  }
  return hh * 60 + mm;
};

export const minutosParaHora = (mins: number): HoraString => {
  const normalizedMins = ((mins % (24 * 60)) + 24 * 60) % (24 * 60);
  const h = Math.floor(normalizedMins / 60);
  const m = normalizedMins % 60;
  return `${pad2(h)}:${pad2(m)}`;
};

export const diaIndex = (date: Date): number => date.getDay(); // 0-6

export const minutosDoDia = (date: Date): number =>
  date.getHours() * 60 + date.getMinutes();
