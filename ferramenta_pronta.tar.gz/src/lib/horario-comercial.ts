/**
 * Classe principal para gerenciar horários comerciais
 */

import type { DiaChave, Intervalo, Horario, Feriado } from "./types.js";
import { normalizarHorario } from "./normalize.js";
import { horaParaMinutos, diaIndex, minutosDoDia } from "./utils.js";
import {
  carregarFeriados,
  obterDatasFeriados,
} from "../infrastructure/utils/feriados.util.js";

/**
 * Classe principal para gerenciar horários comerciais.
 * Implementa todas as funcionalidades básicas para verificação de horários,
 * cálculo de próximas aberturas/fechamentos e operações com minutos úteis.
 */
export class HorarioComercial {
  readonly #horario: Horario;
  readonly #feriados: readonly Feriado[];
  readonly #feriadosSet: ReadonlySet<string>;

  /**
   * Constrói uma nova instância do HorarioComercial.
   * @param horarioInput - Configuração de horários por dia da semana
   * @param feriados - Array de feriados (opcional, se não fornecido carrega do feriados.json)
   */
  constructor(
    horarioInput: Record<DiaChave, Intervalo[] | Intervalo>,
    feriados?: readonly Feriado[]
  ) {
    this.#horario = normalizarHorario(horarioInput);

    // Carrega feriados do arquivo JSON se não fornecidos
    this.#feriados = feriados || carregarFeriados();

    // Cria um Set para busca rápida de datas
    this.#feriadosSet = new Set(
      obterDatasFeriados(this.#feriados)
    ) as ReadonlySet<string>;
  }

  /**
   * Verifica se uma data é feriado.
   * @param data - Data a ser verificada
   * @returns true se for feriado, false caso contrário
   */
  #ehFeriado = (data: Date): boolean => {
    const iso = data.toISOString().slice(0, 10);
    return this.#feriadosSet.has(iso);
  };

  /**
   * Verifica se o estabelecimento está aberto em uma data específica.
   * @param dt - Data para verificação (padrão: data atual)
   * @returns true se estiver aberto, false caso contrário
   * @throws Error se a data for inválida
   */
  estaAberto = (dt: Date | string = new Date()): boolean => {
    const date = typeof dt === "string" ? new Date(dt) : dt;
    if (Number.isNaN(date.getTime())) {
      throw new Error("Data inválida");
    }
    if (this.#ehFeriado(date)) return false;

    const dia = diaIndex(date);
    const mins = minutosDoDia(date);
    const intervalos = this.#horario[String(dia)] ?? [];

    for (const iv of intervalos) {
      const o = horaParaMinutos(iv.abertura);
      const c = horaParaMinutos(iv.fechamento);

      if (c > o) {
        if (mins >= o && mins < c) return true;
      } else {
        // overnight
        if (mins >= o || mins < c) return true;
      }
    }

    // checar intervalo overnight do dia anterior
    const prev = (dia + 6) % 7;
    const prevIntervalos = this.#horario[String(prev)] ?? [];

    for (const iv of prevIntervalos) {
      const o = horaParaMinutos(iv.abertura);
      const c = horaParaMinutos(iv.fechamento);
      if (c <= o && mins < c) return true;
    }

    return false;
  };

  /**
   * Obtém a próxima data/hora de abertura do estabelecimento.
   * @param dt - Data de referência para busca (padrão: data atual)
   * @returns Data da próxima abertura ou null se não encontrada
   * @throws Error se a data for inválida
   */
  proximaAbertura = (dt: Date | string = new Date()): Date | null => {
    const date = typeof dt === "string" ? new Date(dt) : new Date(dt.getTime());
    if (Number.isNaN(date.getTime())) {
      throw new Error("Data inválida");
    }
    if (this.estaAberto(date)) return date;

    // busca até 14 dias (permite feriados)
    for (let offset = 0; offset <= 14; offset++) {
      const cand = new Date(date.getTime());
      cand.setDate(date.getDate() + offset);
      if (this.#ehFeriado(cand)) continue;

      const dIdx = diaIndex(cand);
      const intervalos = this.#horario[String(dIdx)] ?? [];
      const currentMins = offset === 0 ? minutosDoDia(date) : -1;
      let best: number | null = null;

      for (const iv of intervalos) {
        const o = horaParaMinutos(iv.abertura);
        if (offset === 0) {
          if (o >= currentMins && (best === null || o < best)) {
            best = o;
          }
        } else if (best === null || o < best) {
          best = o;
        }
      }

      if (best !== null) {
        const res = new Date(cand.getTime());
        res.setHours(Math.floor(best / 60), best % 60, 0, 0);
        return res;
      }
    }
    return null;
  };

  /**
   * Obtém a próxima data/hora de fechamento do estabelecimento.
   * @param dt - Data de referência para busca (padrão: data atual)
   * @returns Data do próximo fechamento ou null se não encontrada
   * @throws Error se a data for inválida
   */
  proximoFechamento = (dt: Date | string = new Date()): Date | null => {
    const date = typeof dt === "string" ? new Date(dt) : new Date(dt.getTime());
    if (Number.isNaN(date.getTime())) {
      throw new Error("Data inválida");
    }
    if (this.#ehFeriado(date)) return null;

    const dia = diaIndex(date);
    const mins = minutosDoDia(date);
    const intervalos = this.#horario[String(dia)] ?? [];

    for (const iv of intervalos) {
      const o = horaParaMinutos(iv.abertura);
      const c = horaParaMinutos(iv.fechamento);

      if (c > o) {
        if (mins >= o && mins < c) {
          const res = new Date(date.getTime());
          res.setHours(Math.floor(c / 60), c % 60, 0, 0);
          return res;
        }
      } else {
        // overnight
        if (mins >= o) {
          const res = new Date(date.getTime());
          res.setDate(date.getDate() + 1);
          res.setHours(Math.floor(c / 60), c % 60, 0, 0);
          return res;
        } else if (mins < c) {
          const res = new Date(date.getTime());
          res.setHours(Math.floor(c / 60), c % 60, 0, 0);
          return res;
        }
      }
    }

    // se não estiver aberto, pega a próxima abertura e calcula fechamento
    const na = this.proximaAbertura(date);
    if (!na) return null;

    const dIdx = diaIndex(na);
    const intervalosNext = this.#horario[String(dIdx)] ?? [];

    for (const iv of intervalosNext) {
      const o = horaParaMinutos(iv.abertura);
      if (o === na.getHours() * 60 + na.getMinutes()) {
        const c = horaParaMinutos(iv.fechamento);
        const res = new Date(na.getTime());
        if (c > o) {
          res.setHours(Math.floor(c / 60), c % 60, 0, 0);
        } else {
          res.setDate(res.getDate() + 1);
          res.setHours(Math.floor(c / 60), c % 60, 0, 0);
        }
        return res;
      }
    }
    return na;
  };

  /**
   * Adiciona minutos úteis (dentro do horário comercial) a uma data.
   * @param dt - Data base para o cálculo (padrão: data atual)
   * @param minutosAdicionar - Número de minutos úteis a adicionar (padrão: 0)
   * @returns Nova data com os minutos úteis adicionados
   * @throws Error se a data for inválida ou não encontrar próxima abertura
   */
  adicionarMinutosUteis = (
    dt: Date | string = new Date(),
    minutosAdicionar: number = 0
  ): Date => {
    if (minutosAdicionar === 0) {
      return typeof dt === "string" ? new Date(dt) : new Date(dt.getTime());
    }

    let cursor = typeof dt === "string" ? new Date(dt) : new Date(dt.getTime());
    if (Number.isNaN(cursor.getTime())) {
      throw new Error("Data inválida");
    }

    if (!this.estaAberto(cursor)) {
      const no = this.proximaAbertura(cursor);
      if (!no) throw new Error("Não foi encontrada próxima abertura");
      cursor = no;
    }

    let restante = minutosAdicionar;
    while (restante > 0) {
      const fechamento = this.proximoFechamento(cursor);
      if (!fechamento)
        throw new Error("Não foi encontrado fechamento durante cálculo");

      const disponivel = Math.floor(
        (fechamento.getTime() - cursor.getTime()) / 60000
      );
      if (disponivel >= restante) {
        cursor = new Date(cursor.getTime() + restante * 60000);
        restante = 0;
        break;
      } else {
        restante -= disponivel;
        cursor = new Date(fechamento.getTime() + 1000);
        const no = this.proximaAbertura(cursor);
        if (!no)
          throw new Error(
            "Não foi encontrada próxima abertura durante cálculo"
          );
        cursor = no;
      }
    }
    return cursor;
  };

  /**
   * Calcula quantos minutos restam de horário comercial no dia atual.
   * @param dt - Data de referência (padrão: data atual)
   * @returns Número de minutos restantes no dia atual
   */
  minutosRestantesHoje = (dt: Date | string = new Date()): number => {
    const date = typeof dt === "string" ? new Date(dt) : new Date(dt.getTime());
    if (!this.estaAberto(date)) return 0;

    const fechamento = this.proximoFechamento(date);
    if (!fechamento) return 0;

    return Math.max(
      0,
      Math.floor((fechamento.getTime() - date.getTime()) / 60000)
    );
  };

  /**
   * Obtém uma cópia da configuração de horário comercial atual.
   * @returns Cópia da configuração de horários por dia da semana
   */
  obterHorario = (): Horario => {
    return structuredClone(this.#horario);
  };

  /**
   * Obtém todos os feriados com informações completas.
   * @returns Array de feriados com nome, data, observações e status
   */
  obterFeriados = (): readonly Feriado[] => {
    return [...this.#feriados];
  };

  /**
   * Obtém apenas as datas dos feriados (formato antigo para compatibilidade).
   * @returns Array de strings com as datas dos feriados
   */
  obterDatasFeriados = (): readonly string[] => {
    return obterDatasFeriados(this.#feriados);
  };

  /**
   * Verifica se uma data específica é um feriado e retorna informações completas.
   * @param data - Data para verificar (Date ou string)
   * @returns Feriado encontrado ou undefined
   */
  obterFeriadoPorData = (data: Date | string): Feriado | undefined => {
    const dataStr =
      typeof data === "string" ? data : data.toISOString().split("T")[0];
    return this.#feriados.find((feriado) => feriado.data === dataStr);
  };

  /**
   * Obtém feriados que ainda não passaram baseado na data atual.
   * @param dataAtual - Data atual para comparação (padrão: new Date())
   * @returns Array de feriados futuros
   */
  obterFeriadosFuturos = (dataAtual: Date = new Date()): readonly Feriado[] => {
    const hoje = dataAtual.toISOString().split("T")[0];
    return this.#feriados.filter((feriado) => feriado.data >= (hoje || ""));
  };

  /**
   * Obtém feriados que já passaram baseado na data atual.
   * @param dataAtual - Data atual para comparação (padrão: new Date())
   * @returns Array de feriados passados
   */
  obterFeriadosPassados = (
    dataAtual: Date = new Date()
  ): readonly Feriado[] => {
    const hoje = dataAtual.toISOString().split("T")[0];
    return this.#feriados.filter((feriado) => feriado.data < (hoje || ""));
  };
}
