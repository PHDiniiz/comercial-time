/**
 * Barrel exports para a biblioteca de horário comercial
 */

// Tipos
export type { DiaChave, HoraString, Intervalo, Horario } from "./types.js";

// Funções utilitárias
export {
  horaParaMinutos,
  minutosParaHora,
  diaIndex,
  minutosDoDia,
} from "./utils.js";

// Funções de normalização
export { normalizarDia, normalizarHorario } from "./normalize.js";

// Classe principal
export { HorarioComercial } from "./horario-comercial.js";
