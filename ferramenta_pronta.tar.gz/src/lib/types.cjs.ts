/**
 * Tipos para o módulo de horário comercial (CommonJS)
 */

export type DiaChave = number | string; // 0 (domingo) - 6 (sábado) ou nomes 'segunda', 'monday', etc
export type HoraString = string; // "HH:mm"
export type Intervalo = {
  readonly abertura: HoraString;
  readonly fechamento: HoraString;
};
export type Horario = Readonly<Record<string, readonly Intervalo[]>>; // chaves dia (string do número) -> intervalos
