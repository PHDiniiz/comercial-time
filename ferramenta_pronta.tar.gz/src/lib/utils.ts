/**
 * Funções utilitárias para manipulação de horários
 */

import type { HoraString } from "./types.js";

/**
 * Função auxiliar para padronizar números com 2 dígitos.
 * @param n - Número a ser padronizado
 * @returns String com o número padronizado com 2 dígitos
 */
const pad2 = (n: number): string => n.toString().padStart(2, "0");

/**
 * Converte uma string de hora (HH:mm) para minutos desde meia-noite.
 * @param h - String de hora no formato HH:mm
 * @returns Número de minutos desde meia-noite
 * @throws Error se o formato for inválido
 */
export const horaParaMinutos = (h: HoraString): number => {
  const [hStr, mStr] = h.split(":");
  const hh = Number(hStr ?? 0);
  const mm = Number(mStr ?? 0);
  if (Number.isNaN(hh) || Number.isNaN(mm)) {
    throw new Error(`Formato de hora inválido: ${h}`);
  }
  return hh * 60 + mm;
};

/**
 * Converte minutos desde meia-noite para string de hora (HH:mm).
 * @param mins - Número de minutos desde meia-noite
 * @returns String de hora no formato HH:mm
 */
export const minutosParaHora = (mins: number): HoraString => {
  const normalizedMins = ((mins % (24 * 60)) + 24 * 60) % (24 * 60);
  const h = Math.floor(normalizedMins / 60);
  const m = normalizedMins % 60;
  return `${pad2(h)}:${pad2(m)}`;
};

/**
 * Obtém o índice do dia da semana de uma data (0-6).
 * @param date - Data para obter o dia da semana
 * @returns Número do dia da semana (0=domingo, 6=sábado)
 */
export const diaIndex = (date: Date): number => date.getDay(); // 0-6

/**
 * Obtém o número de minutos desde meia-noite de uma data.
 * @param date - Data para calcular os minutos
 * @returns Número de minutos desde meia-noite
 */
export const minutosDoDia = (date: Date): number =>
  date.getHours() * 60 + date.getMinutes();
