/**
 * Funções para normalização de dias e horários (CommonJS)
 */

import type { DiaChave, Intervalo, Horario } from "./types.cjs";

const nomesPadrao = new Map([
  ["domingo", 0],
  ["dom", 0],
  ["sunday", 0],
  ["segunda", 1],
  ["segunda-feira", 1],
  ["seg", 1],
  ["monday", 1],
  ["terca", 2],
  ["terca-feira", 2],
  ["ter", 2],
  ["tuesday", 2],
  ["terça", 2],
  ["quarta", 3],
  ["quarta-feira", 3],
  ["wed", 3],
  ["wednesday", 3],
  ["quinta", 4],
  ["quinta-feira", 4],
  ["thu", 4],
  ["thursday", 4],
  ["sexta", 5],
  ["sexta-feira", 5],
  ["fri", 5],
  ["friday", 5],
  ["sabado", 6],
  ["sábado", 6],
  ["sat", 6],
  ["saturday", 6],
] as const);

export const normalizarDia = (k: DiaChave): number => {
  if (typeof k === "number") {
    if (k >= 0 && k <= 6) return k;
    throw new Error("Número de dia inválido. Use 0 (domingo) até 6 (sábado).");
  }
  const key = String(k)
    .toLowerCase()
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "");
  const found = nomesPadrao.get(key as any);
  if (found === undefined) {
    throw new Error(`Nome de dia desconhecido: ${k}`);
  }
  return found;
};

export const normalizarHorario = (
  input: Record<DiaChave, Intervalo[] | Intervalo>
): Horario => {
  const out: Record<string, Intervalo[]> = {};

  for (const [k, value] of Object.entries(input)) {
    const keyRaw = isNaN(Number(k)) ? k : Number(k);
    const nk = normalizarDia(keyRaw);
    const dayStr = String(nk);
    const arr = Array.isArray(value) ? value : [value];

    out[dayStr] = arr.map((iv: Intervalo) => {
      if (!iv.abertura || !iv.fechamento) {
        throw new Error("Intervalo precisa ter abertura e fechamento");
      }
      return { abertura: iv.abertura, fechamento: iv.fechamento } as const;
    });
  }

  return out as Horario;
};
