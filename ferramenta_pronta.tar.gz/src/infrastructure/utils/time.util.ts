/**
 * Infrastructure Layer - Utilitários de Tempo
 *
 * Funções utilitárias para manipulação de tempo e horários.
 * Implementações concretas das operações de tempo.
 */

import type { HoraString } from "../../domain/entities/horario-comercial.entity.js";

/**
 * Função auxiliar para padronizar números com 2 dígitos.
 * @param n - Número a ser padronizado
 * @returns String com o número padronizado com 2 dígitos
 */
const pad2 = (n: number): string => n.toString().padStart(2, "0");

/**
 * Converte uma string de hora (HH:mm) para minutos desde meia-noite.
 * @param h - String de hora no formato HH:mm
 * @returns Número de minutos desde meia-noite
 * @throws Error se o formato for inválido
 */
export const horaParaMinutos = (h: HoraString): number => {
  const [hStr, mStr] = h.split(":");
  const hh = Number(hStr ?? 0);
  const mm = Number(mStr ?? 0);
  if (Number.isNaN(hh) || Number.isNaN(mm)) {
    throw new Error(`Formato de hora inválido: ${h}`);
  }
  return hh * 60 + mm;
};

/**
 * Converte minutos desde meia-noite para string de hora (HH:mm).
 * @param mins - Número de minutos desde meia-noite
 * @returns String de hora no formato HH:mm
 */
export const minutosParaHora = (mins: number): HoraString => {
  const normalizedMins = ((mins % (24 * 60)) + 24 * 60) % (24 * 60);
  const h = Math.floor(normalizedMins / 60);
  const m = normalizedMins % 60;
  return `${pad2(h)}:${pad2(m)}`;
};

/**
 * Obtém o índice do dia da semana de uma data (0-6).
 * @param date - Data para obter o dia da semana
 * @returns Número do dia da semana (0=domingo, 6=sábado)
 */
export const diaIndex = (date: Date): number => date.getDay(); // 0-6

/**
 * Obtém o número de minutos desde meia-noite de uma data.
 * @param date - Data para calcular os minutos
 * @returns Número de minutos desde meia-noite
 */
export const minutosDoDia = (date: Date): number =>
  date.getHours() * 60 + date.getMinutes();

/**
 * Valida se uma string está no formato de hora correto (HH:mm).
 * @param hora - String de hora a ser validada
 * @returns true se o formato for válido, false caso contrário
 */
export const validarFormatoHora = (hora: string): boolean => {
  const regex = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/;
  return regex.test(hora);
};

/**
 * Formata uma data para o formato ISO (YYYY-MM-DD).
 * @param data - Data a ser formatada
 * @returns String da data no formato YYYY-MM-DD
 */
export const formatarDataParaISO = (data: Date): string => {
  return data.toISOString().slice(0, 10);
};
