/**
 * Infrastructure Layer - Timezone Utilities
 *
 * Utilitários para manipulação de timezone e conversão de datas.
 * Integra com a configuração global de timezone.
 */

import {
  getCurrentDate,
  getCurrentTimezone,
} from "../../config/timezone.config.js";

/**
 * Converte uma data para o timezone atualmente configurado no sistema.
 * @param date - Data a ser convertida (Date ou string)
 * @returns Nova data convertida para o timezone atual
 * @throws Error se a data for inválida
 */
export function toCurrentTimezone(date: Date | string): Date {
  const dateObj = typeof date === "string" ? new Date(date) : date;

  if (Number.isNaN(dateObj.getTime())) {
    throw new Error("Data inválida fornecida");
  }

  try {
    const timezone = getCurrentTimezone();
    const utc = dateObj.getTime() + dateObj.getTimezoneOffset() * 60000;
    const targetTime = new Date(utc + getTimezoneOffset(timezone) * 60000);
    return targetTime;
  } catch (error) {
    console.warn("Erro ao converter timezone, usando data original:", error);
    return dateObj;
  }
}

/**
 * Obtém o offset de um timezone específico em minutos em relação ao UTC.
 * @param timezone - String do timezone (ex: "America/Sao_Paulo")
 * @returns Offset em minutos (positivo para leste, negativo para oeste)
 */
export function getTimezoneOffset(timezone: string): number {
  try {
    const now = new Date();
    const utc = new Date(now.getTime() + now.getTimezoneOffset() * 60000);
    const target = new Date(
      utc.toLocaleString("en-US", { timeZone: timezone })
    );
    return (target.getTime() - utc.getTime()) / 60000;
  } catch {
    return 0; // Fallback para UTC
  }
}

/**
 * Verifica se um timezone é válido usando a API Intl.
 * @param timezone - String do timezone a ser validado
 * @returns true se o timezone for válido, false caso contrário
 */
export function isValidTimezone(timezone: string): boolean {
  try {
    Intl.DateTimeFormat(undefined, { timeZone: timezone });
    return true;
  } catch {
    return false;
  }
}

/**
 * Obtém a data atual no timezone configurado no sistema.
 * @returns Data atual convertida para o timezone configurado
 */
export function getNowInTimezone(): Date {
  return getCurrentDate();
}

/**
 * Formata uma data no timezone atualmente configurado.
 * @param date - Data a ser formatada (Date ou string)
 * @param options - Opções de formatação do Intl.DateTimeFormat
 * @returns String formatada da data
 * @throws Error se a data for inválida
 */
export function formatDateInTimezone(
  date: Date | string,
  options?: Intl.DateTimeFormatOptions
): string {
  const dateObj = typeof date === "string" ? new Date(date) : date;

  if (Number.isNaN(dateObj.getTime())) {
    throw new Error("Data inválida fornecida");
  }

  try {
    const timezone = getCurrentTimezone();
    return dateObj.toLocaleString("pt-BR", {
      timeZone: timezone,
      ...options,
    });
  } catch (error) {
    console.warn("Erro ao formatar data no timezone:", error);
    return dateObj.toISOString();
  }
}

/**
 * Obtém apenas a hora (HH:mm) no timezone atualmente configurado.
 * @param date - Data de referência (padrão: data atual)
 * @returns String com a hora no formato HH:mm
 */
export function getTimeInTimezone(date: Date | string = new Date()): string {
  return formatDateInTimezone(date, {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

/**
 * Obtém apenas a data (DD/MM/YYYY) no timezone atualmente configurado.
 * @param date - Data de referência (padrão: data atual)
 * @returns String com a data no formato DD/MM/YYYY
 */
export function getDateInTimezone(date: Date | string = new Date()): string {
  return formatDateInTimezone(date, {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
}

/**
 * Obtém o dia da semana (0-6) no timezone atualmente configurado.
 * @param date - Data de referência (padrão: data atual)
 * @returns Número do dia da semana (0=domingo, 6=sábado)
 */
export function getDayOfWeekInTimezone(
  date: Date | string = new Date()
): number {
  const dateObj = typeof date === "string" ? new Date(date) : date;
  const timezoneDate = toCurrentTimezone(dateObj);
  return timezoneDate.getDay();
}

/**
 * Obtém o nome do dia da semana no timezone atualmente configurado.
 * @param date - Data de referência (padrão: data atual)
 * @returns Nome do dia da semana em português
 */
export function getDayNameInTimezone(date: Date | string = new Date()): string {
  const dayIndex = getDayOfWeekInTimezone(date);
  const dayNames = [
    "domingo",
    "segunda",
    "terça",
    "quarta",
    "quinta",
    "sexta",
    "sábado",
  ];
  return dayNames[dayIndex] || "desconhecido";
}

/**
 * Cria uma data no timezone atualmente configurado com hora específica.
 * @param year - Ano da data
 * @param month - Mês da data (1-12)
 * @param day - Dia da data (1-31)
 * @param hour - Hora (0-23, padrão: 0)
 * @param minute - Minuto (0-59, padrão: 0)
 * @param second - Segundo (0-59, padrão: 0)
 * @returns Nova data criada no timezone configurado
 * @throws Error se houver erro na criação da data
 */
export function createDateInTimezone(
  year: number,
  month: number,
  day: number,
  hour: number = 0,
  minute: number = 0,
  second: number = 0
): Date {
  try {
    const timezone = getCurrentTimezone();
    const dateString = `${year}-${String(month).padStart(2, "0")}-${String(
      day
    ).padStart(2, "0")}T${String(hour).padStart(2, "0")}:${String(
      minute
    ).padStart(2, "0")}:${String(second).padStart(2, "0")}`;

    // Cria a data no timezone local primeiro
    const localDate = new Date(dateString);

    // Converte para o timezone configurado
    return toCurrentTimezone(localDate);
  } catch (error) {
    throw new Error(`Erro ao criar data no timezone: ${error}`);
  }
}

/**
 * Compara duas datas considerando o timezone atualmente configurado.
 * @param date1 - Primeira data para comparação
 * @param date2 - Segunda data para comparação
 * @returns Número negativo se date1 < date2, 0 se iguais, positivo se date1 > date2
 */
export function compareDatesInTimezone(
  date1: Date | string,
  date2: Date | string
): number {
  const d1 = toCurrentTimezone(date1);
  const d2 = toCurrentTimezone(date2);

  return d1.getTime() - d2.getTime();
}

/**
 * Verifica se uma data é hoje no timezone atualmente configurado.
 * @param date - Data a ser verificada
 * @returns true se a data for hoje, false caso contrário
 */
export function isTodayInTimezone(date: Date | string): boolean {
  const targetDate = toCurrentTimezone(date);
  const today = getNowInTimezone();

  return (
    targetDate.getFullYear() === today.getFullYear() &&
    targetDate.getMonth() === today.getMonth() &&
    targetDate.getDate() === today.getDate()
  );
}

/**
 * Verifica se uma data é no futuro no timezone atualmente configurado.
 * @param date - Data a ser verificada
 * @returns true se a data for no futuro, false caso contrário
 */
export function isFutureInTimezone(date: Date | string): boolean {
  const targetDate = toCurrentTimezone(date);
  const now = getNowInTimezone();

  return targetDate.getTime() > now.getTime();
}

/**
 * Verifica se uma data é no passado no timezone atualmente configurado.
 * @param date - Data a ser verificada
 * @returns true se a data for no passado, false caso contrário
 */
export function isPastInTimezone(date: Date | string): boolean {
  const targetDate = toCurrentTimezone(date);
  const now = getNowInTimezone();

  return targetDate.getTime() < now.getTime();
}
