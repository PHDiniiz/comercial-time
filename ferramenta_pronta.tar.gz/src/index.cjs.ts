/**
 * @phdiniiz/comercialTime
 * API em Português (pt-BR) para horários comerciais.
 *
 * Exportações principais:
 * - HorarioComercial
 * - helpers: horaParaMinutos, minutosParaHora, normalizarDia, normalizarHorario
 * - Sistema de inicialização: inicializar, inicializarRapido, etc.
 */

// Re-exportar tudo da biblioteca (versão CommonJS) - usando legacy para compatibilidade
export * from "./legacy/horario-comercial.legacy.js";

// Re-exportar utilitários
export {
  horaParaMinutos,
  minutosParaHora,
  diaIndex,
  minutosDoDia,
  validarFormatoHora,
  formatarDataParaISO,
} from "./infrastructure/utils/time.util.js";

export {
  normalizarDia,
  normalizarHorario,
  obterNomeDia,
} from "./infrastructure/utils/normalize.util.js";

// Re-exportar sistema de inicialização (migrado do main.ts)
export {
  inicializar,
  inicializarRapido,
  inicializarComercialTime,
  inicializarComercialTimeComTimezone,
  inicializarParaBrasil,
  inicializarParaEUA,
  inicializarParaPortugal,
  obterInfoTimezone,
  estaInicializado,
} from "./index.js";

export type { InicializacaoConfig } from "./index.js";
