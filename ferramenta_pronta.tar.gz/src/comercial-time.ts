/**
 * @phdiniiz/comercialTime
 * Sistema de Importação Modular para Horários Comerciais
 *
 * Permite importação seletiva de feriados nacionais e estaduais
 * com sintaxe limpa e intuitiva.
 */

import { ComercialTime, IncluirConfig } from "./core/comercial-time.js";

/**
 * Função principal para importação modular
 * @param config - Configuração de importação
 * @returns Instância do ComercialTime configurada
 */
export function incluir(config: IncluirConfig): ComercialTime {
  return new ComercialTime(config);
}

/**
 * Exportação padrão - instância base sem feriados
 */
const comercialTime = new ComercialTime();

export default comercialTime;

// Re-exportar tipos e classes principais
export { ComercialTime } from "./core/comercial-time.js";
export type { IncluirConfig } from "./core/comercial-time.js";
export { HorarioComercial } from "./lib/horario-comercial.js";
export type {
  Feriado,
  DiaChave,
  HoraString,
  Intervalo,
  Horario,
} from "./domain/entities/horario-comercial.entity.js";

// Re-exportar utilitários
export {
  horaParaMinutos,
  minutosParaHora,
  diaIndex,
  minutosDoDia,
  validarFormatoHora,
  formatarDataParaISO,
} from "./infrastructure/utils/time.util.js";

export {
  normalizarDia,
  normalizarHorario,
  obterNomeDia,
} from "./infrastructure/utils/normalize.util.js";

export {
  carregarFeriados,
  obterFeriadosFuturos,
  obterFeriadosPassados,
  ehFeriado,
  obterFeriadoPorData,
  obterDatasFeriados,
  obterFeriadosPorMes,
  obterFeriadosPorAno,
} from "./infrastructure/utils/feriados.util.js";

export {
  toCurrentTimezone,
  getNowInTimezone,
  formatDateInTimezone,
  getTimeInTimezone,
  getDateInTimezone,
  getDayOfWeekInTimezone,
  getDayNameInTimezone,
  createDateInTimezone,
  compareDatesInTimezone,
  isTodayInTimezone,
  isFutureInTimezone,
  isPastInTimezone,
} from "./infrastructure/utils/timezone.util.js";

export {
  timezoneManager,
  getCurrentTimezone,
  getCurrentDate,
  formatDate,
  DEFAULT_TIMEZONE_CONFIG,
} from "./config/timezone.config.js";

// Re-exportar sistema de atualização de feriados
export {
  inicializarCronJobFeriados,
  inicializarCronJobFeriadosPorPais,
  executarAtualizacaoManual,
} from "./cronjob/feriado-update.cronjob.js";

export { FeriadoUpdateFactory } from "./presentation/factories/feriado-update.factory.js";
export type {
  FeriadoUpdateConfig,
  FeriadoUpdateResult,
} from "./domain/entities/feriado-update.entity.js";

// Re-exportar sistema de inicialização principal
export {
  inicializarComercialTime,
  inicializarComercialTimeComTimezone,
  inicializarParaBrasil,
  inicializarParaEUA,
  inicializarParaPortugal,
  obterInfoTimezone,
  estaInicializado,
} from "./index.js";

export type { InicializacaoConfig } from "./index.js";
