/**
 * Security Layer - Validadores de Entrada
 *
 * Validações de segurança para prevenir ataques comuns como:
 * - Injection attacks
 * - XSS
 * - DoS por entrada maliciosa
 */

/**
 * Classe para validação de entrada de dados com foco em segurança.
 * Previne ataques comuns como injection, XSS e DoS por entrada maliciosa.
 */
export class InputValidator {
  /**
   * Valida se uma string contém apenas caracteres seguros para horários.
   * @param input - String de entrada a ser validada
   * @returns true se a entrada for segura e válida, false caso contrário
   */
  static validateHorarioInput(input: string): boolean {
    // Previne injection attacks
    const dangerousChars = /[<>'"&;(){}[\]\\|`~!@#$%^*+=]/;
    if (dangerousChars.test(input)) {
      return false;
    }

    // Valida formato de horário
    const horarioRegex = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/;
    return horarioRegex.test(input);
  }

  /**
   * Valida se uma string contém apenas caracteres seguros para nomes de dias.
   * @param input - String de entrada a ser validada
   * @returns true se a entrada for segura e válida, false caso contrário
   */
  static validateDiaInput(input: string): boolean {
    // Previne injection attacks
    const dangerousChars = /[<>'"&;(){}[\]\\|`~!@#$%^*+=]/;
    if (dangerousChars.test(input)) {
      return false;
    }

    // Permite apenas letras, números, hífens e espaços
    const safeChars = /^[a-zA-Z0-9\s\-áàâãéèêíìîóòôõúùûçÁÀÂÃÉÈÊÍÌÎÓÒÔÕÚÙÛÇ]+$/;
    return safeChars.test(input);
  }

  /**
   * Valida se uma data é válida e não é maliciosa.
   * @param input - Data a ser validada (string ou Date)
   * @returns true se a data for válida e segura, false caso contrário
   */
  static validateDateInput(input: string | Date): boolean {
    try {
      const date = typeof input === "string" ? new Date(input) : input;

      // Verifica se é uma data válida
      if (Number.isNaN(date.getTime())) {
        return false;
      }

      // Previne datas muito antigas ou muito futuras (possível DoS)
      const now = new Date();
      const minDate = new Date(1900, 0, 1);
      const maxDate = new Date(2100, 11, 31);

      return date >= minDate && date <= maxDate;
    } catch {
      return false;
    }
  }

  /**
   * Sanitiza entrada de string removendo caracteres perigosos.
   * @param input - String a ser sanitizada
   * @returns String sanitizada e limitada a 100 caracteres
   */
  static sanitizeString(input: string): string {
    return input
      .replace(/[<>'"&;(){}[\]\\|`~!@#$%^*+=]/g, "")
      .trim()
      .slice(0, 100); // Limita tamanho para prevenir DoS
  }

  /**
   * Valida array de feriados para garantir segurança e formato correto.
   * @param feriados - Array de feriados a ser validado
   * @returns true se todos os feriados forem válidos, false caso contrário
   */
  static validateFeriados(feriados: readonly string[]): boolean {
    if (!Array.isArray(feriados)) {
      return false;
    }

    // Limita número de feriados para prevenir DoS
    if (feriados.length > 1000) {
      return false;
    }

    // Valida cada feriado
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    return feriados.every(
      (feriado) =>
        typeof feriado === "string" &&
        dateRegex.test(feriado) &&
        this.validateDateInput(feriado)
    );
  }
}
