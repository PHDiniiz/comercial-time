/**
 * @phdiniiz/comercialTime
 * API em Português (pt-BR) para horários comerciais.
 *
 * Implementação seguindo Clean Architecture com camadas bem definidas:
 * - Domain: Entidades e regras de negócio
 * - Application: Casos de uso
 * - Infrastructure: Serviços e utilitários
 * - Presentation: Controllers e interfaces
 * - Core: Sistema de importação modular
 *
 * Exportações principais:
 * - comercialTime (instância principal com sistema modular)
 * - incluir() (função para importação seletiva)
 * - HorarioComercial (classe principal para compatibilidade)
 * - helpers: horaParaMinutos, minutosParaHora, normalizarDia, normalizarHorario
 */

// Exportar sistema modular principal
export {
  default as comercialTime,
  criarComercialTime as incluir,
} from "./core/comercial-time.js";

// Re-exportar tipos do domínio
export type {
  DiaChave,
  HoraString,
  Intervalo,
  Horario,
  Feriado,
} from "./domain/entities/horario-comercial.entity.js";

// Re-exportar utilitários
export {
  horaParaMinutos,
  minutosParaHora,
  diaIndex,
  minutosDoDia,
  validarFormatoHora,
  formatarDataParaISO,
} from "./infrastructure/utils/time.util.js";

export {
  normalizarDia,
  normalizarHorario,
  obterNomeDia,
} from "./infrastructure/utils/normalize.util.js";

// Re-exportar utilitários de feriados
export {
  carregarFeriados,
  obterFeriadosFuturos,
  obterFeriadosPassados,
  ehFeriado,
  obterFeriadoPorData,
  obterDatasFeriados,
  obterFeriadosPorMes,
  obterFeriadosPorAno,
} from "./infrastructure/utils/feriados.util.js";

// Re-exportar utilitários de localização
export {
  carregarFeriadosNacionais,
  carregarFeriadosEstaduais,
  carregarDadosLocalizacao,
  listarLocalizacoesDisponiveis,
  localizacaoValida,
  carregarFeriadosPersonalizados,
  feriadosPersonalizadosDisponiveis,
  obterInfoFeriadosPersonalizados,
} from "./infrastructure/utils/locale.util.js";

// Re-exportar sistema de atualização de feriados
export {
  inicializarCronJobFeriados,
  inicializarCronJobFeriadosPorPais,
  executarAtualizacaoManual,
} from "./cronjob/feriado-update.cronjob.js";

export { FeriadoUpdateFactory } from "./presentation/factories/feriado-update.factory.js";
export type {
  FeriadoUpdateConfig,
  FeriadoUpdateResult,
} from "./domain/entities/feriado-update.entity.js";

// Sistema de inicialização principal (migrado do main.ts)
import { inicializarCronJobFeriados } from "./cronjob/feriado-update.cronjob.js";
import { getCurrentTimezone } from "./config/timezone.config.js";

/**
 * Interface para configuração de inicialização
 */
export interface InicializacaoConfig {
  /** Timezone para configuração (ex: "America/Sao_Paulo") - OBRIGATÓRIO */
  timezone: string;
  /** Inicializar CRONJOB automaticamente */
  inicializarCronJob?: boolean;
  /** Intervalo do CRONJOB em minutos */
  intervaloCronJob?: number;
  /** Timeout das requisições em milissegundos */
  timeoutRequisicoes?: number;
}

/**
 * Detecta país, locale e capital baseado no timezone
 * @param timezone - Timezone para análise
 * @returns Objeto com informações do país
 */
function detectarPaisPorTimezone(timezone: string): {
  pais: string;
  locale: string;
  capital: string;
} {
  // Mapeamento direto dos timezones principais
  if (timezone === "America/Sao_Paulo") {
    return { pais: "BR", locale: "pt-br", capital: "BRASILIA" };
  } else if (timezone === "America/New_York") {
    return { pais: "US", locale: "en-US", capital: "WASHINGTON" };
  } else if (timezone === "Europe/Lisbon") {
    return { pais: "PT", locale: "pt-PT", capital: "LISBOA" };
  }

  // Fallback para timezones similares
  if (
    timezone.includes("America/Sao_Paulo") ||
    timezone.includes("America/Recife") ||
    timezone.includes("America/Manaus") ||
    timezone.includes("America/Bahia") ||
    timezone.includes("America/Fortaleza")
  ) {
    return { pais: "BR", locale: "pt-br", capital: "BRASILIA" };
  } else if (
    timezone.includes("America/New_York") ||
    timezone.includes("America/Los_Angeles") ||
    timezone.includes("America/Chicago") ||
    timezone.includes("America/Denver")
  ) {
    return { pais: "US", locale: "en-US", capital: "WASHINGTON" };
  } else if (
    timezone.includes("Europe/Lisbon") ||
    timezone.includes("Europe/Azores") ||
    timezone.includes("Europe/Madeira")
  ) {
    return { pais: "PT", locale: "pt-PT", capital: "LISBOA" };
  }

  // Fallback padrão para Brasil
  return { pais: "BR", locale: "pt-br", capital: "BRASILIA" };
}

/**
 * Inicializa o módulo de horários comerciais
 * @param config - Configuração de inicialização (timezone é OBRIGATÓRIO)
 * @returns Promise com informações da inicialização
 */
export async function inicializarComercialTime(
  config: InicializacaoConfig
): Promise<{
  sucesso: boolean;
  timezone: string;
  pais: string;
  locale: string;
  capital: string;
  cronJobIniciado: boolean;
  mensagem: string;
}> {
  try {
    console.log("🚀 Inicializando módulo @phdiniiz/comercialTime...");

    // Validar se timezone foi fornecido
    if (!config.timezone) {
      throw new Error(
        "Timezone é obrigatório. Use: { timezone: 'America/Sao_Paulo' }"
      );
    }

    // Configurar timezone
    const timezone = config.timezone;
    process.env.TIMEZONE = timezone;

    // Configurar CRONJOB se solicitado
    if (config.intervaloCronJob) {
      process.env.FERIADO_UPDATE_INTERVAL_MINUTES =
        config.intervaloCronJob.toString();
    }

    if (config.timeoutRequisicoes) {
      process.env.FERIADO_UPDATE_TIMEOUT_MS =
        config.timeoutRequisicoes.toString();
    }

    // Detectar país e locale baseado no timezone
    const { pais, locale, capital } = detectarPaisPorTimezone(timezone);

    console.log(`🌍 Timezone configurado: ${timezone}`);
    console.log(`🏳️ País detectado: ${pais} (${locale})`);
    console.log(`🏛️ Capital: ${capital}`);

    // Inicializar CRONJOB se solicitado (de forma assíncrona e não-bloqueante)
    let cronJobIniciado = false;
    if (config.inicializarCronJob !== false) {
      // Padrão: true - Inicia de forma assíncrona para não bloquear a tela
      console.log("⏰ Iniciando CRONJOB de atualização de feriados...");

      // Inicia o CRONJOB de forma assíncrona após um pequeno delay
      setTimeout(() => {
        inicializarCronJobFeriados();
        console.log(
          "✅ CRONJOB iniciado com sucesso (executando em background)"
        );
      }, 50); // 50ms de delay para garantir que a inicialização seja rápida

      cronJobIniciado = true;
    }

    const resultado = {
      sucesso: true,
      timezone,
      pais,
      locale,
      capital,
      cronJobIniciado,
      mensagem: `Módulo inicializado com sucesso para ${pais} (${locale})`,
    };

    console.log("✅ Módulo @phdiniiz/comercialTime inicializado com sucesso!");
    return resultado;
  } catch (error) {
    const erro = error instanceof Error ? error.message : String(error);
    console.error("❌ Erro ao inicializar módulo:", erro);

    return {
      sucesso: false,
      timezone: config.timezone || "America/Sao_Paulo",
      pais: "BR",
      locale: "pt-br",
      capital: "BRASILIA",
      cronJobIniciado: false,
      mensagem: `Erro na inicialização: ${erro}`,
    };
  }
}

/**
 * Inicializa o módulo com timezone específico
 * @param timezone - Timezone para configuração (ex: "America/Sao_Paulo")
 * @param opcoes - Opções adicionais de inicialização
 * @returns Promise com informações da inicialização
 */
export async function inicializarComercialTimeComTimezone(
  timezone: string,
  opcoes: Omit<InicializacaoConfig, "timezone"> = {}
): Promise<{
  sucesso: boolean;
  timezone: string;
  pais: string;
  locale: string;
  capital: string;
  cronJobIniciado: boolean;
  mensagem: string;
}> {
  return inicializarComercialTime({
    timezone,
    ...opcoes,
  });
}

/**
 * Função principal para inicializar o módulo - ACEITA TIMEZONE COMO PARÂMETRO OBRIGATÓRIO
 * @param timezone - Timezone para configuração (ex: "America/Sao_Paulo") - OBRIGATÓRIO
 * @param opcoes - Opções adicionais de inicialização
 * @returns Promise com informações da inicialização
 */
export async function inicializar(
  timezone: string,
  opcoes: Omit<InicializacaoConfig, "timezone"> = {}
): Promise<{
  sucesso: boolean;
  timezone: string;
  pais: string;
  locale: string;
  capital: string;
  cronJobIniciado: boolean;
  mensagem: string;
}> {
  return inicializarComercialTime({
    timezone,
    ...opcoes,
  });
}

/**
 * Inicialização rápida sem CRONJOB - ideal para aplicações que precisam de inicialização rápida
 * @param timezone - Timezone para configuração (ex: "America/Sao_Paulo") - OBRIGATÓRIO
 * @returns Promise com informações da inicialização
 */
export async function inicializarRapido(timezone: string): Promise<{
  sucesso: boolean;
  timezone: string;
  pais: string;
  locale: string;
  capital: string;
  cronJobIniciado: boolean;
  mensagem: string;
}> {
  return inicializarComercialTime({
    timezone,
    inicializarCronJob: false, // Não inicia CRONJOB para inicialização mais rápida
  });
}

/**
 * Inicializa o módulo para Brasil (pt-BR)
 * @param opcoes - Opções adicionais de inicialização
 * @returns Promise com informações da inicialização
 */
export async function inicializarParaBrasil(
  opcoes: Omit<InicializacaoConfig, "timezone"> = {}
): Promise<{
  sucesso: boolean;
  timezone: string;
  pais: string;
  locale: string;
  capital: string;
  cronJobIniciado: boolean;
  mensagem: string;
}> {
  return inicializarComercialTime({
    timezone: "America/Sao_Paulo",
    ...opcoes,
  });
}

/**
 * Inicializa o módulo para EUA (en-US)
 * @param opcoes - Opções adicionais de inicialização
 * @returns Promise com informações da inicialização
 */
export async function inicializarParaEUA(
  opcoes: Omit<InicializacaoConfig, "timezone"> = {}
): Promise<{
  sucesso: boolean;
  timezone: string;
  pais: string;
  locale: string;
  capital: string;
  cronJobIniciado: boolean;
  mensagem: string;
}> {
  return inicializarComercialTime({
    timezone: "America/New_York",
    ...opcoes,
  });
}

/**
 * Inicializa o módulo para Portugal (pt-PT)
 * @param opcoes - Opções adicionais de inicialização
 * @returns Promise com informações da inicialização
 */
export async function inicializarParaPortugal(
  opcoes: Omit<InicializacaoConfig, "timezone"> = {}
): Promise<{
  sucesso: boolean;
  timezone: string;
  pais: string;
  locale: string;
  capital: string;
  cronJobIniciado: boolean;
  mensagem: string;
}> {
  return inicializarComercialTime({
    timezone: "Europe/Lisbon",
    ...opcoes,
  });
}

/**
 * Obtém informações sobre o timezone atual
 * @returns Informações do timezone configurado
 */
export function obterInfoTimezone(): {
  timezone: string;
  pais: string;
  locale: string;
  capital: string;
} {
  const timezone = getCurrentTimezone();
  const info = detectarPaisPorTimezone(timezone);
  return {
    timezone,
    ...info,
  };
}

/**
 * Verifica se o módulo está inicializado
 * @returns true se o módulo estiver inicializado
 */
export function estaInicializado(): boolean {
  return process.env.TIMEZONE !== undefined;
}

// Re-exportar utilitários de timezone
export {
  toCurrentTimezone,
  getNowInTimezone,
  formatDateInTimezone,
  getTimeInTimezone,
  getDateInTimezone,
  getDayOfWeekInTimezone,
  getDayNameInTimezone,
  createDateInTimezone,
  compareDatesInTimezone,
  isTodayInTimezone,
  isFutureInTimezone,
  isPastInTimezone,
} from "./infrastructure/utils/timezone.util.js";

// Re-exportar configuração de timezone
export {
  timezoneManager,
  getCurrentTimezone,
  getCurrentDate,
  formatDate,
  setTimezone,
  DEFAULT_TIMEZONE_CONFIG,
} from "./config/timezone.config.js";

// Classe principal para compatibilidade com versões anteriores
export { HorarioComercial } from "./legacy/horario-comercial.legacy.js";

// Exportar factory moderna para uso avançado
export {
  HorarioComercialFactory,
  type HorarioComercialFactoryConfig,
} from "./presentation/factories/horario-comercial.factory.js";

// Exportar factory otimizada para performance
export {
  OptimizedHorarioComercialFactory,
  type OptimizedHorarioComercialFactoryConfig,
} from "./presentation/factories/optimized-horario-comercial.factory.js";

// Exportar casos de uso modernos
export {
  HorarioComercialUseCaseImpl,
  type HorarioComercialUseCase,
  type HorarioComercialUseCaseConfig,
} from "./application/use-cases/horario-comercial.use-case.js";

// Exportar serviços otimizados
export {
  OptimizedHorarioComercialService,
} from "./application/services/optimized-horario-comercial.service.js";

// Exportar controllers modernos
export {
  HorarioComercialControllerImpl,
  type HorarioComercialController,
} from "./presentation/controllers/horario-comercial.controller.js";

export {
  OptimizedHorarioComercialControllerImpl,
  type OptimizedHorarioComercialController,
} from "./presentation/controllers/optimized-horario-comercial.controller.js";

export {
  FeriadoUpdateControllerImpl,
  type FeriadoUpdateController,
} from "./presentation/controllers/feriado-update.controller.js";
