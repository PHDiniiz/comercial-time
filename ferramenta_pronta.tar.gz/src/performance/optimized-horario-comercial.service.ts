/**
 * Performance Layer - Serviço Otimizado
 *
 * Versão otimizada do serviço de horário comercial com cache
 * e otimizações de performance.
 */

import type {
  DiaChave,
  Intervalo,
  Horario,
} from "../domain/entities/horario-comercial.entity.js";
import { normalizarHorario } from "../infrastructure/utils/normalize.util.js";
import {
  horaParaMinutos,
  diaIndex,
  minutosDoDia,
  formatarDataParaISO,
} from "../infrastructure/utils/time.util.js";
import { LIMITE_BUSCA_DIAS } from "../domain/entities/horario-comercial.entity.js";
import { horarioCache, proximaAberturaCache } from "./cache.manager.js";

/**
 * Serviço otimizado de horário comercial com cache e otimizações de performance.
 * Implementa as mesmas funcionalidades do HorarioComercial mas com melhorias
 * de performance através de cache e otimizações de algoritmo.
 */
export class OptimizedHorarioComercialService {
  private readonly horario: Horario;
  private readonly feriados: ReadonlySet<string>;
  private readonly feriadosArray: readonly string[];

  /**
   * Constrói uma nova instância do serviço otimizado.
   * @param horarioInput - Configuração de horários por dia da semana
   * @param feriados - Array de feriados no formato YYYY-MM-DD
   */
  constructor(
    horarioInput: Record<DiaChave, Intervalo[] | Intervalo>,
    feriados: readonly string[] = []
  ) {
    this.horario = normalizarHorario(horarioInput);
    this.feriados = new Set(
      feriados.map((f) => f.trim())
    ) as ReadonlySet<string>;
    this.feriadosArray = feriados.map((f) => f.trim());
  }

  /**
   * Verifica se uma data é feriado.
   * @param data - Data a ser verificada
   * @returns true se for feriado, false caso contrário
   */
  private ehFeriado = (data: Date): boolean => {
    const iso = formatarDataParaISO(data);
    return this.feriados.has(iso);
  };

  /**
   * Verifica se o estabelecimento está aberto em uma data específica.
   * Utiliza cache para otimizar performance em consultas repetidas.
   * @param dt - Data para verificação (padrão: data atual)
   * @returns true se estiver aberto, false caso contrário
   * @throws Error se a data for inválida
   */
  estaAberto = (dt: Date | string = new Date()): boolean => {
    const date = typeof dt === "string" ? new Date(dt) : dt;
    if (Number.isNaN(date.getTime())) {
      throw new Error("Data inválida");
    }

    // Cache key baseada na data e horário
    const cacheKey = `${formatarDataParaISO(
      date
    )}_${date.getHours()}_${date.getMinutes()}`;

    // Verificar cache primeiro
    if (horarioCache.has(cacheKey)) {
      return horarioCache.get(cacheKey)!;
    }

    if (this.ehFeriado(date)) {
      horarioCache.set(cacheKey, false);
      return false;
    }

    const dia = diaIndex(date);
    const mins = minutosDoDia(date);
    const intervalos = this.horario[String(dia)] ?? [];

    let resultado = false;

    for (const iv of intervalos) {
      const o = horaParaMinutos(iv.abertura);
      const c = horaParaMinutos(iv.fechamento);

      if (c > o) {
        if (mins >= o && mins < c) {
          resultado = true;
          break;
        }
      } else {
        // overnight
        if (mins >= o || mins < c) {
          resultado = true;
          break;
        }
      }
    }

    // Se não encontrou no dia atual, verificar overnight do dia anterior
    if (!resultado) {
      const prev = (dia + 6) % 7;
      const prevIntervalos = this.horario[String(prev)] ?? [];

      for (const iv of prevIntervalos) {
        const o = horaParaMinutos(iv.abertura);
        const c = horaParaMinutos(iv.fechamento);
        if (c <= o && mins < c) {
          resultado = true;
          break;
        }
      }
    }

    // Armazenar no cache
    horarioCache.set(cacheKey, resultado);
    return resultado;
  };

  /**
   * Obtém a próxima data/hora de abertura do estabelecimento.
   * Utiliza cache para otimizar performance em consultas repetidas.
   * @param dt - Data de referência para busca (padrão: data atual)
   * @returns Data da próxima abertura ou null se não encontrada
   * @throws Error se a data for inválida
   */
  proximaAbertura = (dt: Date | string = new Date()): Date | null => {
    const date = typeof dt === "string" ? new Date(dt) : new Date(dt.getTime());
    if (Number.isNaN(date.getTime())) {
      throw new Error("Data inválida");
    }

    // Cache key baseada na data
    const cacheKey = `proxima_abertura_${formatarDataParaISO(
      date
    )}_${date.getHours()}_${date.getMinutes()}`;

    // Verificar cache primeiro
    if (proximaAberturaCache.has(cacheKey)) {
      return proximaAberturaCache.get(cacheKey);
    }

    if (this.estaAberto(date)) {
      proximaAberturaCache.set(cacheKey, date);
      return date;
    }

    // busca até LIMITE_BUSCA_DIAS (permite feriados)
    for (let offset = 0; offset <= LIMITE_BUSCA_DIAS; offset++) {
      const cand = new Date(date.getTime());
      cand.setDate(date.getDate() + offset);
      if (this.ehFeriado(cand)) continue;

      const dIdx = diaIndex(cand);
      const intervalos = this.horario[String(dIdx)] ?? [];
      const currentMins = offset === 0 ? minutosDoDia(date) : -1;
      let best: number | null = null;

      for (const iv of intervalos) {
        const o = horaParaMinutos(iv.abertura);
        if (offset === 0) {
          if (o >= currentMins && (best === null || o < best)) {
            best = o;
          }
        } else if (best === null || o < best) {
          best = o;
        }
      }

      if (best !== null) {
        const res = new Date(cand.getTime());
        res.setHours(Math.floor(best / 60), best % 60, 0, 0);
        proximaAberturaCache.set(cacheKey, res);
        return res;
      }
    }

    proximaAberturaCache.set(cacheKey, null);
    return null;
  };

  /**
   * Obtém a próxima data/hora de fechamento do estabelecimento.
   * @param dt - Data de referência para busca (padrão: data atual)
   * @returns Data do próximo fechamento ou null se não encontrada
   * @throws Error se a data for inválida
   */
  proximoFechamento = (dt: Date | string = new Date()): Date | null => {
    const date = typeof dt === "string" ? new Date(dt) : new Date(dt.getTime());
    if (Number.isNaN(date.getTime())) {
      throw new Error("Data inválida");
    }
    if (this.ehFeriado(date)) return null;

    const dia = diaIndex(date);
    const mins = minutosDoDia(date);
    const intervalos = this.horario[String(dia)] ?? [];

    for (const iv of intervalos) {
      const o = horaParaMinutos(iv.abertura);
      const c = horaParaMinutos(iv.fechamento);

      if (c > o) {
        if (mins >= o && mins < c) {
          const res = new Date(date.getTime());
          res.setHours(Math.floor(c / 60), c % 60, 0, 0);
          return res;
        }
      } else {
        // overnight
        if (mins >= o) {
          const res = new Date(date.getTime());
          res.setDate(date.getDate() + 1);
          res.setHours(Math.floor(c / 60), c % 60, 0, 0);
          return res;
        } else if (mins < c) {
          const res = new Date(date.getTime());
          res.setHours(Math.floor(c / 60), c % 60, 0, 0);
          return res;
        }
      }
    }

    // se não estiver aberto, pega a próxima abertura e calcula fechamento
    const na = this.proximaAbertura(date);
    if (!na) return null;

    const dIdx = diaIndex(na);
    const intervalosNext = this.horario[String(dIdx)] ?? [];

    for (const iv of intervalosNext) {
      const o = horaParaMinutos(iv.abertura);
      if (o === na.getHours() * 60 + na.getMinutes()) {
        const c = horaParaMinutos(iv.fechamento);
        const res = new Date(na.getTime());
        if (c > o) {
          res.setHours(Math.floor(c / 60), c % 60, 0, 0);
        } else {
          res.setDate(res.getDate() + 1);
          res.setHours(Math.floor(c / 60), c % 60, 0, 0);
        }
        return res;
      }
    }
    return na;
  };

  /**
   * Adiciona minutos úteis (dentro do horário comercial) a uma data.
   * @param dt - Data base para o cálculo (padrão: data atual)
   * @param minutosAdicionar - Número de minutos úteis a adicionar (padrão: 0)
   * @returns Nova data com os minutos úteis adicionados
   * @throws Error se a data for inválida ou não encontrar próxima abertura
   */
  adicionarMinutosUteis = (
    dt: Date | string = new Date(),
    minutosAdicionar: number = 0
  ): Date => {
    if (minutosAdicionar === 0) {
      return typeof dt === "string" ? new Date(dt) : new Date(dt.getTime());
    }

    let cursor = typeof dt === "string" ? new Date(dt) : new Date(dt.getTime());
    if (Number.isNaN(cursor.getTime())) {
      throw new Error("Data inválida");
    }

    if (!this.estaAberto(cursor)) {
      const no = this.proximaAbertura(cursor);
      if (!no) throw new Error("Não foi encontrada próxima abertura");
      cursor = no;
    }

    let restante = minutosAdicionar;
    while (restante > 0) {
      const fechamento = this.proximoFechamento(cursor);
      if (!fechamento)
        throw new Error("Não foi encontrado fechamento durante cálculo");

      const disponivel = Math.floor(
        (fechamento.getTime() - cursor.getTime()) / 60000
      );
      if (disponivel >= restante) {
        cursor = new Date(cursor.getTime() + restante * 60000);
        restante = 0;
        break;
      } else {
        restante -= disponivel;
        cursor = new Date(fechamento.getTime() + 1000);
        const no = this.proximaAbertura(cursor);
        if (!no)
          throw new Error(
            "Não foi encontrada próxima abertura durante cálculo"
          );
        cursor = no;
      }
    }
    return cursor;
  };

  /**
   * Calcula quantos minutos restam de horário comercial no dia atual.
   * @param dt - Data de referência (padrão: data atual)
   * @returns Número de minutos restantes no dia atual
   */
  minutosRestantesHoje = (dt: Date | string = new Date()): number => {
    const date = typeof dt === "string" ? new Date(dt) : new Date(dt.getTime());
    if (!this.estaAberto(date)) return 0;

    const fechamento = this.proximoFechamento(date);
    if (!fechamento) return 0;

    return Math.max(
      0,
      Math.floor((fechamento.getTime() - date.getTime()) / 60000)
    );
  };

  /**
   * Obtém uma cópia da configuração de horário comercial atual.
   * @returns Cópia da configuração de horários por dia da semana
   */
  obterHorario = (): Horario => {
    return structuredClone(this.horario);
  };

  /**
   * Limpa todos os caches quando necessário.
   * Útil para forçar recálculo de valores em cache.
   */
  limparCache = (): void => {
    horarioCache.clear();
    proximaAberturaCache.clear();
  };
}
