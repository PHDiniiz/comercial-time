/**
 * Performance Layer - Cache Manager
 *
 * Sistema de cache para otimizar performance de operações
 * frequentes como verificação de horários e cálculos de datas.
 */

/**
 * Gerenciador de cache genérico com TTL (Time To Live).
 * Implementa um sistema de cache em memória com expiração automática.
 * @template T - Tipo dos valores armazenados no cache
 */
export class CacheManager<T> {
  private readonly cache = new Map<string, { value: T; timestamp: number }>();
  private readonly ttl: number;

  /**
   * Constrói uma nova instância do gerenciador de cache.
   * @param ttlMs - Tempo de vida dos itens em milissegundos (padrão: 60000ms = 1 minuto)
   */
  constructor(ttlMs: number = 60000) {
    // 1 minuto por padrão
    this.ttl = ttlMs;
  }

  /**
   * Obtém um valor do cache por chave.
   * @param key - Chave do item no cache
   * @returns Valor armazenado ou null se não existir ou expirado
   */
  get(key: string): T | null {
    const item = this.cache.get(key);
    if (!item) return null;

    const now = Date.now();
    if (now - item.timestamp > this.ttl) {
      this.cache.delete(key);
      return null;
    }

    return item.value;
  }

  /**
   * Armazena um valor no cache com timestamp atual.
   * @param key - Chave para armazenar o valor
   * @param value - Valor a ser armazenado
   */
  set(key: string, value: T): void {
    this.cache.set(key, {
      value,
      timestamp: Date.now(),
    });
  }

  /**
   * Verifica se uma chave existe no cache e não expirou.
   * @param key - Chave a ser verificada
   * @returns true se a chave existe e não expirou, false caso contrário
   */
  has(key: string): boolean {
    const item = this.cache.get(key);
    if (!item) return false;

    const now = Date.now();
    if (now - item.timestamp > this.ttl) {
      this.cache.delete(key);
      return false;
    }

    return true;
  }

  /**
   * Remove todos os itens do cache.
   */
  clear(): void {
    this.cache.clear();
  }

  /**
   * Remove itens expirados do cache para liberar memória.
   */
  cleanup(): void {
    const now = Date.now();
    for (const [key, item] of this.cache.entries()) {
      if (now - item.timestamp > this.ttl) {
        this.cache.delete(key);
      }
    }
  }

  /**
   * Obtém o número de itens atualmente no cache.
   * @returns Número de itens no cache
   */
  size(): number {
    return this.cache.size;
  }
}

/** Cache global para operações de horário comercial (30 segundos de TTL) */
export const horarioCache = new CacheManager<boolean>(30000); // 30 segundos

/** Cache global para próximas aberturas (1 minuto de TTL) */
export const proximaAberturaCache = new CacheManager<Date | null>(60000); // 1 minuto
