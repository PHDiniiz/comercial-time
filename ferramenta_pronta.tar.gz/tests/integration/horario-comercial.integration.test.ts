/**
 * Testes de Integração
 * 
 * Testes que verificam a integração entre diferentes camadas
 * e o funcionamento completo da aplicação.
 */

import { HorarioComercialFactory } from "../../src/presentation/factories/horario-comercial.factory.js";
import { HorarioComercial } from "../../src/legacy/horario-comercial.legacy.js";

describe("HorarioComercial Integration Tests", () => {
  const horarioComercial = new HorarioComercial({
    segunda: { abertura: "08:00", fechamento: "18:00" },
    terca: { abertura: "08:00", fechamento: "18:00" },
    quarta: { abertura: "08:00", fechamento: "18:00" },
    quinta: { abertura: "08:00", fechamento: "18:00" },
    sexta: { abertura: "08:00", fechamento: "18:00" },
  }, ["2024-12-25", "2024-01-01"]);

  describe("Funcionalidade Básica", () => {
    it("deve verificar se está aberto em horário comercial", () => {
      const dataAberta = new Date("2024-01-08T10:00:00"); // Segunda-feira, 10h
      expect(horarioComercial.estaAberto(dataAberta)).toBe(true);
    });

    it("deve verificar se está fechado fora do horário comercial", () => {
      const dataFechada = new Date("2024-01-08T20:00:00"); // Segunda-feira, 20h
      expect(horarioComercial.estaAberto(dataFechada)).toBe(false);
    });

    it("deve verificar se está fechado em feriados", () => {
      const dataFeriado = new Date("2024-12-25T10:00:00"); // Natal, 10h
      expect(horarioComercial.estaAberto(dataFeriado)).toBe(false);
    });

    it("deve ter propriedade openedNow", () => {
      expect(typeof horarioComercial.openedNow).toBe('boolean');
    });

    it("deve retornar status atual baseado no timezone", () => {
      const status = horarioComercial.openedNow;
      expect(typeof status).toBe('boolean');
    });
  });

  describe("Próxima Abertura", () => {
    it("deve retornar próxima abertura quando fechado", () => {
      const dataFechada = new Date("2024-01-08T20:00:00"); // Segunda-feira, 20h
      const proximaAbertura = horarioComercial.proximaAbertura(dataFechada);
      
      expect(proximaAbertura).not.toBeNull();
      expect(proximaAbertura?.getDay()).toBe(1); // Próxima segunda
      expect(proximaAbertura?.getHours()).toBe(8); // 8h
    });
  });

  describe("Adicionar Minutos Úteis", () => {
    it("deve adicionar minutos úteis corretamente", () => {
      const dataInicial = new Date("2024-01-08T14:00:00"); // Segunda-feira, 14h
      const dataFinal = horarioComercial.adicionarMinutosUteis(dataInicial, 120); // +2 horas
      
      expect(dataFinal.getHours()).toBe(16); // 16h
      expect(dataFinal.getMinutes()).toBe(0);
    });

    it("deve pular fins de semana ao adicionar minutos úteis", () => {
      const sextaTarde = new Date("2024-01-12T17:00:00"); // Sexta-feira, 17h
      const dataFinal = horarioComercial.adicionarMinutosUteis(sextaTarde, 120); // +2 horas
      
      // Deve ir para a próxima segunda-feira
      expect(dataFinal.getDay()).toBe(1); // Segunda-feira
      expect(dataFinal.getHours()).toBe(10); // 10h (8h + 2h)
    });
  });

  describe("Factory Pattern", () => {
    it("deve criar instâncias corretamente", () => {
      const { service, useCase, controller } = HorarioComercialFactory.create({
        segunda: { abertura: "09:00", fechamento: "17:00" },
      });

      expect(service).toBeDefined();
      expect(useCase).toBeDefined();
      expect(controller).toBeDefined();
    });

    it("deve funcionar com controller", () => {
      const { controller } = HorarioComercialFactory.create({
        segunda: { abertura: "09:00", fechamento: "17:00" },
      });

      const status = controller.verificarStatus(new Date("2024-01-08T10:00:00"));
      
      expect(status.estaAberto).toBe(true);
      expect(status.minutosRestantes).toBeGreaterThan(0);
    });
  });
});
