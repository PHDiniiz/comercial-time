/**
 * Testes para funcionalidades de feriados personalizados via URL
 */

// Jest imports
import {
  carregarFeriadosPersonalizados,
  carregarFeriadosPersonalizadosDeUrl,
  feriadosPersonalizadosDisponiveis,
  obterInfoFeriadosPersonalizados,
} from "../../src/infrastructure/utils/locale.util";

// Mock do fetch
global.fetch = jest.fn();

describe("Feriados Personalizados via URL", () => {
  beforeEach(() => {
    // Limpar variáveis de ambiente
    delete process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON;
    // Limpar mocks
    jest.clearAllMocks();
  });

  afterEach(() => {
    // Limpar variáveis de ambiente
    delete process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON;
  });

  describe("carregarFeriadosPersonalizadosDeUrl", () => {
    it("deve carregar feriados de URL válida com formato novo", async () => {
      const mockResponse = {
        ok: true,
        text: jest.fn().mockResolvedValue(
          JSON.stringify({
            nacionais: [
              {
                nome: "Dia da Empresa",
                data: "2025-03-15",
                observacoes: "Aniversário da empresa",
              },
            ],
            estaduais: {
              SP: [
                {
                  nome: "Feriado SP",
                  data: "2025-07-09",
                  observacoes: "Feriado estadual",
                },
              ],
            },
          })
        ),
      };

      (global.fetch as any).mockResolvedValue(mockResponse);

      const result = await carregarFeriadosPersonalizadosDeUrl(
        "https://api.exemplo.com/feriados.json"
      );

      expect(result).toEqual({
        nacionais: [
          {
            nome: "Dia da Empresa",
            data: "2025-03-15",
            observacoes: "Aniversário da empresa",
          },
        ],
        estaduais: {
          SP: [
            {
              nome: "Feriado SP",
              data: "2025-07-09",
              observacoes: "Feriado estadual",
            },
          ],
        },
      });
    });

    it("deve carregar feriados de URL válida com formato antigo (array)", async () => {
      const mockResponse = {
        ok: true,
        text: jest.fn().mockResolvedValue(
          JSON.stringify([
            {
              nome: "Dia da Empresa",
              data: "2025-03-15",
              observacoes: "Aniversário da empresa",
            },
          ])
        ),
      };

      (global.fetch as any).mockResolvedValue(mockResponse);

      const result = await carregarFeriadosPersonalizadosDeUrl(
        "https://api.exemplo.com/feriados.json"
      );

      expect(result).toEqual({
        nacionais: [
          {
            nome: "Dia da Empresa",
            data: "2025-03-15",
            observacoes: "Aniversário da empresa",
          },
        ],
        estaduais: {},
      });
    });

    it("deve retornar null para URL inválida", async () => {
      const result = await carregarFeriadosPersonalizadosDeUrl("not-a-url");
      expect(result).toBeNull();
    });

    it("deve retornar null para resposta HTTP não OK", async () => {
      const mockResponse = {
        ok: false,
        status: 404,
        statusText: "Not Found",
      };

      (global.fetch as any).mockResolvedValue(mockResponse);

      const result = await carregarFeriadosPersonalizadosDeUrl(
        "https://api.exemplo.com/feriados.json"
      );
      expect(result).toBeNull();
    });

    it("deve retornar null para JSON inválido", async () => {
      const mockResponse = {
        ok: true,
        text: jest.fn().mockResolvedValue("invalid json"),
      };

      (global.fetch as any).mockResolvedValue(mockResponse);

      const result = await carregarFeriadosPersonalizadosDeUrl(
        "https://api.exemplo.com/feriados.json"
      );
      expect(result).toBeNull();
    });

    it("deve retornar null para feriado sem campos obrigatórios", async () => {
      const mockResponse = {
        ok: true,
        text: jest.fn().mockResolvedValue(
          JSON.stringify([
            {
              nome: "Dia da Empresa",
              // data e observacoes faltando
            },
          ])
        ),
      };

      (global.fetch as any).mockResolvedValue(mockResponse);

      const result = await carregarFeriadosPersonalizadosDeUrl(
        "https://api.exemplo.com/feriados.json"
      );
      expect(result).toBeNull();
    });

    it("deve retornar null para erro de rede", async () => {
      (global.fetch as any).mockRejectedValue(new Error("Network error"));

      const result = await carregarFeriadosPersonalizadosDeUrl(
        "https://api.exemplo.com/feriados.json"
      );
      expect(result).toBeNull();
    });
  });

  describe("carregarFeriadosPersonalizados (assíncrono)", () => {
    it("deve carregar feriados de URL quando PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON é URL", async () => {
      process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON =
        "https://api.exemplo.com/feriados.json";

      const mockResponse = {
        ok: true,
        text: jest.fn().mockResolvedValue(
          JSON.stringify({
            nacionais: [
              {
                nome: "Dia da Empresa",
                data: "2025-03-15",
                observacoes: "Aniversário da empresa",
              },
            ],
            estaduais: {},
          })
        ),
      };

      (global.fetch as any).mockResolvedValue(mockResponse);

      const result = await carregarFeriadosPersonalizados();

      expect(result).toEqual({
        nacionais: [
          {
            nome: "Dia da Empresa",
            data: "2025-03-15",
            observacoes: "Aniversário da empresa",
          },
        ],
        estaduais: {},
      });
    });

    it("deve carregar feriados de JSON quando PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON é JSON", async () => {
      process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON = JSON.stringify({
        nacionais: [
          {
            nome: "Dia da Empresa",
            data: "2025-03-15",
            observacoes: "Aniversário da empresa",
          },
        ],
        estaduais: {},
      });

      const result = await carregarFeriadosPersonalizados();

      expect(result).toEqual({
        nacionais: [
          {
            nome: "Dia da Empresa",
            data: "2025-03-15",
            observacoes: "Aniversário da empresa",
          },
        ],
        estaduais: {},
      });
    });

    it("deve retornar null quando PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON é vazio", async () => {
      process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON = "";

      const result = await carregarFeriadosPersonalizados();
      expect(result).toBeNull();
    });

    it("deve retornar null quando PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON é undefined", async () => {
      delete process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON;

      const result = await carregarFeriadosPersonalizados();
      expect(result).toBeNull();
    });

    it("deve retornar null quando PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON é inválido", async () => {
      process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON = "invalid-value";

      const result = await carregarFeriadosPersonalizados();
      expect(result).toBeNull();
    });
  });

  describe("feriadosPersonalizadosDisponiveis", () => {
    it("deve retornar true para URL válida", () => {
      process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON =
        "https://api.exemplo.com/feriados.json";

      const result = feriadosPersonalizadosDisponiveis();
      expect(result).toBe(true);
    });

    it("deve retornar true para JSON válido", () => {
      process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON = JSON.stringify([
        {
          nome: "Dia da Empresa",
          data: "2025-03-15",
          observacoes: "Aniversário da empresa",
        },
      ]);

      const result = feriadosPersonalizadosDisponiveis();
      expect(result).toBe(true);
    });

    it("deve retornar false para valor vazio", () => {
      process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON = "";

      const result = feriadosPersonalizadosDisponiveis();
      expect(result).toBe(false);
    });

    it("deve retornar false para valor undefined", () => {
      delete process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON;

      const result = feriadosPersonalizadosDisponiveis();
      expect(result).toBe(false);
    });

    it("deve retornar false para valor inválido", () => {
      process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON = "invalid-value";

      const result = feriadosPersonalizadosDisponiveis();
      expect(result).toBe(false);
    });
  });

  describe("obterInfoFeriadosPersonalizados", () => {
    it("deve retornar info para URL válida", () => {
      process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON =
        "https://api.exemplo.com/feriados.json";

      const result = obterInfoFeriadosPersonalizados();

      expect(result).toEqual({
        disponivel: true,
        quantidadeNacionais: 0,
        quantidadeEstaduais: 0,
        total: 0,
        estadosDisponiveis: [],
      });
    });

    it("deve retornar info para JSON válido", () => {
      process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON = JSON.stringify({
        nacionais: [
          {
            nome: "Dia da Empresa",
            data: "2025-03-15",
            observacoes: "Aniversário da empresa",
          },
        ],
        estaduais: {
          SP: [
            {
              nome: "Feriado SP",
              data: "2025-07-09",
              observacoes: "Feriado estadual",
            },
          ],
        },
      });

      const result = obterInfoFeriadosPersonalizados();

      expect(result).toEqual({
        disponivel: true,
        quantidadeNacionais: 1,
        quantidadeEstaduais: 1,
        total: 2,
        exemploNacional: {
          nome: "Dia da Empresa",
          data: "2025-03-15",
          observacoes: "Aniversário da empresa",
        },
        exemploEstadual: {
          nome: "Feriado SP",
          data: "2025-07-09",
          observacoes: "Feriado estadual",
        },
        estadosDisponiveis: ["SP"],
      });
    });

    it("deve retornar info vazia para valor inválido", () => {
      process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON = "invalid-value";

      const result = obterInfoFeriadosPersonalizados();

      expect(result).toEqual({
        disponivel: false,
        quantidadeNacionais: 0,
        quantidadeEstaduais: 0,
        total: 0,
        estadosDisponiveis: [],
      });
    });
  });
});
