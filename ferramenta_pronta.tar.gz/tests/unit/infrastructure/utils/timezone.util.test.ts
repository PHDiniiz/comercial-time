/**
 * Unit Tests - Timezone Utilities
 */

import { describe, it, expect, beforeEach, vi } from "@jest/globals";
import {
  toCurrentTimezone,
  getTimezoneOffset,
  isValidTimezone,
  getNowInTimezone,
  formatDateInTimezone,
  getTimeInTimezone,
  getDateInTimezone,
  getDayOfWeekInTimezone,
  getDayNameInTimezone,
  createDateInTimezone,
  compareDatesInTimezone,
  isTodayInTimezone,
  isFutureInTimezone,
  isPastInTimezone,
} from "../../../src/infrastructure/utils/timezone.util.js";

describe("Timezone Utilities", () => {
  beforeEach(() => {
    // Mock timezone manager to use a consistent timezone for tests
    vi.spyOn(
      require("../../../src/config/timezone.config.js"),
      "getCurrentTimezone"
    ).mockReturnValue("America/Sao_Paulo");
  });

  describe("toCurrentTimezone", () => {
    it("should convert Date to current timezone", () => {
      const utcDate = new Date("2024-01-08T14:30:00Z");
      const converted = toCurrentTimezone(utcDate);

      expect(converted).toBeInstanceOf(Date);
      expect(Number.isNaN(converted.getTime())).toBe(false);
    });

    it("should convert string date to current timezone", () => {
      const dateString = "2024-01-08T14:30:00Z";
      const converted = toCurrentTimezone(dateString);

      expect(converted).toBeInstanceOf(Date);
      expect(Number.isNaN(converted.getTime())).toBe(false);
    });

    it("should throw error for invalid date", () => {
      expect(() => {
        toCurrentTimezone("invalid-date");
      }).toThrow("Data inválida fornecida");
    });
  });

  describe("getTimezoneOffset", () => {
    it("should return offset for valid timezone", () => {
      const offset = getTimezoneOffset("America/Sao_Paulo");
      expect(typeof offset).toBe("number");
    });

    it("should return 0 for invalid timezone", () => {
      const offset = getTimezoneOffset("Invalid/Timezone");
      expect(offset).toBe(0);
    });
  });

  describe("isValidTimezone", () => {
    it("should return true for valid timezone", () => {
      expect(isValidTimezone("America/Sao_Paulo")).toBe(true);
      expect(isValidTimezone("Europe/London")).toBe(true);
      expect(isValidTimezone("UTC")).toBe(true);
    });

    it("should return false for invalid timezone", () => {
      expect(isValidTimezone("Invalid/Timezone")).toBe(false);
      expect(isValidTimezone("")).toBe(false);
    });
  });

  describe("getNowInTimezone", () => {
    it("should return current date in timezone", () => {
      const now = getNowInTimezone();
      expect(now).toBeInstanceOf(Date);
      expect(Number.isNaN(now.getTime())).toBe(false);
    });
  });

  describe("formatDateInTimezone", () => {
    it("should format date in timezone", () => {
      const testDate = new Date("2024-01-08T14:30:00Z");
      const formatted = formatDateInTimezone(testDate);

      expect(typeof formatted).toBe("string");
      expect(formatted).toContain("2024");
    });

    it("should format date with custom options", () => {
      const testDate = new Date("2024-01-08T14:30:00Z");
      const formatted = formatDateInTimezone(testDate, {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      });

      expect(typeof formatted).toBe("string");
    });

    it("should throw error for invalid date", () => {
      expect(() => {
        formatDateInTimezone("invalid-date");
      }).toThrow("Data inválida fornecida");
    });
  });

  describe("getTimeInTimezone", () => {
    it("should return time in timezone", () => {
      const testDate = new Date("2024-01-08T14:30:00Z");
      const time = getTimeInTimezone(testDate);

      expect(typeof time).toBe("string");
      expect(time).toMatch(/^\d{2}:\d{2}$/);
    });

    it("should use current date when no date provided", () => {
      const time = getTimeInTimezone();
      expect(typeof time).toBe("string");
      expect(time).toMatch(/^\d{2}:\d{2}$/);
    });
  });

  describe("getDateInTimezone", () => {
    it("should return date in timezone", () => {
      const testDate = new Date("2024-01-08T14:30:00Z");
      const date = getDateInTimezone(testDate);

      expect(typeof date).toBe("string");
      expect(date).toContain("2024");
    });

    it("should use current date when no date provided", () => {
      const date = getDateInTimezone();
      expect(typeof date).toBe("string");
    });
  });

  describe("getDayOfWeekInTimezone", () => {
    it("should return day of week in timezone", () => {
      const testDate = new Date("2024-01-08T14:30:00Z"); // Monday
      const dayOfWeek = getDayOfWeekInTimezone(testDate);

      expect(typeof dayOfWeek).toBe("number");
      expect(dayOfWeek).toBeGreaterThanOrEqual(0);
      expect(dayOfWeek).toBeLessThanOrEqual(6);
    });

    it("should use current date when no date provided", () => {
      const dayOfWeek = getDayOfWeekInTimezone();
      expect(typeof dayOfWeek).toBe("number");
      expect(dayOfWeek).toBeGreaterThanOrEqual(0);
      expect(dayOfWeek).toBeLessThanOrEqual(6);
    });
  });

  describe("getDayNameInTimezone", () => {
    it("should return day name in timezone", () => {
      const testDate = new Date("2024-01-08T14:30:00Z"); // Monday
      const dayName = getDayNameInTimezone(testDate);

      expect(typeof dayName).toBe("string");
      expect([
        "domingo",
        "segunda",
        "terça",
        "quarta",
        "quinta",
        "sexta",
        "sábado",
      ]).toContain(dayName);
    });

    it("should use current date when no date provided", () => {
      const dayName = getDayNameInTimezone();
      expect(typeof dayName).toBe("string");
      expect([
        "domingo",
        "segunda",
        "terça",
        "quarta",
        "quinta",
        "sexta",
        "sábado",
      ]).toContain(dayName);
    });
  });

  describe("createDateInTimezone", () => {
    it("should create date in timezone", () => {
      const date = createDateInTimezone(2024, 1, 8, 14, 30, 0);

      expect(date).toBeInstanceOf(Date);
      expect(Number.isNaN(date.getTime())).toBe(false);
    });

    it("should create date with default time values", () => {
      const date = createDateInTimezone(2024, 1, 8);

      expect(date).toBeInstanceOf(Date);
      expect(Number.isNaN(date.getTime())).toBe(false);
    });
  });

  describe("compareDatesInTimezone", () => {
    it("should compare dates in timezone", () => {
      const date1 = new Date("2024-01-08T14:30:00Z");
      const date2 = new Date("2024-01-08T15:30:00Z");

      const result = compareDatesInTimezone(date1, date2);
      expect(typeof result).toBe("number");
    });

    it("should return 0 for equal dates", () => {
      const date1 = new Date("2024-01-08T14:30:00Z");
      const date2 = new Date("2024-01-08T14:30:00Z");

      const result = compareDatesInTimezone(date1, date2);
      expect(result).toBe(0);
    });
  });

  describe("isTodayInTimezone", () => {
    it("should check if date is today in timezone", () => {
      const today = new Date();
      const result = isTodayInTimezone(today);

      expect(typeof result).toBe("boolean");
    });

    it("should return false for future date", () => {
      const futureDate = new Date();
      futureDate.setDate(futureDate.getDate() + 1);

      const result = isTodayInTimezone(futureDate);
      expect(result).toBe(false);
    });
  });

  describe("isFutureInTimezone", () => {
    it("should check if date is in future in timezone", () => {
      const futureDate = new Date();
      futureDate.setDate(futureDate.getDate() + 1);

      const result = isFutureInTimezone(futureDate);
      expect(result).toBe(true);
    });

    it("should return false for past date", () => {
      const pastDate = new Date();
      pastDate.setDate(pastDate.getDate() - 1);

      const result = isFutureInTimezone(pastDate);
      expect(result).toBe(false);
    });
  });

  describe("isPastInTimezone", () => {
    it("should check if date is in past in timezone", () => {
      const pastDate = new Date();
      pastDate.setDate(pastDate.getDate() - 1);

      const result = isPastInTimezone(pastDate);
      expect(result).toBe(true);
    });

    it("should return false for future date", () => {
      const futureDate = new Date();
      futureDate.setDate(futureDate.getDate() + 1);

      const result = isPastInTimezone(futureDate);
      expect(result).toBe(false);
    });
  });
});
