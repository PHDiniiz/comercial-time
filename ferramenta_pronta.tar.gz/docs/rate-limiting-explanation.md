# Sistema de Rate Limiting com Debounce - Explicação Detalhada

## 🔍 **O que é Rate Limiting?**

Rate Limiting é uma técnica de segurança que **controla a frequência** com que um usuário ou sistema pode fazer requisições para uma API ou serviço. É essencial para:

- **Prevenir ataques de DoS** (Denial of Service)
- **Proteger recursos** do servidor
- **Garantir qualidade de serviço** para todos os usuários
- **Prevenir abuso** da API

## 🎯 **Diferença entre Rate Limiting e Debounce**

### **Rate Limiting (Limitação de Taxa)**
- **Controle de volume**: Limita o **número total** de requisições em um período
- **Janela deslizante**: Conta requisições em uma janela de tempo que "desliza"
- **Exemplo**: Máximo 100 requisições por minuto

### **Debounce (Anti-Repetition)**
- **Controle de frequência**: Previne requisições **muito próximas** no tempo
- **Intervalo mínimo**: Força um tempo mínimo entre requisições
- **Exemplo**: Máximo 1 requisição por segundo

## 🏗️ **Arquitetura do Sistema Implementado**

### **1. Rate Limiting Básico (Sliding Window)**
```typescript
// Configuração: 100 requisições por minuto
const limiter = new AdvancedRateLimiter({
  maxRequests: 100,
  windowMs: 60000, // 1 minuto
});

// Como funciona:
// - Mantém um array de timestamps das requisições
// - Remove timestamps antigos (fora da janela)
// - Verifica se o número atual excede o limite
```

### **2. Debounce (Prevenção de Spam)**
```typescript
// Configuração: 1 requisição por segundo
const limiter = new AdvancedRateLimiter({
  debounceMs: 1000, // 1 segundo
});

// Como funciona:
// - Armazena o timestamp da última requisição
// - Bloqueia requisições se o intervalo for menor que debounceMs
// - Útil para prevenir cliques duplos ou spam
```

### **3. Throttle (Suavização de Picos)**
```typescript
// Configuração: 1 requisição a cada 100ms
const limiter = new AdvancedRateLimiter({
  throttleMs: 100, // 100ms
});

// Como funciona:
// - Similar ao debounce, mas com intervalo menor
// - Suaviza picos de tráfego
// - Permite tráfego constante mas controlado
```

### **4. Circuit Breaker (Proteção contra Falhas)**
```typescript
// Configuração: Abre após 5 falhas, timeout de 30s
const limiter = new AdvancedRateLimiter({
  circuitBreakerThreshold: 5,
  circuitBreakerTimeout: 30000,
});

// Como funciona:
// - Conta falhas consecutivas
// - Abre o "circuito" após muitas falhas
// - Bloqueia requisições temporariamente
// - Permite tentativas após o timeout
```

## 📊 **Exemplo Prático de Funcionamento**

### **Cenário: Usuário fazendo requisições para verificar horário comercial**

```typescript
// Configuração para operações de horário comercial
const config = {
  maxRequests: 1000,  // 1000 requests por minuto
  windowMs: 60000,    // 1 minuto
  debounceMs: 100,    // 100ms de debounce
  throttleMs: 50,     // 50ms de throttle
};

const limiter = new AdvancedRateLimiter(config);
const user = 'user123';

// Simulação de requisições
console.log(limiter.isAllowed(user)); // ✅ true (primeira requisição)
console.log(limiter.isAllowed(user)); // ❌ false (debounce - muito rápido)
// ... aguarda 100ms ...
console.log(limiter.isAllowed(user)); // ✅ true (debounce passou)
```

### **Resultado da Verificação:**
```typescript
{
  allowed: false,
  reason: 'debounce',
  retryAfter: 75, // ms para tentar novamente
  stats: {
    count: 1,
    resetTime: 1640995200000,
    debounceTime: 75
  }
}
```

## 🎛️ **Configurações por Cenário**

### **1. Operações de Horário Comercial (Menos Restritivo)**
```typescript
HORARIO_COMERCIAL: {
  maxRequests: 1000,  // 1000 requests por minuto
  windowMs: 60000,    // 1 minuto
  debounceMs: 100,    // 100ms de debounce
  throttleMs: 50,     // 50ms de throttle
}
```
**Uso**: Verificações frequentes de horário comercial
**Justificativa**: Operação comum, precisa ser rápida

### **2. Operações de Validação (Moderadamente Restritivo)**
```typescript
VALIDACAO: {
  maxRequests: 100,   // 100 requests por minuto
  windowMs: 60000,    // 1 minuto
  debounceMs: 500,    // 500ms de debounce
  throttleMs: 200,    // 200ms de throttle
}
```
**Uso**: Validação de dados de entrada
**Justificativa**: Previne spam de validações

### **3. Operações Administrativas (Muito Restritivo)**
```typescript
ADMIN: {
  maxRequests: 10,    // 10 requests por minuto
  windowMs: 60000,    // 1 minuto
  debounceMs: 2000,   // 2 segundos de debounce
  throttleMs: 1000,   // 1 segundo de throttle
}
```
**Uso**: Configurações sensíveis do sistema
**Justificativa**: Operações críticas, precisam de proteção máxima

## 🔧 **Integração com Decorators**

```typescript
class HorarioComercialService {
  @withRateLimit('horario')
  estaAberto(data: Date): boolean {
    // Método automaticamente protegido por rate limiting
    return this.checkHorario(data);
  }

  @withRateLimit('validacao')
  validarHorario(horario: string): boolean {
    // Método com rate limiting mais restritivo
    return this.validateTime(horario);
  }
}
```

## 📈 **Benefícios do Sistema Implementado**

### **1. Proteção Multi-Camada**
- ✅ **Rate Limiting**: Previne sobrecarga
- ✅ **Debounce**: Previne spam
- ✅ **Throttle**: Suaviza picos
- ✅ **Circuit Breaker**: Protege contra falhas

### **2. Flexibilidade**
- ✅ **Configuração por cenário**: Diferentes limites para diferentes operações
- ✅ **Identificação por usuário**: Controle individual
- ✅ **Estatísticas detalhadas**: Monitoramento completo

### **3. Performance**
- ✅ **Sliding Window**: Eficiente em memória
- ✅ **Cleanup automático**: Remove dados antigos
- ✅ **Cache inteligente**: Reduz cálculos repetitivos

### **4. Segurança**
- ✅ **Proteção contra DoS**: Limita requisições maliciosas
- ✅ **Prevenção de spam**: Debounce evita cliques duplos
- ✅ **Circuit Breaker**: Protege contra falhas em cascata

## 🚨 **Cenários de Proteção**

### **1. Ataque de Força Bruta**
```typescript
// Atacante tenta 1000 requisições por segundo
for (let i = 0; i < 1000; i++) {
  const result = limiter.isAllowed('attacker');
  // Apenas as primeiras 1000 por minuto são permitidas
  // Resto é bloqueado por rate limiting
}
```

### **2. Spam de Cliques**
```typescript
// Usuário clica rapidamente no botão
button.addEventListener('click', () => {
  const result = limiter.isAllowed('user123');
  if (result.allowed) {
    // Apenas o primeiro clique é processado
    // Cliques subsequentes são bloqueados por debounce
  }
});
```

### **3. Falhas em Cascata**
```typescript
// Sistema começa a falhar
for (let i = 0; i < 10; i++) {
  try {
    limiter.recordFailure('service');
    // Após 5 falhas, circuit breaker abre
    // Próximas requisições são bloqueadas por 30 segundos
  } catch (error) {
    // Sistema se protege automaticamente
  }
}
```

## 📊 **Monitoramento e Estatísticas**

```typescript
// Estatísticas globais
const stats = manager.getGlobalStats();
console.log(stats);
// {
//   horario: { activeIdentifiers: 150, totalRequests: 5000, circuitBreakersOpen: 0 },
//   validacao: { activeIdentifiers: 50, totalRequests: 800, circuitBreakersOpen: 1 },
//   admin: { activeIdentifiers: 5, totalRequests: 20, circuitBreakersOpen: 0 }
// }
```

## 🎯 **Resumo**

O sistema de Rate Limiting implementado **NÃO é apenas debounce**, mas sim um **sistema completo de proteção** que inclui:

1. **Rate Limiting** (controle de volume)
2. **Debounce** (controle de frequência)
3. **Throttle** (suavização de picos)
4. **Circuit Breaker** (proteção contra falhas)

Cada componente tem um propósito específico e trabalha em conjunto para criar uma **proteção robusta e flexível** contra diferentes tipos de ataques e abusos.
