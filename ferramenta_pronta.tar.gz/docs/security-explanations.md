# Explicação Detalhada das Validações de Segurança

## 🔒 **Rate Limiting: Como Funciona?**

### **1. Rate Limiting NÃO é Debounce**

**Rate Limiting** e **Debounce** são conceitos diferentes:

#### **Rate Limiting (Sliding Window)**
```typescript
// Configuração: 3 requisições em 10 segundos
const limiter = new AdvancedRateLimiter({
  maxRequests: 3,    // Máximo 3 requisições
  windowMs: 10000,   // Em 10 segundos
  debounceMs: 0,     // SEM debounce
});

// Como funciona:
// - Mantém um array de timestamps: [1000, 2000, 3000]
// - Remove timestamps antigos: [2000, 3000, 4000]
// - Verifica se array.length < maxRequests
```

#### **Debounce (Anti-Repetition)**
```typescript
// Configuração: 1 requisição por segundo
const limiter = new AdvancedRateLimiter({
  debounceMs: 1000,  // 1 segundo de debounce
});

// Como funciona:
// - Armazena timestamp da última requisição
// - Bloqueia se (now - lastRequest) < debounceMs
```

### **2. Exemplo Prático de Rate Limiting**

```typescript
// Cenário: Usuário fazendo requisições
const limiter = new AdvancedRateLimiter({
  maxRequests: 3,
  windowMs: 10000, // 10 segundos
});

// Tentativa 1: ✅ PERMITIDA (1/3)
limiter.isAllowed("user1"); // { allowed: true }

// Tentativa 2: ✅ PERMITIDA (2/3)
limiter.isAllowed("user1"); // { allowed: true }

// Tentativa 3: ✅ PERMITIDA (3/3)
limiter.isAllowed("user1"); // { allowed: true }

// Tentativa 4: ❌ BLOQUEADA (4/3 - excedeu limite)
limiter.isAllowed("user1"); // { allowed: false, reason: "rate_limit" }

// Após 10 segundos: ✅ PERMITIDA (janela deslizou)
limiter.isAllowed("user1"); // { allowed: true }
```

### **3. Exemplo Prático de Debounce**

```typescript
// Cenário: Usuário clicando rapidamente
const limiter = new AdvancedRateLimiter({
  debounceMs: 1000, // 1 segundo
});

// Clique 1: ✅ PERMITIDA
limiter.isAllowed("user1"); // { allowed: true }

// Clique 2 (500ms depois): ❌ BLOQUEADA (muito rápido)
limiter.isAllowed("user1"); // { allowed: false, reason: "debounce", retryAfter: 500 }

// Clique 3 (1.5s depois): ✅ PERMITIDA (debounce passou)
limiter.isAllowed("user1"); // { allowed: true }
```

## 🛡️ **DoS Prevention: O que é Limitado?**

### **1. Proteção Multi-Camada**

O sistema implementa **4 camadas de proteção** contra DoS:

#### **Camada 1: Rate Limiting (Volume)**
```typescript
// Limita número total de requisições
{
  maxRequests: 1000,  // Máximo 1000 requisições
  windowMs: 60000,    // Por minuto
}
```
**Protege contra**: Ataques de força bruta, spam massivo

#### **Camada 2: Debounce (Frequência)**
```typescript
// Previne requisições muito próximas
{
  debounceMs: 100,    // Máximo 1 requisição por 100ms
}
```
**Protege contra**: Cliques duplos, spam de botões

#### **Camada 3: Throttle (Suavização)**
```typescript
// Suaviza picos de tráfego
{
  throttleMs: 50,     // Máximo 1 requisição por 50ms
}
```
**Protege contra**: Picos de tráfego, burst attacks

#### **Camada 4: Circuit Breaker (Falhas)**
```typescript
// Protege contra falhas em cascata
{
  circuitBreakerThreshold: 5,    // Após 5 falhas
  circuitBreakerTimeout: 30000,  // Bloqueia por 30s
}
```
**Protege contra**: Falhas em cascata, sobrecarga do sistema

### **2. Input Validation (Entrada Maliciosa)**

#### **Validação de Horários**
```typescript
// Bloqueia caracteres perigosos
const dangerousChars = /[<>'"&;(){}[\]\\|`~!@#$%^*+=]/;

// Exemplos bloqueados:
"08:00<script>alert('xss')</script>"  // ❌ XSS
"12:30'; DROP TABLE users; --"        // ❌ SQL Injection
"15:45&malicious=1"                   // ❌ Parameter Pollution
"25:00"                               // ❌ Hora inválida
"12:60"                               // ❌ Minuto inválido

// Exemplos permitidos:
"08:00"                               // ✅ Válido
"23:59"                               // ✅ Válido
"00:00"                               // ✅ Válido
```

#### **Validação de Datas**
```typescript
// Limita datas para prevenir DoS
const minDate = new Date(1900, 0, 1);
const maxDate = new Date(2100, 11, 31);

// Exemplos bloqueados:
"1800-01-01"                          // ❌ Muito antiga
"2200-01-01"                          // ❌ Muito futura
"invalid-date"                        // ❌ Formato inválido

// Exemplos permitidos:
"2024-01-08"                          // ✅ Válida
"1990-12-25"                          // ✅ Válida
```

#### **Validação de Arrays**
```typescript
// Limita tamanho de arrays
if (feriados.length > 1000) {
  return false; // ❌ Muitos feriados (possível DoS)
}

// Exemplos bloqueados:
Array(1001).fill("2024-01-01")        // ❌ Array muito grande
["invalid-date", "2024-13-01"]        // ❌ Datas inválidas
```

### **3. Sanitização de Entrada**

```typescript
// Remove caracteres perigosos
static sanitizeString(input: string): string {
  return input
    .replace(/[<>'"&;(){}[\]\\|`~!@#$%^*+=]/g, "")  // Remove caracteres perigosos
    .trim()                                          // Remove espaços
    .slice(0, 100);                                  // Limita tamanho
}

// Exemplos:
"test<script>alert('xss')</script>"  // → "test"
"  hello world  "                    // → "hello world"
"a".repeat(150)                      // → "a".repeat(100)
```

## 📊 **Configurações por Cenário**

### **1. Operações de Horário Comercial (Menos Restritivo)**
```typescript
HORARIO_COMERCIAL: {
  maxRequests: 1000,  // 1000 requests por minuto
  windowMs: 60000,    // 1 minuto
  debounceMs: 100,    // 100ms de debounce
  throttleMs: 50,     // 50ms de throttle
}
```
**Justificativa**: Operação comum, precisa ser rápida

### **2. Operações de Validação (Moderadamente Restritivo)**
```typescript
VALIDACAO: {
  maxRequests: 100,   // 100 requests por minuto
  windowMs: 60000,    // 1 minuto
  debounceMs: 500,    // 500ms de debounce
  throttleMs: 200,    // 200ms de throttle
}
```
**Justificativa**: Previne spam de validações

### **3. Operações Administrativas (Muito Restritivo)**
```typescript
ADMIN: {
  maxRequests: 10,    // 10 requests por minuto
  windowMs: 60000,    // 1 minuto
  debounceMs: 2000,   // 2 segundos de debounce
  throttleMs: 1000,   // 1 segundo de throttle
}
```
**Justificativa**: Operações críticas, precisam de proteção máxima

## 🎯 **Cenários de Ataque e Proteção**

### **1. Ataque de Força Bruta**
```typescript
// Atacante tenta 1000 requisições por segundo
for (let i = 0; i < 1000; i++) {
  const result = limiter.isAllowed("attacker");
  // Apenas as primeiras 1000 por minuto são permitidas
  // Resto é bloqueado por rate limiting
}
```

### **2. Spam de Cliques**
```typescript
// Usuário clica rapidamente no botão
button.addEventListener("click", () => {
  const result = limiter.isAllowed("user123");
  if (result.allowed) {
    // Apenas o primeiro clique é processado
    // Cliques subsequentes são bloqueados por debounce
  }
});
```

### **3. Injection Attacks**
```typescript
// Tentativa de XSS
const maliciousInput = "08:00<script>alert('xss')</script>";
const isValid = InputValidator.validateHorarioInput(maliciousInput);
// ❌ BLOQUEADA - caracteres perigosos detectados
```

### **4. Falhas em Cascata**
```typescript
// Sistema começa a falhar
for (let i = 0; i < 10; i++) {
  try {
    limiter.recordFailure("service");
    // Após 5 falhas, circuit breaker abre
    // Próximas requisições são bloqueadas por 30 segundos
  } catch (error) {
    // Sistema se protege automaticamente
  }
}
```

## 📈 **Monitoramento e Estatísticas**

```typescript
// Estatísticas globais
const stats = manager.getGlobalStats();
console.log(stats);
// {
//   horario: { 
//     activeIdentifiers: 150, 
//     totalRequests: 5000, 
//     circuitBreakersOpen: 0 
//   },
//   validacao: { 
//     activeIdentifiers: 50, 
//     totalRequests: 800, 
//     circuitBreakersOpen: 1 
//   },
//   admin: { 
//     activeIdentifiers: 5, 
//     totalRequests: 20, 
//     circuitBreakersOpen: 0 
//   }
// }
```

## 🎯 **Resumo das Proteções**

### **Rate Limiting**
- **O que é**: Controle de volume de requisições
- **Como funciona**: Sliding window com array de timestamps
- **Protege contra**: Ataques de força bruta, spam massivo

### **Debounce**
- **O que é**: Prevenção de requisições muito frequentes
- **Como funciona**: Intervalo mínimo entre requisições
- **Protege contra**: Cliques duplos, spam de botões

### **DoS Prevention**
- **O que limita**: Volume, frequência, tamanho de entrada, falhas
- **Como funciona**: Múltiplas camadas de validação
- **Protege contra**: Todos os tipos de ataques de negação de serviço

### **Input Validation**
- **O que valida**: Horários, datas, strings, arrays
- **Como funciona**: Regex, sanitização, limites de tamanho
- **Protege contra**: XSS, SQL Injection, Parameter Pollution

O sistema implementado é **muito mais robusto** que apenas debounce - é um **sistema completo de proteção** que combina múltiplas técnicas de segurança para criar uma defesa em profundidade contra diferentes tipos de ataques e abusos.
