# Documentação Completa - Módulo Comercial Hours

Este documento contém a documentação completa de todas as classes, funções e arrow functions do módulo `@phdiniiz/comercialTime`, organizadas por camadas da Clean Architecture.

## 📋 Índice

- [Domain Layer (Camada de Domínio)](#domain-layer)
- [Application Layer (Camada de Aplicação)](#application-layer)
- [Infrastructure Layer (Camada de Infraestrutura)](#infrastructure-layer)
- [Presentation Layer (Camada de Apresentação)](#presentation-layer)
- [Performance Layer (Camada de Performance)](#performance-layer)
- [Security Layer (Camada de Segurança)](#security-layer)
- [Configuration Layer (Camada de Configuração)](#configuration-layer)
- [Library Layer (Camada de Biblioteca)](#library-layer)

---

## Domain Layer

### Entidades

#### `HorarioComercialEntity`
Interface que representa a entidade completa de horário comercial.

**Propriedades:**
- `horario: Horario` - Configuração de horários por dia da semana
- `feriados: ReadonlySet<string>` - Set de feriados (datas no formato YYYY-MM-DD)
- `openedNow: boolean` - Status atual do estabelecimento (aberto/fechado)

#### `Intervalo`
Interface que representa um intervalo de horário comercial.

**Propriedades:**
- `abertura: HoraString` - Horário de abertura no formato HH:mm
- `fechamento: HoraString` - Horário de fechamento no formato HH:mm

#### `Horario`
Interface que representa o horário comercial completo.

**Propriedades:**
- `[dia: string]: readonly Intervalo[]` - Mapeamento de dia (string) para array de intervalos

### Value Objects

#### `IntervaloValueObject`
Value Object que representa um intervalo de horário comercial com validações.

**Métodos:**
- `constructor(abertura: HoraString, fechamento: HoraString)` - Constrói um novo intervalo com validação
- `get abertura(): HoraString` - Obtém o horário de abertura
- `get fechamento(): HoraString` - Obtém o horário de fechamento
- `equals(other: IntervaloValueObject): boolean` - Compara intervalos para igualdade
- `toString(): string` - Retorna representação em string do intervalo

### Tipos

#### `DiaChave`
Tipo que representa uma chave de dia da semana (número ou nome).

#### `HoraString`
Tipo que representa uma string de hora no formato HH:mm.

### Constantes

#### `DIAS_SEMANA`
Constantes que definem os dias da semana como números.

#### `HORARIO_PADRAO`
Constantes que definem horários padrão para estabelecimentos comerciais.

#### `LIMITE_BUSCA_DIAS`
Máximo de dias para buscar próxima abertura (limite de performance).

---

## Application Layer

### Casos de Uso

#### `HorarioComercialUseCase`
Interface que define os casos de uso para operações de horário comercial.

**Métodos:**
- `verificarSeEstaAberto(data?: Date | string): boolean` - Verifica se está aberto
- `obterProximaAbertura(data?: Date | string): Date | null` - Obtém próxima abertura
- `obterProximoFechamento(data?: Date | string): Date | null` - Obtém próximo fechamento
- `adicionarMinutosUteis(data: Date | string, minutos: number): Date` - Adiciona minutos úteis
- `obterMinutosRestantesHoje(data?: Date | string): number` - Calcula minutos restantes
- `obterHorarioConfigurado(): HorarioComercialEntity["horario"]` - Obtém configuração
- `obterStatusAtual(): boolean` - Obtém status atual

#### `HorarioComercialUseCaseImpl`
Implementação concreta dos casos de uso de horário comercial.

**Métodos:**
- `constructor(horarioComercial: HorarioComercial)` - Constrói nova instância
- `verificarSeEstaAberto(data?: Date | string): boolean` - Verifica se está aberto
- `obterProximaAbertura(data?: Date | string): Date | null` - Obtém próxima abertura
- `obterProximoFechamento(data?: Date | string): Date | null` - Obtém próximo fechamento
- `adicionarMinutosUteis(data: Date | string, minutos: number): Date` - Adiciona minutos úteis
- `obterMinutosRestantesHoje(data?: Date | string): number` - Calcula minutos restantes
- `obterHorarioConfigurado()` - Obtém configuração
- `obterStatusAtual(): boolean` - Obtém status atual

---

## Infrastructure Layer

### Utilitários de Timezone

#### `toCurrentTimezone(date: Date | string): Date`
Converte uma data para o timezone atualmente configurado no sistema.

#### `getTimezoneOffset(timezone: string): number`
Obtém o offset de um timezone específico em minutos em relação ao UTC.

#### `isValidTimezone(timezone: string): boolean`
Verifica se um timezone é válido usando a API Intl.

#### `getNowInTimezone(): Date`
Obtém a data atual no timezone configurado no sistema.

#### `formatDateInTimezone(date: Date | string, options?: Intl.DateTimeFormatOptions): string`
Formata uma data no timezone atualmente configurado.

#### `getTimeInTimezone(date?: Date | string): string`
Obtém apenas a hora (HH:mm) no timezone atualmente configurado.

#### `getDateInTimezone(date?: Date | string): string`
Obtém apenas a data (DD/MM/YYYY) no timezone atualmente configurado.

#### `getDayOfWeekInTimezone(date?: Date | string): number`
Obtém o dia da semana (0-6) no timezone atualmente configurado.

#### `getDayNameInTimezone(date?: Date | string): string`
Obtém o nome do dia da semana no timezone atualmente configurado.

#### `createDateInTimezone(year: number, month: number, day: number, hour?: number, minute?: number, second?: number): Date`
Cria uma data no timezone atualmente configurado com hora específica.

#### `compareDatesInTimezone(date1: Date | string, date2: Date | string): number`
Compara duas datas considerando o timezone atualmente configurado.

#### `isTodayInTimezone(date: Date | string): boolean`
Verifica se uma data é hoje no timezone atualmente configurado.

#### `isFutureInTimezone(date: Date | string): boolean`
Verifica se uma data é no futuro no timezone atualmente configurado.

#### `isPastInTimezone(date: Date | string): boolean`
Verifica se uma data é no passado no timezone atualmente configurado.

### Utilitários de Normalização

#### `normalizarDia(k: DiaChave): number`
Normaliza uma chave de dia da semana para um número (0-6).

#### `normalizarHorario(input: Record<DiaChave, Intervalo[] | Intervalo>): Horario`
Normaliza um objeto de horário comercial para o formato padrão.

#### `obterNomeDia(numero: number): string`
Obtém o nome do dia da semana a partir do número.

### Utilitários de Tempo

#### `horaParaMinutos(h: HoraString): number`
Converte uma string de hora (HH:mm) para minutos desde meia-noite.

#### `minutosParaHora(mins: number): HoraString`
Converte minutos desde meia-noite para string de hora (HH:mm).

#### `diaIndex(date: Date): number`
Obtém o índice do dia da semana de uma data (0-6).

#### `minutosDoDia(date: Date): number`
Obtém o número de minutos desde meia-noite de uma data.

#### `validarFormatoHora(hora: string): boolean`
Valida se uma string está no formato de hora correto (HH:mm).

#### `formatarDataParaISO(data: Date): string`
Formata uma data para o formato ISO (YYYY-MM-DD).

---

## Presentation Layer

### Controllers

#### `HorarioComercialController`
Interface que define o controller para operações de horário comercial.

**Métodos:**
- `verificarStatus(data?: Date | string)` - Verifica status completo
- `obterHorario(): Record<string, readonly Intervalo[]>` - Obtém configuração
- `adicionarMinutosUteis(data: Date | string, minutos: number): string` - Adiciona minutos úteis
- `obterStatusAtual(): boolean` - Obtém status atual

#### `HorarioComercialControllerImpl`
Implementação concreta do controller de horário comercial.

**Métodos:**
- `constructor(useCase: HorarioComercialUseCase)` - Constrói nova instância
- `verificarStatus(data?: Date | string)` - Verifica status completo
- `obterHorario()` - Obtém configuração
- `adicionarMinutosUteis(data: Date | string, minutos: number): string` - Adiciona minutos úteis
- `obterStatusAtual(): boolean` - Obtém status atual

### Factories

#### `HorarioComercialFactory`
Factory para criar instâncias da aplicação com todas as dependências injetadas.

**Métodos:**
- `static create(horarioInput: Record<DiaChave, Intervalo[] | Intervalo>, feriados?: readonly string[])` - Cria instância completa

---

## Performance Layer

### Cache Manager

#### `CacheManager<T>`
Gerenciador de cache genérico com TTL (Time To Live).

**Métodos:**
- `constructor(ttlMs?: number)` - Constrói nova instância
- `get(key: string): T | null` - Obtém valor do cache
- `set(key: string, value: T): void` - Armazena valor no cache
- `has(key: string): boolean` - Verifica se chave existe
- `clear(): void` - Remove todos os itens
- `cleanup(): void` - Remove itens expirados
- `size(): number` - Obtém número de itens

### Serviço Otimizado

#### `OptimizedHorarioComercialService`
Serviço otimizado de horário comercial com cache e otimizações de performance.

**Métodos:**
- `constructor(horarioInput: Record<DiaChave, Intervalo[] | Intervalo>, feriados?: readonly string[])` - Constrói nova instância
- `estaAberto(dt?: Date | string): boolean` - Verifica se está aberto (com cache)
- `proximaAbertura(dt?: Date | string): Date | null` - Obtém próxima abertura (com cache)
- `proximoFechamento(dt?: Date | string): Date | null` - Obtém próximo fechamento
- `adicionarMinutosUteis(dt?: Date | string, minutosAdicionar?: number): Date` - Adiciona minutos úteis
- `minutosRestantesHoje(dt?: Date | string): number` - Calcula minutos restantes
- `obterHorario(): Horario` - Obtém configuração
- `limparCache(): void` - Limpa todos os caches

---

## Security Layer

### Rate Limiter

#### `RateLimiter`
Implementação de rate limiting para prevenir ataques de DoS e abuso da API.

**Métodos:**
- `constructor(maxRequests?: number, windowMs?: number)` - Constrói nova instância
- `isAllowed(identifier: string): boolean` - Verifica se requisição é permitida
- `cleanup(): void` - Limpa requisições antigas
- `getStats(identifier: string): { count: number; resetTime: number }` - Obtém estatísticas

### Advanced Rate Limiter

#### `AdvancedRateLimiter`
Implementação avançada de rate limiting com debounce, throttle e circuit breaker.

**Métodos:**
- `constructor(config: RateLimitConfig)` - Constrói nova instância
- `isAllowed(identifier: string): RateLimitResult` - Verifica se requisição é permitida
- `recordFailure(identifier: string): void` - Registra falha para circuit breaker
- `cleanup(): void` - Limpeza de memória
- `getGlobalStats()` - Obtém estatísticas globais

### Rate Limiter Integration

#### `RateLimiterManager`
Gerenciador de rate limiters para diferentes cenários.

**Métodos:**
- `constructor()` - Constrói nova instância
- `checkHorarioComercial(identifier: string)` - Verifica operação de horário
- `checkValidacao(identifier: string)` - Verifica operação de validação
- `checkAdmin(identifier: string)` - Verifica operação administrativa
- `recordFailure(type: string, identifier: string)` - Registra falha
- `cleanup()` - Limpeza de todos os rate limiters
- `getGlobalStats()` - Obtém estatísticas globais

#### `SecureHorarioComercialService`
Exemplo de serviço seguro com rate limiting integrado.

**Métodos:**
- `constructor(identifier: string)` - Constrói nova instância
- `getIdentifier(): string` - Obtém identificador
- `estaAberto(data?: Date | string): boolean` - Verifica se está aberto (com rate limiting)
- `validarHorario(horario: string): boolean` - Valida horário (com rate limiting)
- `configurarHorario(horario: any): void` - Configura horário (com rate limiting)

### Validadores de Entrada

#### `InputValidator`
Classe para validação de entrada de dados com foco em segurança.

**Métodos Estáticos:**
- `validateHorarioInput(input: string): boolean` - Valida entrada de horário
- `validateDiaInput(input: string): boolean` - Valida entrada de dia
- `validateDateInput(input: string | Date): boolean` - Valida entrada de data
- `sanitizeString(input: string): string` - Sanitiza string
- `validateFeriados(feriados: readonly string[]): boolean` - Valida array de feriados

---

## Configuration Layer

### Timezone Configuration

#### `TimezoneConfig`
Interface que define a configuração de timezone do sistema.

**Propriedades:**
- `defaultTimezone: string` - Timezone padrão do sistema
- `fallbackTimezone: string` - Timezone de fallback em caso de erro
- `autoDetect: boolean` - Se deve detectar automaticamente o timezone do sistema

#### `TimezoneManager`
Gerenciador de configuração de timezone do sistema.

**Métodos:**
- `constructor(config?: TimezoneConfig)` - Constrói nova instância
- `getCurrentTimezone(): string` - Obtém timezone atual
- `getConfig(): TimezoneConfig` - Obtém configuração atual
- `toCurrentTimezone(date: Date): Date` - Converte data para timezone atual
- `getCurrentDate(): Date` - Obtém data atual no timezone configurado
- `formatDate(date: Date, options?: Intl.DateTimeFormatOptions): string` - Formata data

### Funções Utilitárias de Timezone

#### `getTimezoneFromEnv(): string`
Obtém o timezone configurado no arquivo .env com validação e fallback.

#### `getCurrentTimezone(): string`
Função utilitária para obter o timezone atualmente configurado.

#### `getCurrentDate(): Date`
Função utilitária para obter a data atual no timezone configurado.

#### `formatDate(date: Date, options?: Intl.DateTimeFormatOptions): string`
Função utilitária para formatar uma data no timezone atual.

### Constantes

#### `DEFAULT_TIMEZONE_CONFIG`
Configuração padrão de timezone para o sistema.

---

## Library Layer

### Classe Principal

#### `HorarioComercial`
Classe principal para gerenciar horários comerciais.

**Métodos:**
- `constructor(horarioInput: Record<DiaChave, Intervalo[] | Intervalo>, feriados?: readonly string[])` - Constrói nova instância
- `estaAberto(dt?: Date | string): boolean` - Verifica se está aberto
- `proximaAbertura(dt?: Date | string): Date | null` - Obtém próxima abertura
- `proximoFechamento(dt?: Date | string): Date | null` - Obtém próximo fechamento
- `adicionarMinutosUteis(dt?: Date | string, minutosAdicionar?: number): Date` - Adiciona minutos úteis
- `minutosRestantesHoje(dt?: Date | string): number` - Calcula minutos restantes
- `obterHorario(): Horario` - Obtém configuração

### Funções de Normalização

#### `normalizarDia(k: DiaChave): number`
Normaliza uma chave de dia da semana para um número (0-6).

#### `normalizarHorario(input: Record<DiaChave, Intervalo[] | Intervalo>): Horario`
Normaliza um objeto de horário comercial para o formato padrão.

### Funções Utilitárias

#### `horaParaMinutos(h: HoraString): number`
Converte uma string de hora (HH:mm) para minutos desde meia-noite.

#### `minutosParaHora(mins: number): HoraString`
Converte minutos desde meia-noite para string de hora (HH:mm).

#### `diaIndex(date: Date): number`
Obtém o índice do dia da semana de uma data (0-6).

#### `minutosDoDia(date: Date): number`
Obtém o número de minutos desde meia-noite de uma data.

### Tipos

#### `DiaChave`
Tipo que representa uma chave de dia da semana (número ou nome).

#### `HoraString`
Tipo que representa uma string de hora no formato HH:mm.

#### `Intervalo`
Tipo que representa um intervalo de horário comercial.

#### `Horario`
Tipo que representa o horário comercial completo.

---

## 🚀 Exemplos de Uso

### Uso Básico

```typescript
import { HorarioComercial } from '@phdiniiz/comercialTime';

const horario = new HorarioComercial({
  segunda: { abertura: "08:00", fechamento: "18:00" },
  terca: { abertura: "08:00", fechamento: "18:00" },
  // ... outros dias
}, ["2024-01-01", "2024-12-25"]);

// Verificar se está aberto agora
const aberto = horario.estaAberto();

// Próxima abertura
const proximaAbertura = horario.proximaAbertura();

// Adicionar 30 minutos úteis
const novaData = horario.adicionarMinutosUteis(new Date(), 30);
```

### Uso com Timezone

```typescript
import { getCurrentDate, getCurrentTimezone } from '@phdiniiz/comercialTime';

// Obter timezone atual (lido do .env)
const timezone = getCurrentTimezone();

// Obter data atual no timezone configurado
const agora = getCurrentDate();
```

### Uso com Cache (Performance)

```typescript
import { OptimizedHorarioComercialService } from '@phdiniiz/comercialTime';

const servicoOtimizado = new OptimizedHorarioComercialService(horarioInput, feriados);

// Operações com cache automático
const aberto = servicoOtimizado.estaAberto();
const proximaAbertura = servicoOtimizado.proximaAbertura();

// Limpar cache quando necessário
servicoOtimizado.limparCache();
```

### Uso com Rate Limiting (Segurança)

```typescript
import { applyRateLimit } from '@phdiniiz/comercialTime';

try {
  // Aplicar rate limiting
  applyRateLimit("horario", "user123");
  
  // Operação permitida
  const resultado = horario.estaAberto();
} catch (error) {
  // Rate limit excedido
  console.error("Rate limit excedido:", error.message);
}
```

---

## 📝 Notas Importantes

1. **Clean Architecture**: O módulo segue os princípios de Clean Architecture com camadas bem definidas.

2. **TypeScript**: Totalmente tipado com TypeScript para melhor experiência de desenvolvimento.

3. **Performance**: Inclui otimizações de cache e algoritmos eficientes.

4. **Segurança**: Implementa rate limiting e validação de entrada para prevenir ataques.

5. **Timezone**: Suporte completo a timezones com configuração flexível.

6. **Testes**: Inclui testes unitários e de integração para garantir qualidade.

7. **Documentação**: Toda a API é documentada com JSDoc para melhor experiência de desenvolvimento.

---

## 🔧 Configuração

### Variáveis de Ambiente

O timezone é configurado exclusivamente através do arquivo `.env`:

```env
TIMEZONE=America/Sao_Paulo
```

**Nota:** O timezone é lido automaticamente do arquivo `.env` na inicialização. Não há necessidade de configurar programaticamente.

### Dependências

```json
{
  "dependencies": {
    "dotenv": "^16.0.0"
  }
}
```

---

## 📚 Recursos Adicionais

- [README Principal](./README.md) - Documentação geral do projeto
- [Exemplos](./examples/) - Exemplos práticos de uso
- [Testes](./tests/) - Suíte de testes completa
- [Documentação de Segurança](./docs/security-explanations.md) - Explicações de segurança
- [Análise de Compatibilidade](./docs/compatibility-analysis.md) - Análise de compatibilidade
