# @phdiniiz/comercialTime

[![npm version](https://badge.fury.io/js/%40phdiniz%2FcomercialHours.svg)](https://badge.fury.io/js/%40phdiniz%2FcomercialHours)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Node.js Version](https://img.shields.io/badge/node-%3E%3D22.0.0-brightgreen.svg)](https://nodejs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.7.2-blue.svg)](https://www.typescriptlang.org/)

> **Ferramentas em TypeScript para horário comercial (pt-BR) — HorarioComercial**

Uma biblioteca completa e robusta para gerenciamento de horários comerciais em português brasileiro, implementada com Clean Architecture, validações de segurança e otimizações de performance.

## 🚀 Características

- ✅ **API em Português (pt-BR)** - Interface totalmente em português brasileiro
- ✅ **Clean Architecture** - Código organizado em camadas bem definidas
- ✅ **TypeScript First** - Tipagem forte e IntelliSense completo
- ✅ **Validações de Segurança** - Proteção contra XSS, SQL Injection, DoS
- ✅ **Rate Limiting Avançado** - Debounce, Throttle, Circuit Breaker
- ✅ **Performance Otimizada** - Cache inteligente e operações eficientes
- ✅ **Testes Automatizados** - Cobertura completa com Jest
- ✅ **ESM Nativo** - Suporte completo a módulos ES2024
- ✅ **Zero Dependencies** - Sem dependências externas

## 📦 Instalação

```bash
# Usando pnpm (recomendado)
pnpm add @phdiniiz/comercialTime

# Usando npm
npm install @phdiniiz/comercialTime

# Usando yarn
yarn add @phdiniiz/comercialTime
```

## 🚀 Inicialização com Timezone Obrigatório

### ⚠️ **IMPORTANTE: Timezone é Obrigatório**

A partir desta versão, o módulo **requer** que você especifique o timezone durante a inicialização. O padrão é **pt-BR (America/Sao_Paulo)**.

**✨ NOVO:** Todas as funções de inicialização foram migradas para o arquivo principal `index.ts`, tornando a importação mais simples e direta.

```typescript
import { inicializar } from "@phdiniiz/comercialTime";

// ✅ CORRETO: Inicializar com timezone específico
await inicializar("America/Sao_Paulo"); // Brasil (pt-BR)
await inicializar("America/New_York");  // EUA (en-US)
await inicializar("Europe/Lisbon");     // Portugal (pt-PT)

// ❌ INCORRETO: Tentar inicializar sem timezone
// await inicializar(); // ERRO: Timezone é obrigatório
```

### Inicialização por País

```typescript
import { 
  inicializarParaBrasil,
  inicializarParaEUA,
  inicializarParaPortugal 
} from "@phdiniiz/comercialTime";

// Inicialização específica por país
await inicializarParaBrasil();     // America/Sao_Paulo
await inicializarParaEUA();        // America/New_York
await inicializarParaPortugal();   // Europe/Lisbon
```

**✨ NOVO:** Todas as funções de inicialização estão agora disponíveis diretamente no arquivo principal, sem necessidade de importações adicionais.

### Configuração Avançada

```typescript
import { inicializar, inicializarRapido } from "@phdiniiz/comercialTime";

// Inicialização com opções personalizadas
await inicializar("America/Sao_Paulo", {
  inicializarCronJob: true,        // Iniciar CRONJOB automaticamente
  intervaloCronJob: 60,            // Intervalo em minutos
  timeoutRequisicoes: 5000         // Timeout em ms
});

// Inicialização rápida sem CRONJOB (ideal para aplicações que precisam de inicialização rápida)
await inicializarRapido("America/Sao_Paulo");
```

### ⚡ Inicialização Rápida

Para aplicações que precisam de inicialização mais rápida (sem aguardar atualização de feriados):

```typescript
import { inicializarRapido, inicializarCronJobFeriados } from "@phdiniiz/comercialTime";

// Inicialização rápida - não inicia CRONJOB automaticamente
const resultado = await inicializarRapido("America/Sao_Paulo");
console.log("✅ Aplicação inicializada rapidamente:", resultado.sucesso);

// CRONJOB pode ser iniciado posteriormente se necessário
inicializarCronJobFeriados(); // Inicia em background
```

**✨ NOVO:** Todas as funções estão agora disponíveis em uma única importação, simplificando o uso do módulo.

## 🚀 Importação Modular

### Importação Seletiva de Feriados

```typescript
// Importar apenas feriados nacionais
import comercialTime, { incluir } from "@phdiniiz/comercialTime";

const horarioNacional = incluir({ nacionais: true });

// Importar feriados nacionais + estaduais de SP
const horarioCompleto = incluir({ 
  nacionais: true, 
  estaduais: "SP" 
});

// Importar feriados de múltiplos estados
const horarioMultiEstados = incluir({ 
  nacionais: true, 
  estaduais: ["SP", "RJ", "MG"] 
});

// Importar de localização personalizada
const horarioCustom = incluir({ 
  nacionais: true, 
  estaduais: "SP",
  location: "my-location" // Pasta /locale/my-location/
});
```

### Uso do Sistema Modular

```typescript
// Criar instância do horário comercial
const horario = horarioCompleto.criarHorarioComercial({
  segunda: { abertura: '08:00', fechamento: '18:00' },
  terca: { abertura: '08:00', fechamento: '18:00' },
  quarta: { abertura: '08:00', fechamento: '18:00' },
  quinta: { abertura: '08:00', fechamento: '18:00' },
  sexta: { abertura: '08:00', fechamento: '18:00' }
});

// Acessar feriados específicos
const feriadosNacionais = horarioCompleto.nacionais();
const feriadosSP = horarioCompleto.estaduais("SP");

// Verificar estados disponíveis
const estados = horarioCompleto.obterEstadosDisponiveis();
console.log(estados); // ["SP", "RJ", "MG", "RS", "PR", "SC", "BA", "PE", "CE", "GO"]

// Verificar localização em uso
const localizacao = horarioCompleto.obterLocalizacaoUsada();
console.log(localizacao); // "pt-br" ou "my-location"
```

## 🌍 Localizações Disponíveis

### Localizações Pré-configuradas

O módulo inclui feriados para as seguintes localizações:

#### 🇧🇷 **Brasil (pt-BR)**
- **Feriados Nacionais**: 9 feriados (Confraternização Universal, Tiradentes, etc.)
- **Estados**: SP, RJ, MG, RS, PR, SC, BA, PE, CE, GO
- **Uso**: `incluir({ nacionais: true, estaduais: "SP" })`

#### 🇵🇹 **Portugal (pt-PT)**
- **Feriados Nacionais**: 10 feriados (Dia da Liberdade, Dia de Portugal, etc.)
- **Regiões**: LIS, POR, BRA, COI, AVE, SET, FAR, LEI, VSE, GUA
- **Uso**: `incluir({ nacionais: true, estaduais: "LIS", location: "pt-PT" })`

#### 🇺🇸 **Estados Unidos (en-US)**
- **Feriados Nacionais**: 10 feriados (Independence Day, Thanksgiving, etc.)
- **Estados**: CA, NY, TX, FL, IL, MA, LA, HI, AK, NV
- **Uso**: `incluir({ nacionais: true, estaduais: "CA", location: "en-US" })`

### Exemplos de Uso por Localização

```typescript
import { incluir } from "@phdiniiz/comercialTime";

// Brasil (padrão)
const horarioBrasil = incluir({ nacionais: true, estaduais: "SP" });

// Portugal
const horarioPortugal = incluir({ 
  nacionais: true, 
  estaduais: "LIS", 
  location: "pt-PT" 
});

// Estados Unidos
const horarioEUA = incluir({ 
  nacionais: true, 
  estaduais: "CA", 
  location: "en-US" 
});

// Verificar feriados específicos
console.log(horarioPortugal.nacionais()); // Feriados de Portugal
console.log(horarioEUA.estaduais("CA")); // Feriados da Califórnia
```

## 🌍 Localização Personalizada

### Criando Sua Própria Localização

Para usar feriados de outro país/região, crie uma pasta em `/locale/my-location/` com os arquivos:

```
src/locale/my-location/
├── feriados-nacionais.json
└── feriados-estaduais.json
```

### Estrutura dos Arquivos

**feriados-nacionais.json:**
```json
[
  {
    "nome": "New Year's Day",
    "data": "2025-01-01",
    "observacoes": "First day of the year."
  }
]
```

**feriados-estaduais.json:**
```json
{
  "CA": [
    {
      "nome": "California Day",
      "data": "2025-09-09",
      "observacoes": "California's state holiday."
    }
  ]
}
```

### Uso com Localização Personalizada

```typescript
import { incluir, listarLocalizacoesDisponiveis, localizacaoValida } from "@phdiniiz/comercialTime";

// Verificar localizações disponíveis
const localizacoes = listarLocalizacoesDisponiveis();
console.log(localizacoes); // ["pt-br", "pt-PT", "en-US", "my-location"]

// Verificar se localização é válida
const valida = localizacaoValida("my-location");
console.log(valida); // true

// Usar localização personalizada
const horarioCustom = incluir({ 
  nacionais: true, 
  estaduais: "CA",
  location: "my-location"
});

// Se a localização não for válida, usa pt-BR como fallback
const horarioFallback = incluir({ 
  nacionais: true, 
  location: "invalid-location" // Usa pt-BR automaticamente
});
```

## ⚙️ Configuração

### Timezone (Opcional)

O módulo lê automaticamente o timezone do arquivo `.env` ou variáveis de ambiente:

```env
# .env (no seu projeto)
TIMEZONE=America/Sao_Paulo
```

**Alternativas:**
```bash
# Variável de ambiente
export TIMEZONE=America/Sao_Paulo

# Docker
ENV TIMEZONE=America/Sao_Paulo

# Scripts package.json
"start": "TIMEZONE=America/Sao_Paulo node index.js"
```

**Fallback:** Se não configurado, usa `America/Sao_Paulo` automaticamente.

## ⏰ CRONJOB de Atualização Automática

### Sistema de Atualização de Feriados

O módulo inclui um sistema de CRONJOB para atualização automática de feriados nacionais e estaduais no start do projeto.

#### Configuração Automática por Timezone

```env
# .env (no seu projeto)
TIMEZONE=America/Sao_Paulo  # pt-BR (Brasil)
# TIMEZONE=America/New_York  # en-US (EUA)
# TIMEZONE=Europe/Lisbon     # pt-PT (Portugal)

# Configurações opcionais do CRONJOB
FERIADO_UPDATE_INTERVAL_MINUTES=60  # Intervalo em minutos (padrão: 60)
FERIADO_UPDATE_TIMEOUT_MS=10000     # Timeout das requisições em ms (padrão: 10000)
```

#### Mapeamento de Timezones

| Timezone | País | Locale | Capital |
|----------|------|--------|---------|
| `America/Sao_Paulo` | BR | pt-BR | BRASILIA |
| `America/New_York` | US | en-US | WASHINGTON |
| `Europe/Lisbon` | PT | pt-PT | LISBOA |

#### Uso do CRONJOB

```typescript
import { 
  inicializar,
  inicializarCronJobFeriados, 
  inicializarCronJobFeriadosPorPais,
  executarAtualizacaoManual 
} from "@phdiniiz/comercialTime";

// ⚠️ IMPORTANTE: Inicializar primeiro com timezone
await inicializar("America/Sao_Paulo");

// Inicialização automática baseada no timezone configurado
inicializarCronJobFeriados();

// Ou para país específico
inicializarCronJobFeriadosPorPais("BR");
inicializarCronJobFeriadosPorPais("US");
inicializarCronJobFeriadosPorPais("PT");

// Atualização manual
await executarAtualizacaoManual();
await executarAtualizacaoManual("BR");
```

**✨ NOVO:** Todas as funções de CRONJOB estão agora disponíveis diretamente no arquivo principal, sem necessidade de importações separadas.

#### Logs do CRONJOB

O sistema gera logs informativos durante a execução:

```
🚀 Iniciando CRONJOB de atualização de feriados...
[BRASILIA] Iniciando CRONJOB de atualização de feriados (intervalo: 60 minutos)
[BRASILIA] Iniciando atualização completa de feriados...
[BR] Usando dados estáticos de feriados nacionais
[BR] Usando dados estáticos de feriados estaduais
[BRASILIA] Atualizado os feriados nacionais.
[BRASILIA] Atualizado os feriados estaduais.
[BRASILIA] Atualizado os feriados nacionais e estaduais.
✅ CRONJOB de atualização de feriados iniciado com sucesso
```

#### Feriados Incluídos

**Brasil (pt-BR):**
- 9 feriados nacionais (Confraternização, Tiradentes, Trabalhador, etc.)
- 6 feriados estaduais (SP, RJ, MG, RS, BA, PE)

**EUA (en-US):**
- 11 feriados nacionais (New Year's, MLK Day, Independence Day, etc.)
- 6 feriados estaduais (CA, TX, NY, FL, IL, MA)

**Portugal (pt-PT):**
- 13 feriados nacionais (Ano Novo, Carnaval, Páscoa, etc.)
- 6 feriados regionais (Lisboa, Porto, Coimbra, Braga, Aveiro, Faro)

### 🎯 Feriados Personalizados (Prioridade Máxima)

O módulo suporta feriados personalizados através da variável de ambiente `PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON`. **Estes feriados têm prioridade máxima** sobre todos os outros.

#### **📋 Formatos Suportados**

**1. JSON Direto (Formato Novo)**
```env
# .env (no seu projeto)
# Formato novo: nacionais e estaduais
PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON='{"nacionais":[{"nome":"Dia da Empresa","data":"2025-03-15","observacoes":"Aniversário da nossa empresa - feriado corporativo."},{"nome":"Dia do Desenvolvedor","data":"2025-09-13","observacoes":"Celebração do dia do programador - feriado técnico."}],"estaduais":{"SP":[{"nome":"Dia da Revolução Constitucionalista Personalizada","data":"2025-07-09","observacoes":"Nossa versão personalizada do feriado de SP."}],"RJ":[{"nome":"Dia de São Sebastião Personalizado","data":"2025-01-20","observacoes":"Nossa versão personalizada do feriado do RJ."}]}}'
```

**2. JSON Direto (Formato Antigo - Compatibilidade)**
```env
# Formato antigo: apenas nacionais (compatibilidade)
PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON='[{"nome":"Dia da Empresa","data":"2025-03-15","observacoes":"Aniversário da nossa empresa - feriado corporativo."},{"nome":"Dia do Desenvolvedor","data":"2025-09-13","observacoes":"Celebração do dia do programador - feriado técnico."}]'
```

**3. URL para Carregamento Dinâmico**
```env
# URL para carregar feriados de uma API ou arquivo remoto
PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON='https://api.exemplo.com/feriados.json'
PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON='https://raw.githubusercontent.com/user/repo/main/feriados.json'
PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON='https://api.github.com/repos/user/repo/contents/feriados.json'
```

**4. Valores Inválidos (Desconsiderados)**
```env
# Vazio (inválido - desconsiderado)
PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON=''

# Undefined (inválido - desconsiderado)
# (não definir a variável)

# JSON (inválido - desconsiderado)
PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON='{"nacionais":[...]}'

# Qualquer outro valor (inválido - desconsiderado)
PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON='invalid-value'
```

**Alternativas:**
```bash
# Variável de ambiente
export PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON='[{"nome":"Dia da Empresa","data":"2025-03-15","observacoes":"Aniversário da nossa empresa."}]'

# Docker
ENV PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON='[{"nome":"Dia da Empresa","data":"2025-03-15","observacoes":"Aniversário da nossa empresa."}]'

# Scripts package.json
"start": "PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON='[{\"nome\":\"Dia da Empresa\",\"data\":\"2025-03-15\",\"observacoes\":\"Aniversário da nossa empresa.\"}]' node index.js"
```

**Comportamento:**
- ✅ **Prioridade máxima** - Feriados personalizados sempre têm precedência
- ✅ **Apenas URLs válidas** - O sistema aceita apenas URLs válidas
- ✅ **Validação rigorosa** - Valores vazios, null, undefined e inválidos são desconsiderados
- ✅ **Fallback seguro** - Valores inválidos são ignorados sem quebrar o sistema

#### **🌐 Vantagens de Usar URLs**

**✅ Centralização**
- Feriados em um local único
- Atualizações automáticas sem redeploy
- Compartilhamento entre múltiplas aplicações

**✅ Versionamento**
- Controle de versões via Git
- Histórico de mudanças
- Rollback fácil

**✅ Performance**
- Cache e CDN
- Redução de dependências locais
- Carregamento sob demanda

**✅ Segurança**
- Controle de acesso via autenticação
- Validação de certificados SSL
- Monitoramento centralizado

#### **🔒 Considerações de Segurança para URLs**

**Requisitos:**
- ✅ Use HTTPS em produção
- ✅ Valide certificados SSL
- ✅ Implemente timeout para requisições
- ✅ Use autenticação quando necessário
- ✅ Valide o conteúdo JSON recebido
- ✅ Implemente fallback para falhas de rede
- ✅ Cache local para reduzir dependência de rede
- ✅ Monitoramento de disponibilidade da URL
- ✅ **Validação automática** - Estrutura JSON é validada automaticamente
- ✅ **Fallback inteligente** - Se inválido, usa pt-BR como fallback
- ✅ **Logs informativos** - Console mostra quando feriados personalizados são carregados

## 📅 Feriados

O módulo suporta múltiplas localizações e carrega automaticamente os feriados dos arquivos em `/locale/` com informações completas:

### 🌍 Localizações Disponíveis

| Localização | País | Feriados Nacionais | Regiões/Estados | Código |
|-------------|------|-------------------|-----------------|--------|
| **pt-BR** | 🇧🇷 Brasil | 9 feriados | 10 estados | `location: "pt-BR"` |
| **pt-PT** | 🇵🇹 Portugal | 10 feriados | 10 regiões | `location: "pt-PT"` |
| **en-US** | 🇺🇸 Estados Unidos | 10 feriados | 10 estados | `location: "en-US"` |

### 📋 Exemplos por Localização

#### 🇧🇷 **Brasil (pt-BR) - Padrão**
```typescript
import { incluir } from "@phdiniiz/comercialTime";

// Usar feriados brasileiros (padrão)
const horarioBrasil = incluir({ 
  nacionais: true, 
  estaduais: "SP" 
});

// Feriados nacionais do Brasil
const feriadosNacionais = horarioBrasil.nacionais();
console.log(feriadosNacionais);
// [
//   { nome: "Confraternização Universal", data: "2025-01-01", observacoes: "Início do ano civil." },
//   { nome: "Tiradentes", data: "2025-04-21", observacoes: "Em homenagem ao mártir da Inconfidência Mineira..." },
//   // ... outros feriados
// ]

// Feriados de São Paulo
const feriadosSP = horarioBrasil.estaduais("SP");
console.log(feriadosSP);
// [
//   { nome: "Revolução Constitucionalista", data: "2025-07-09", observacoes: "Data magna do estado de São Paulo." }
// ]
```

#### 🇵🇹 **Portugal (pt-PT)**
```typescript
// Usar feriados portugueses
const horarioPortugal = incluir({ 
  nacionais: true, 
  estaduais: "LIS", 
  location: "pt-PT" 
});

// Feriados nacionais de Portugal
const feriadosPortugal = horarioPortugal.nacionais();
console.log(feriadosPortugal);
// [
//   { nome: "Dia de Ano Novo", data: "2025-01-01", observacoes: "Primeiro dia do ano civil." },
//   { nome: "Dia da Liberdade", data: "2025-04-25", observacoes: "Revolução dos Cravos - fim da ditadura em Portugal." },
//   // ... outros feriados
// ]

// Feriados de Lisboa
const feriadosLisboa = horarioPortugal.estaduais("LIS");
console.log(feriadosLisboa);
// [
//   { nome: "Dia de Santo António", data: "2025-06-13", observacoes: "Padroeiro de Lisboa." }
// ]
```

#### 🇺🇸 **Estados Unidos (en-US)**
```typescript
// Usar feriados americanos
const horarioEUA = incluir({ 
  nacionais: true, 
  estaduais: "CA", 
  location: "en-US" 
});

// Feriados nacionais dos EUA
const feriadosEUA = horarioEUA.nacionais();
console.log(feriadosEUA);
// [
//   { nome: "New Year's Day", data: "2025-01-01", observacoes: "First day of the year." },
//   { nome: "Independence Day", data: "2025-07-04", observacoes: "Celebrates the Declaration of Independence in 1776." },
//   // ... outros feriados
// ]

// Feriados da Califórnia
const feriadosCalifornia = horarioEUA.estaduais("CA");
console.log(feriadosCalifornia);
// [
//   { nome: "California Admission Day", data: "2025-09-09", observacoes: "Commemorates California's admission to the Union in 1850." },
//   { nome: "Cesar Chavez Day", data: "2025-03-31", observacoes: "Honors the labor leader and civil rights activist." }
// ]
```

### 🔍 Verificar Localizações Disponíveis

```typescript
import { listarLocalizacoesDisponiveis, localizacaoValida } from "@phdiniiz/comercialTime";

// Listar todas as localizações disponíveis
const localizacoes = listarLocalizacoesDisponiveis();
console.log(localizacoes); // ["pt-br", "pt-PT", "en-US"]

// Verificar se uma localização é válida
const valida = localizacaoValida("pt-PT");
console.log(valida); // true

// Verificar localização em uso
const horario = incluir({ nacionais: true, location: "en-US" });
console.log(horario.obterLocalizacaoUsada()); // "en-US"
```

### 🎯 Como Escolher a Localização Correta

```typescript
import { incluir } from "@phdiniiz/comercialTime";

// Para projetos no Brasil (padrão)
const horarioBrasil = incluir({ nacionais: true, estaduais: "SP" });

// Para projetos em Portugal
const horarioPortugal = incluir({ 
  nacionais: true, 
  estaduais: "LIS", 
  location: "pt-PT" 
});

// Para projetos nos Estados Unidos
const horarioEUA = incluir({ 
  nacionais: true, 
  estaduais: "CA", 
  location: "en-US" 
});

// Para projetos internacionais (múltiplas localizações)
const horarioGlobal = incluir({ 
  nacionais: true, 
  estaduais: ["SP", "LIS", "CA"],
  location: "pt-br" // Base, mas pode incluir feriados de outros países
});
```

### 🎯 Feriados Personalizados

#### Verificar e Usar Feriados Personalizados

```typescript
import { 
  incluir, 
  feriadosPersonalizadosDisponiveis, 
  obterInfoFeriadosPersonalizados 
} from "@phdiniiz/comercialTime";

// Verificar se há feriados personalizados
const disponivel = feriadosPersonalizadosDisponiveis();
console.log('Feriados personalizados disponíveis:', disponivel);

if (disponivel) {
  // Obter informações sobre os feriados personalizados
  const info = obterInfoFeriadosPersonalizados();
  console.log('Quantidade:', info.quantidade);
  console.log('Exemplo:', info.exemplo);
  
  // Criar instância (automaticamente usa feriados personalizados)
  const horarioPersonalizado = incluir({ nacionais: true });
  
  console.log('Localização:', horarioPersonalizado.obterLocalizacaoUsada()); // "personalizado"
  console.log('Usando personalizados:', horarioPersonalizado.estaUsandoFeriadosPersonalizados()); // true
  
  // Obter informações detalhadas
  const infoDetalhada = horarioPersonalizado.obterInfoFeriados();
  console.log('Total de feriados:', infoDetalhada.total);
  console.log('Localização:', infoDetalhada.localizacao);
  console.log('Usando personalizados:', infoDetalhada.usandoPersonalizados);
}
```

#### Exemplo de Uso Completo

```typescript
// Configurar feriados personalizados (formato novo)
process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON = JSON.stringify({
  nacionais: [
    {
      nome: "Dia da Empresa",
      data: "2025-03-15",
      observacoes: "Aniversário da nossa empresa - feriado corporativo."
    },
    {
      nome: "Dia do Desenvolvedor",
      data: "2025-09-13",
      observacoes: "Celebração do dia do programador - feriado técnico."
    }
  ],
  estaduais: {
    "SP": [
      {
        nome: "Dia da Revolução Constitucionalista Personalizada",
        data: "2025-07-09",
        observacoes: "Nossa versão personalizada do feriado de SP."
      }
    ],
    "RJ": [
      {
        nome: "Dia de São Sebastião Personalizado",
        data: "2025-01-20",
        observacoes: "Nossa versão personalizada do feriado do RJ."
      }
    ]
  }
});

// Usar feriados personalizados
const horario = incluir({ nacionais: true });
const horarioComercial = horario.criarHorarioComercial({
  segunda: { abertura: '08:00', fechamento: '18:00' },
  terca: { abertura: '08:00', fechamento: '18:00' },
  quarta: { abertura: '08:00', fechamento: '18:00' },
  quinta: { abertura: '08:00', fechamento: '18:00' },
  sexta: { abertura: '08:00', fechamento: '18:00' }
});

// Verificar se está aberto em uma data específica
const dataEmpresa = '2025-03-15';
const estaAberto = horarioComercial.estaAberto(dataEmpresa);
console.log(`Está aberto no dia da empresa? ${estaAberto}`);

// Verificar feriado específico
const feriadoEmpresa = horarioComercial.obterFeriadoPorData(dataEmpresa);
if (feriadoEmpresa) {
  console.log(`Feriado: ${feriadoEmpresa.nome}`);
  console.log(`Observações: ${feriadoEmpresa.observacoes}`);
}
```

#### Estrutura dos Feriados Personalizados

```typescript
// Formato novo (recomendado)
interface FeriadosPersonalizados {
  nacionais: FeriadoPersonalizado[];                    // Feriados nacionais
  estaduais: Record<string, FeriadoPersonalizado[]>;    // Feriados estaduais por sigla
}

// Formato antigo (compatibilidade)
type FeriadosPersonalizadosLegacy = FeriadoPersonalizado[];

interface FeriadoPersonalizado {
  nome: string;        // Nome do feriado
  data: string;        // Data no formato YYYY-MM-DD
  observacoes: string; // Descrição do feriado
}
```

#### Exemplos de Estrutura

**Formato Novo (Recomendado):**
```json
{
  "nacionais": [
    {
      "nome": "Dia da Empresa",
      "data": "2025-03-15",
      "observacoes": "Aniversário da nossa empresa - feriado corporativo."
    }
  ],
  "estaduais": {
    "SP": [
      {
        "nome": "Dia da Revolução Constitucionalista Personalizada",
        "data": "2025-07-09",
        "observacoes": "Nossa versão personalizada do feriado de SP."
      }
    ],
    "RJ": [
      {
        "nome": "Dia de São Sebastião Personalizado",
        "data": "2025-01-20",
        "observacoes": "Nossa versão personalizada do feriado do RJ."
      }
    ]
  }
}
```

**Formato Antigo (Compatibilidade):**
```json
[
  {
    "nome": "Dia da Empresa",
    "data": "2025-03-15",
    "observacoes": "Aniversário da nossa empresa - feriado corporativo."
  },
  {
    "nome": "Dia do Desenvolvedor",
    "data": "2025-09-13",
    "observacoes": "Celebração do dia do programador - feriado técnico."
  }
]
```

#### Casos de Uso para Feriados Personalizados

- **🏢 Feriados Corporativos** - Aniversários da empresa, dias de treinamento
- **🎓 Feriados Acadêmicos** - Períodos de férias, dias de prova
- **🏥 Feriados de Saúde** - Dias de campanha de vacinação, check-ups
- **🎉 Feriados Culturais** - Festivais locais, eventos especiais
- ** Feriados Religiosos** - Datas específicas da religião da empresa

### 📊 Resumo das Localizações

O módulo carrega automaticamente os feriados nacionais brasileiros dos arquivos em `/locale/pt-br/` com informações completas:

```typescript
import { HorarioComercial, obterFeriadosFuturos, obterFeriadoPorData } from '@phdiniiz/comercialTime';

const horario = new HorarioComercial({
  segunda: { abertura: '08:00', fechamento: '18:00' }
});

// Obter todos os feriados
const feriados = horario.obterFeriados();
console.log(feriados);
// [
//   {
//     nome: "Confraternização Universal",
//     data: "2025-01-01",
//     observacoes: "Início do ano civil.",
//     jaPassou: false
//   },
//   // ... outros feriados
// ]

// Verificar se uma data é feriado
const feriado = horario.obterFeriadoPorData('2025-01-01');
if (feriado) {
  console.log(`${feriado.nome}: ${feriado.observacoes}`);
}

// Obter apenas feriados futuros
const feriadosFuturos = horario.obterFeriadosFuturos();
```

### 💼 Casos de Uso por Localização

#### 🇧🇷 **Brasil - E-commerce Nacional**
```typescript
// Loja online brasileira
const horarioEcommerce = incluir({ 
  nacionais: true, 
  estaduais: ["SP", "RJ", "MG"] // Principais estados
});

const horario = horarioEcommerce.criarHorarioComercial({
  segunda: { abertura: '08:00', fechamento: '18:00' },
  terca: { abertura: '08:00', fechamento: '18:00' },
  quarta: { abertura: '08:00', fechamento: '18:00' },
  quinta: { abertura: '08:00', fechamento: '18:00' },
  sexta: { abertura: '08:00', fechamento: '18:00' }
});

// Verificar se está aberto (considera feriados brasileiros)
console.log(horario.estaAberto()); // true/false
```

#### 🇵🇹 **Portugal - Sistema Bancário**
```typescript
// Sistema bancário português
const horarioBanco = incluir({ 
  nacionais: true, 
  estaduais: "LIS", 
  location: "pt-PT" 
});

const horario = horarioBanco.criarHorarioComercial({
  segunda: { abertura: '09:00', fechamento: '15:00' },
  terca: { abertura: '09:00', fechamento: '15:00' },
  quarta: { abertura: '09:00', fechamento: '15:00' },
  quinta: { abertura: '09:00', fechamento: '15:00' },
  sexta: { abertura: '09:00', fechamento: '15:00' }
});

// Verificar se o banco está aberto (considera feriados portugueses)
console.log(horario.estaAberto()); // true/false
```

#### 🇺🇸 **Estados Unidos - SaaS Internacional**
```typescript
// SaaS com clientes americanos
const horarioSaaS = incluir({ 
  nacionais: true, 
  estaduais: ["CA", "NY", "TX"], 
  location: "en-US" 
});

const horario = horarioSaaS.criarHorarioComercial({
  segunda: { abertura: '09:00', fechamento: '17:00' },
  terca: { abertura: '09:00', fechamento: '17:00' },
  quarta: { abertura: '09:00', fechamento: '17:00' },
  quinta: { abertura: '09:00', fechamento: '17:00' },
  sexta: { abertura: '09:00', fechamento: '17:00' }
});

// Verificar se o suporte está disponível (considera feriados americanos)
console.log(horario.estaAberto()); // true/false
```

### 🔄 Migração Entre Localizações

```typescript
import { incluir } from "@phdiniiz/comercialTime";

// Migrar de Brasil para Portugal
const horarioBrasil = incluir({ nacionais: true, estaduais: "SP" });
const horarioPortugal = incluir({ 
  nacionais: true, 
  estaduais: "LIS", 
  location: "pt-PT" 
});

// Comparar feriados entre localizações
const feriadosBrasil = horarioBrasil.nacionais();
const feriadosPortugal = horarioPortugal.nacionais();

console.log(`Brasil: ${feriadosBrasil.length} feriados nacionais`);
console.log(`Portugal: ${feriadosPortugal.length} feriados nacionais`);

// Verificar se uma data é feriado em ambas as localizações
const data = '2025-01-01';
const feriadoBrasil = horarioBrasil.obterFeriadoPorData(data);
const feriadoPortugal = horarioPortugal.obterFeriadoPorData(data);

console.log('Brasil:', feriadoBrasil?.nome); // "Confraternização Universal"
console.log('Portugal:', feriadoPortugal?.nome); // "Dia de Ano Novo"
```

### 🌐 Suporte Multi-localização

```typescript
// Sistema que suporta múltiplas localizações
class SistemaMultiLocalizacao {
  private localizacoes = {
    'pt-BR': incluir({ nacionais: true, estaduais: "SP" }),
    'pt-PT': incluir({ nacionais: true, estaduais: "LIS", location: "pt-PT" }),
    'en-US': incluir({ nacionais: true, estaduais: "CA", location: "en-US" })
  };

  verificarHorarioComercial(localizacao: string, horario: any) {
    const sistema = this.localizacoes[localizacao];
    if (!sistema) {
      throw new Error(`Localização ${localizacao} não suportada`);
    }
    
    return sistema.criarHorarioComercial(horario);
  }

  obterFeriados(localizacao: string) {
    const sistema = this.localizacoes[localizacao];
    return sistema ? sistema.nacionais() : [];
  }
}

// Uso
const sistema = new SistemaMultiLocalizacao();
const horarioBrasil = sistema.verificarHorarioComercial('pt-BR', {
  segunda: { abertura: '08:00', fechamento: '18:00' }
});
const horarioEUA = sistema.verificarHorarioComercial('en-US', {
  segunda: { abertura: '09:00', fechamento: '17:00' }
});
```

### Estrutura do Feriado

```typescript
interface Feriado {
  nome: string;        // Nome do feriado
  data: string;        // Data no formato YYYY-MM-DD
  observacoes: string; // Descrição do feriado
}
```

### Feriados Estaduais Disponíveis

```typescript
// Estados disponíveis
const estados = [
  "SP", // São Paulo - Revolução Constitucionalista (09/07)
  "RJ", // Rio de Janeiro - São Sebastião (20/01), Dia do Estado (23/04)
  "MG", // Minas Gerais - Inconfidência Mineira (21/04)
  "RS", // Rio Grande do Sul - Revolução Farroupilha (20/09)
  "PR", // Paraná - Emancipação Política (19/12)
  "SC", // Santa Catarina - Dia de Santa Catarina (25/11)
  "BA", // Bahia - Independência da Bahia (02/07)
  "PE", // Pernambuco - Revolução Pernambucana (06/03)
  "CE", // Ceará - Dia do Ceará (25/03)
  "GO"  // Goiás - Dia do Goiano (25/07)
];

// Exemplo de uso
const feriadosSP = comercialTime.estaduais("SP");
console.log(feriadosSP);
// [
//   {
//     nome: "Revolução Constitucionalista",
//     data: "2025-07-09",
//     observacoes: "Data magna do estado de São Paulo."
//   }
// ]
```

## 🚀 Como Implementar em Seu Projeto

### 1. **Projeto Node.js/Express**

```bash
# Instalar o módulo
npm install @phdiniiz/comercialTime

# Criar arquivo .env
echo "TIMEZONE=America/Sao_Paulo" > .env
```

```typescript
// server.ts
import express from 'express';
import comercialTime, { incluir } from '@phdiniiz/comercialTime';

const app = express();
const port = 3000;

// Configurar horário comercial com feriados nacionais + SP
const horarioCompleto = incluir({ nacionais: true, estaduais: "SP" });
const horario = horarioCompleto.criarHorarioComercial({
  segunda: { abertura: '08:00', fechamento: '18:00' },
  terca: { abertura: '08:00', fechamento: '18:00' },
  quarta: { abertura: '08:00', fechamento: '18:00' },
  quinta: { abertura: '08:00', fechamento: '18:00' },
  sexta: { abertura: '08:00', fechamento: '18:00' },
  sabado: { abertura: '09:00', fechamento: '13:00' }
});

// API para verificar status
app.get('/status', (req, res) => {
  const status = {
    estaAberto: horario.estaAberto(),
    proximaAbertura: horario.proximaAbertura(),
    proximoFechamento: horario.proximoFechamento(),
    minutosRestantes: horario.minutosRestantesHoje()
  };
  
  res.json(status);
});

// API para adicionar minutos úteis
app.post('/calcular', (req, res) => {
  const { data, minutos } = req.body;
  const novaData = horario.adicionarMinutosUteis(data, minutos);
  res.json({ novaData });
});

// API para listar feriados
app.get('/feriados', (req, res) => {
  const { tipo } = req.query;
  
  let feriados;
  if (tipo === 'nacionais') {
    feriados = horarioCompleto.nacionais();
  } else if (tipo === 'estaduais') {
    feriados = horarioCompleto.estaduais('SP');
  } else {
    feriados = horario.obterFeriados();
  }
  
  res.json(feriados);
});

app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});
```

### 2. **Projeto Next.js**

```bash
# Instalar o módulo
npm install @phdiniiz/comercialTime

# Criar arquivo .env.local
echo "TIMEZONE=America/Sao_Paulo" > .env.local
```

```typescript
// lib/horario.ts
import { incluir } from '@phdiniiz/comercialTime';

// Configurar com feriados nacionais + estaduais do RJ
const horarioCompleto = incluir({ nacionais: true, estaduais: "RJ" });
export const horarioComercial = horarioCompleto.criarHorarioComercial({
  segunda: { abertura: '08:00', fechamento: '18:00' },
  terca: { abertura: '08:00', fechamento: '18:00' },
  quarta: { abertura: '08:00', fechamento: '18:00' },
  quinta: { abertura: '08:00', fechamento: '18:00' },
  sexta: { abertura: '08:00', fechamento: '18:00' },
  sabado: { abertura: '09:00', fechamento: '13:00' }
});

// Exportar também o gerenciador de feriados
export { horarioCompleto };
```

```typescript
// app/api/status/route.ts
import { NextResponse } from 'next/server';
import { horarioComercial } from '@/lib/horario';

export async function GET() {
  const status = {
    estaAberto: horarioComercial.estaAberto(),
    proximaAbertura: horarioComercial.proximaAbertura(),
    proximoFechamento: horarioComercial.proximoFechamento(),
    minutosRestantes: horarioComercial.minutosRestantesHoje()
  };
  
  return NextResponse.json(status);
}
```

```tsx
// components/StatusHorario.tsx
'use client';

import { useState, useEffect } from 'react';

interface StatusHorario {
  estaAberto: boolean;
  proximaAbertura: string | null;
  proximoFechamento: string | null;
  minutosRestantes: number;
}

export default function StatusHorario() {
  const [status, setStatus] = useState<StatusHorario | null>(null);

  useEffect(() => {
    fetch('/api/status')
      .then(res => res.json())
      .then(setStatus);
  }, []);

  if (!status) return <div>Carregando...</div>;

  return (
    <div className="p-4 border rounded-lg">
      <h2 className="text-xl font-bold mb-4">Status do Estabelecimento</h2>
      
      <div className={`p-3 rounded ${status.estaAberto ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
        {status.estaAberto ? '🟢 Aberto' : '🔴 Fechado'}
      </div>
      
      {status.estaAberto && (
        <p className="mt-2">Minutos restantes hoje: {status.minutosRestantes}</p>
      )}
      
      {status.proximaAbertura && (
        <p>Próxima abertura: {new Date(status.proximaAbertura).toLocaleString('pt-BR')}</p>
      )}
    </div>
  );
}
```

### 3. **Projeto NestJS**

```bash
# Instalar o módulo
npm install @phdiniiz/comercialTime

# Criar arquivo .env
echo "TIMEZONE=America/Sao_Paulo" > .env
```

```typescript
// src/horario/horario.service.ts
import { Injectable } from '@nestjs/common';
import { HorarioComercial } from '@phdiniiz/comercialTime';

@Injectable()
export class HorarioService {
  private readonly horario: HorarioComercial;

  constructor() {
    this.horario = new HorarioComercial({
      segunda: { abertura: '08:00', fechamento: '18:00' },
      terca: { abertura: '08:00', fechamento: '18:00' },
      quarta: { abertura: '08:00', fechamento: '18:00' },
      quinta: { abertura: '08:00', fechamento: '18:00' },
      sexta: { abertura: '08:00', fechamento: '18:00' },
      sabado: { abertura: '09:00', fechamento: '13:00' }
    });
  }

  verificarStatus() {
    return {
      estaAberto: this.horario.estaAberto(),
      proximaAbertura: this.horario.proximaAbertura(),
      proximoFechamento: this.horario.proximoFechamento(),
      minutosRestantes: this.horario.minutosRestantesHoje()
    };
  }

  adicionarMinutosUteis(data: Date, minutos: number) {
    return this.horario.adicionarMinutosUteis(data, minutos);
  }
}
```

```typescript
// src/horario/horario.controller.ts
import { Controller, Get, Post, Body } from '@nestjs/common';
import { HorarioService } from './horario.service';

@Controller('horario')
export class HorarioController {
  constructor(private readonly horarioService: HorarioService) {}

  @Get('status')
  getStatus() {
    return this.horarioService.verificarStatus();
  }

  @Post('calcular')
  calcularMinutosUteis(@Body() body: { data: Date; minutos: number }) {
    return this.horarioService.adicionarMinutosUteis(body.data, body.minutos);
  }
}
```

### 4. **Projeto React (Frontend)**

```bash
# Instalar o módulo
npm install @phdiniiz/comercialTime
```

```typescript
// hooks/useHorarioComercial.ts
import { useState, useEffect } from 'react';
import { HorarioComercial } from '@phdiniiz/comercialTime';

export function useHorarioComercial() {
  const [horario] = useState(() => new HorarioComercial({
    segunda: { abertura: '08:00', fechamento: '18:00' },
    terca: { abertura: '08:00', fechamento: '18:00' },
    quarta: { abertura: '08:00', fechamento: '18:00' },
    quinta: { abertura: '08:00', fechamento: '18:00' },
    sexta: { abertura: '08:00', fechamento: '18:00' },
    sabado: { abertura: '09:00', fechamento: '13:00' }
  }));

  const [status, setStatus] = useState({
    estaAberto: false,
    proximaAbertura: null as Date | null,
    proximoFechamento: null as Date | null,
    minutosRestantes: 0
  });

  useEffect(() => {
    const atualizarStatus = () => {
      setStatus({
        estaAberto: horario.estaAberto(),
        proximaAbertura: horario.proximaAbertura(),
        proximoFechamento: horario.proximoFechamento(),
        minutosRestantes: horario.minutosRestantesHoje()
      });
    };

    atualizarStatus();
    const interval = setInterval(atualizarStatus, 60000); // Atualiza a cada minuto

    return () => clearInterval(interval);
  }, [horario]);

  return { horario, status };
}
```

```tsx
// components/HorarioComercial.tsx
import React from 'react';
import { useHorarioComercial } from '../hooks/useHorarioComercial';

export function HorarioComercial() {
  const { status } = useHorarioComercial();

  return (
    <div className="horario-comercial">
      <div className={`status ${status.estaAberto ? 'aberto' : 'fechado'}`}>
        {status.estaAberto ? '🟢 Aberto' : '🔴 Fechado'}
      </div>
      
      {status.estaAberto && (
        <p>Minutos restantes: {status.minutosRestantes}</p>
      )}
      
      {status.proximaAbertura && (
        <p>Próxima abertura: {status.proximaAbertura.toLocaleString('pt-BR')}</p>
      )}
    </div>
  );
}
```

### 5. **Projeto Vue.js**

```bash
# Instalar o módulo
npm install @phdiniiz/comercialTime
```

```typescript
// composables/useHorarioComercial.ts
import { ref, onMounted, onUnmounted } from 'vue';
import { HorarioComercial } from '@phdiniiz/comercialTime';

export function useHorarioComercial() {
  const horario = new HorarioComercial({
    segunda: { abertura: '08:00', fechamento: '18:00' },
    terca: { abertura: '08:00', fechamento: '18:00' },
    quarta: { abertura: '08:00', fechamento: '18:00' },
    quinta: { abertura: '08:00', fechamento: '18:00' },
    sexta: { abertura: '08:00', fechamento: '18:00' },
    sabado: { abertura: '09:00', fechamento: '13:00' }
  });

  const status = ref({
    estaAberto: false,
    proximaAbertura: null as Date | null,
    proximoFechamento: null as Date | null,
    minutosRestantes: 0
  });

  const atualizarStatus = () => {
    status.value = {
      estaAberto: horario.estaAberto(),
      proximaAbertura: horario.proximaAbertura(),
      proximoFechamento: horario.proximoFechamento(),
      minutosRestantes: horario.minutosRestantesHoje()
    };
  };

  onMounted(() => {
    atualizarStatus();
    const interval = setInterval(atualizarStatus, 60000);
    onUnmounted(() => clearInterval(interval));
  });

  return { horario, status };
}
```

```vue
<!-- components/HorarioComercial.vue -->
<template>
  <div class="horario-comercial">
    <div :class="['status', status.estaAberto ? 'aberto' : 'fechado']">
      {{ status.estaAberto ? '🟢 Aberto' : '🔴 Fechado' }}
    </div>
    
    <p v-if="status.estaAberto">
      Minutos restantes: {{ status.minutosRestantes }}
    </p>
    
    <p v-if="status.proximaAbertura">
      Próxima abertura: {{ status.proximaAbertura.toLocaleString('pt-BR') }}
    </p>
  </div>
</template>

<script setup lang="ts">
import { useHorarioComercial } from '../composables/useHorarioComercial';

const { status } = useHorarioComercial();
</script>
```


## 🎯 Uso Básico

### Verificar se está aberto

```typescript
import { HorarioComercial } from '@phdiniiz/comercialTime';

// Configurar horário comercial com timezone
const horario = new HorarioComercial({
  segunda: { abertura: '08:00', fechamento: '18:00' },
  terca: { abertura: '08:00', fechamento: '18:00' },
  quarta: { abertura: '08:00', fechamento: '18:00' },
  quinta: { abertura: '08:00', fechamento: '18:00' },
  sexta: { abertura: '08:00', fechamento: '18:00' },
  sabado: { abertura: '09:00', fechamento: '13:00' }
})
.setTimezone('America/Sao_Paulo'); // ✨ NOVO: Method chaining

// ✨ NOVO: Verificar status atual automaticamente (baseado no timezone)
console.log(horario.openedNow); // true/false - sempre atualizado
console.log(horario.getTimezone()); // 'America/Sao_Paulo'

// Verificar se está aberto agora
console.log(horario.estaAberto()); // true/false

// Verificar em uma data específica
console.log(horario.estaAberto('2024-01-08 14:30')); // true/false
```

### Obter próximas aberturas/fechamentos

```typescript
// Próxima abertura
const proximaAbertura = horario.proximaAbertura();
console.log(proximaAbertura); // 2024-01-09T08:00:00.000Z

// Próximo fechamento
const proximoFechamento = horario.proximoFechamento();
console.log(proximoFechamento); // 2024-01-08T18:00:00.000Z

// Minutos restantes hoje
const minutosRestantes = horario.minutosRestantesHoje();
console.log(minutosRestantes); // 240 (4 horas)
```

### Adicionar minutos úteis

```typescript
// Adicionar 2 horas úteis a partir de agora
const novaData = horario.adicionarMinutosUteis(new Date(), 120);
console.log(novaData); // 2024-01-08T16:30:00.000Z

// Adicionar 1 dia útil
const umDiaUtil = horario.adicionarMinutosUteis(new Date(), 480); // 8 horas
console.log(umDiaUtil); // 2024-01-09T08:00:00.000Z
```

## 🏗️ Arquitetura

O projeto segue uma **arquitetura simplificada e unificada** com as seguintes camadas:

```
src/
├── domain/           # Entidades e regras de negócio
│   ├── entities/     # HorarioComercial, Intervalo
│   └── value-objects/ # Value Objects
├── infrastructure/   # Implementações técnicas
│   └── utils/        # Utilitários (time, normalize, timezone)
├── config/           # Configurações globais
│   └── timezone.config.ts # Configuração de timezone
├── security/         # Validações e proteções
│   ├── validators/   # Validadores de entrada
│   └── rate-limiter/ # Rate limiting
├── performance/      # Otimizações
│   └── cache/        # Gerenciamento de cache
├── locale/           # Dados localizados
│   ├── pt-br/        # Dados em português brasileiro
│   │   ├── feriados-nacionais.json
│   │   └── feriados-estaduais.json
│   ├── pt-PT/        # Dados em português de Portugal
│   │   ├── feriados-nacionais.json
│   │   └── feriados-estaduais.json
│   └── en-US/        # Dados em inglês americano
│       ├── feriados-nacionais.json
│       └── feriados-estaduais.json
├── core/             # Sistema de importação modular
│   └── comercial-time.ts # Classe principal modular
├── cronjob/          # Sistema de atualização automática
│   └── feriado-update.cronjob.ts # CRONJOB de feriados
├── application/      # Casos de uso e serviços
│   ├── services/     # Serviços de aplicação
│   └── use-cases/    # Casos de uso
├── presentation/     # Controllers e interfaces
│   ├── controllers/  # Controllers
│   └── factories/    # Factories
├── index.ts          # ✨ NOVO: Arquivo principal unificado
├── index.cjs.ts      # ✨ NOVO: Versão CommonJS
└── legacy/           # Classe principal unificada
    └── horario-comercial.legacy.ts # Classe principal com toda a lógica
```

### ✨ **Arquitetura Unificada**

**✨ NOVO:** A partir desta versão, todas as funcionalidades de inicialização foram migradas para os arquivos principais:

- **`index.ts`** - Arquivo principal ESM com todas as funcionalidades
- **`index.cjs.ts`** - Versão CommonJS para compatibilidade
- **Remoção do `main.ts`** - Funcionalidades consolidadas nos arquivos principais

**Benefícios:**
- ✅ **Importação simplificada** - Todas as funções em um local
- ✅ **Melhor organização** - Estrutura mais limpa e intuitiva
- ✅ **Compatibilidade total** - Suporte ESM e CommonJS
- ✅ **Manutenção facilitada** - Código centralizado

### ✨ **Arquitetura Simplificada**

- **Classe Unificada**: Toda a lógica de negócio está na classe `HorarioComercial`
- **Timezone por Instância**: Cada instância mantém seu próprio timezone
- **Method Chaining**: API fluente com `setTimezone()`
- **Compatibilidade**: Mantém toda a API existente

## 🔒 Segurança

### Validações de Entrada

```typescript
import { InputValidator } from '@phdiniiz/comercialTime';

// Validação de horário
InputValidator.validateHorarioInput('14:30'); // ✅ true
InputValidator.validateHorarioInput('25:00'); // ❌ false
InputValidator.validateHorarioInput('08:00<script>'); // ❌ false (XSS bloqueado)

// Validação de data
InputValidator.validateDateInput('2024-01-08'); // ✅ true
InputValidator.validateDateInput('1800-01-01'); // ❌ false (muito antiga)
```

### Rate Limiting Avançado

```typescript
import { AdvancedRateLimiter } from '@phdiniiz/comercialTime';

const limiter = new AdvancedRateLimiter({
  maxRequests: 1000,        // 1000 requests por minuto
  windowMs: 60000,          // Janela de 1 minuto
  debounceMs: 100,          // 100ms de debounce
  throttleMs: 50,           // 50ms de throttle
  circuitBreakerThreshold: 5, // 5 falhas para abrir circuit breaker
  circuitBreakerTimeout: 30000 // 30 segundos de timeout
});

// Verificar se requisição é permitida
const result = limiter.isAllowed('user123');
if (result.allowed) {
  // Processar requisição
} else {
  console.log(`Bloqueado: ${result.reason}, retry em ${result.retryAfter}ms`);
}
```

## ⚡ Performance

### Cache Inteligente

```typescript
import { OptimizedHorarioComercialService } from '@phdiniiz/comercialTime';

const service = new OptimizedHorarioComercialService({
  ttl: 300000, // 5 minutos de cache
  maxSize: 1000 // Máximo 1000 entradas
});

// Primeira chamada: calcula e armazena no cache
const result1 = service.estaAberto('2024-01-08 14:30');

// Segunda chamada: retorna do cache (muito mais rápido)
const result2 = service.estaAberto('2024-01-08 14:30');
```

## 🧪 Testes

```bash
# Executar todos os testes
pnpm test

# Executar com cobertura
pnpm test -- --coverage

# Executar testes em modo watch
pnpm test -- --watch
```

### Cobertura de Testes

- **Branches**: 80%
- **Functions**: 80%
- **Lines**: 80%
- **Statements**: 80%

## 📚 API Completa

### HorarioComercial

```typescript
class HorarioComercial {
  constructor(horario: Record<DiaChave, Intervalo[]>)
  
  // Verificações
  estaAberto(data?: Date | string): boolean
  proximaAbertura(data?: Date | string): Date | null
  proximoFechamento(data?: Date | string): Date | null
  minutosRestantesHoje(data?: Date | string): number
  
  // ✨ NOVO: Status atual baseado no timezone
  get openedNow(): boolean
  
  // ✨ NOVO: Configuração de timezone (Method Chaining)
  setTimezone(timezone: string): this
  getTimezone(): string
  
  // Operações
  adicionarMinutosUteis(data: Date | string, minutos: number): Date
  obterHorario(): Record<string, readonly Intervalo[]>
  
  // Feriados
  obterFeriados(): readonly Feriado[]
  obterDatasFeriados(): readonly string[]
  obterFeriadoPorData(data: Date | string): Feriado | undefined
  obterFeriadosFuturos(): readonly Feriado[]
  obterFeriadosPassados(): readonly Feriado[]
  
  // Sistema Modular
  nacionais(): readonly Feriado[]
  estaduais(sigla: string): readonly Feriado[]
  obterEstadosDisponiveis(): readonly string[]
  estadoDisponivel(sigla: string): boolean
  obterLocalizacaoUsada(): string
  estaUsandoFeriadosPersonalizados(): boolean
  obterInfoFeriados(): { total: number; nacionais: number; estaduais: number; localizacao: string; usandoPersonalizados: boolean; estadosDisponiveis: string[] }
}
```

### Utilitários

```typescript
// Conversão de tempo
horaParaMinutos('14:30'): number // 870
minutosParaHora(870): string // '14:30'

// Normalização
normalizarDia('segunda'): DiaChave // 'segunda'
normalizarHorario('08:00'): HoraString // '08:00'

// Índices
diaIndex('segunda'): number // 1
minutosDoDia('14:30'): number // 870

// Feriados
carregarFeriados(): readonly Feriado[]
obterFeriadosFuturos(feriados: readonly Feriado[]): readonly Feriado[]
obterFeriadosPassados(feriados: readonly Feriado[]): readonly Feriado[]
ehFeriado(data: Date | string, feriados: readonly Feriado[]): boolean
obterFeriadoPorData(data: Date | string, feriados: readonly Feriado[]): Feriado | undefined

// Feriados Personalizados
carregarFeriadosPersonalizados(): { nacionais: Feriado[]; estaduais: Record<string, Feriado[]> } | null
feriadosPersonalizadosDisponiveis(): boolean
obterInfoFeriadosPersonalizados(): { disponivel: boolean; quantidadeNacionais: number; quantidadeEstaduais: number; total: number; exemploNacional?: Feriado; exemploEstadual?: Feriado; estadosDisponiveis: string[] }

// ✨ NOVO: Sistema de Inicialização (migrado do main.ts)
inicializar(timezone: string, opcoes?: Omit<InicializacaoConfig, "timezone">): Promise<InicializacaoResult>
inicializarRapido(timezone: string): Promise<InicializacaoResult>
inicializarComercialTime(config: InicializacaoConfig): Promise<InicializacaoResult>
inicializarComercialTimeComTimezone(timezone: string, opcoes?: Omit<InicializacaoConfig, "timezone">): Promise<InicializacaoResult>
inicializarParaBrasil(opcoes?: Omit<InicializacaoConfig, "timezone">): Promise<InicializacaoResult>
inicializarParaEUA(opcoes?: Omit<InicializacaoConfig, "timezone">): Promise<InicializacaoResult>
inicializarParaPortugal(opcoes?: Omit<InicializacaoConfig, "timezone">): Promise<InicializacaoResult>
obterInfoTimezone(): { timezone: string; pais: string; locale: string; capital: string }
estaInicializado(): boolean

// CRONJOB de Atualização
inicializarCronJobFeriados(): void
inicializarCronJobFeriadosPorPais(pais: string): void
executarAtualizacaoManual(pais?: string): Promise<void>
FeriadoUpdateFactory.create(config: FeriadoUpdateConfig): FeriadoUpdateController
FeriadoUpdateFactory.createDefault(): FeriadoUpdateController
FeriadoUpdateFactory.createForCountry(pais: string): FeriadoUpdateController
```

## 🌍 Configuração de Timezone

### Configurar Timezone por Instância

```typescript
import { HorarioComercial, setTimezone, getCurrentTimezone, timezoneManager } from '@phdiniiz/comercialTime';

// ✨ NOVO: Method chaining na instância (Recomendado)
const horarioBrasil = new HorarioComercial({
  segunda: { abertura: '08:00', fechamento: '18:00' }
})
.setTimezone('America/Sao_Paulo'); // Brasil

// ✨ NOVO: Carregamento automático do .env
const horarioEnv = new HorarioComercial({
  segunda: { abertura: '08:00', fechamento: '18:00' }
})
.setTimezone(); // Usa TIMEZONE do arquivo .env ou fallback para America/Sao_Paulo

const horarioEUA = new HorarioComercial({
  segunda: { abertura: '09:00', fechamento: '17:00' }
})
.setTimezone('America/New_York'); // EUA

// Cada instância mantém seu próprio timezone
console.log(horarioBrasil.getTimezone()); // 'America/Sao_Paulo'
console.log(horarioEUA.getTimezone()); // 'America/New_York'

// Ou configurar globalmente (afeta todas as instâncias)
setTimezone('America/Sao_Paulo'); // Brasil
setTimezone('America/New_York');  // EUA
setTimezone('Europe/London');     // Reino Unido
setTimezone('Asia/Tokyo');        // Japão

// Verificar timezone global atual
console.log(getCurrentTimezone()); // 'America/Sao_Paulo'

// Configuração avançada
timezoneManager.updateConfig({
  defaultTimezone: 'America/Sao_Paulo',
  fallbackTimezone: 'UTC',
  autoDetect: true // Detecta automaticamente o timezone do sistema
});
```

### Utilitários de Timezone

```typescript
import { 
  getNowInTimezone, 
  formatDateInTimezone, 
  getTimeInTimezone,
  getDayNameInTimezone 
} from '@phdiniiz/comercialTime';

// Obter data atual no timezone configurado
const agora = getNowInTimezone();

// Formatar data no timezone
const formatada = formatDateInTimezone(new Date(), {
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit'
});

// Obter apenas a hora
const hora = getTimeInTimezone(); // "14:30"

// Obter nome do dia
const dia = getDayNameInTimezone(); // "segunda"
```

## 🔧 Configuração

### Configuração via Arquivo .env

O sistema agora suporta carregamento automático do timezone através de variáveis de ambiente:

```bash
# .env
TIMEZONE=America/Sao_Paulo
```

```typescript
import { HorarioComercial } from '@phdiniiz/comercialTime';

// Carrega automaticamente o timezone do .env
const horario = new HorarioComercial({
  segunda: { abertura: '08:00', fechamento: '18:00' }
}).setTimezone(); // Sem parâmetro = usa TIMEZONE do .env

console.log(horario.getTimezone()); // 'America/Sao_Paulo' (do .env)
```

**Comportamento:**

- ✅ **Sempre busca no `.env` primeiro** - `process.env.TIMEZONE`
- ✅ Se `TIMEZONE` estiver definido no `.env` e for válido → usa o valor
- ✅ Se `TIMEZONE` não estiver definido no `.env` → usa `America/Sao_Paulo` como fallback
- ✅ Se `TIMEZONE` for inválido no `.env` → usa `America/Sao_Paulo` como fallback
- ✅ Timezone explícito sempre sobrescreve o valor do `.env`

### TypeScript

```json
{
  "compilerOptions": {
    "target": "ES2024",
    "module": "ESNext",
    "lib": ["ES2024", "DOM"],
    "moduleResolution": "node",
    "esModuleInterop": true,
    "allowSyntheticDefaultImports": true,
    "strict": true
  }
}
```

### Jest

```javascript
// jest.config.js
export default {
  preset: 'ts-jest',
  testEnvironment: 'node',
  extensionsToTreatAsEsm: ['.ts'],
  globals: {
    'ts-jest': {
      useESM: true,
    },
  },
};
```

## 📋 Requisitos

- **Node.js**: >= 22.0.0
- **TypeScript**: >= 5.7.2
- **Suporte a ESM**: Obrigatório

## 🌍 Compatibilidade

### Sistemas Operacionais

- ✅ Windows 10/11
- ✅ macOS 10.15+
- ✅ Linux (Ubuntu 18.04+)

### Ambientes

- ✅ Node.js (ESM)
- ✅ Deno
- ✅ Bun
- ✅ Browsers modernos (com bundler)

### Frameworks

- ✅ Next.js 15+
- ✅ NestJS
- ✅ Express.js
- ✅ Fastify

## 🔄 Migração e Mudanças

### ✨ **Nova Arquitetura Unificada**

**A partir desta versão, o módulo passou por uma reestruturação significativa:**

#### **Antes (main.ts separado):**
```typescript
// ❌ ANTIGO: Importações separadas
import { inicializar } from "@phdiniiz/comercialTime";
import { inicializarCronJobFeriados } from "@phdiniiz/comercialTime/cronjob";
```

#### **Agora (tudo em index.ts):**
```typescript
// ✅ NOVO: Importação unificada
import { 
  inicializar, 
  inicializarCronJobFeriados,
  inicializarRapido,
  obterInfoTimezone 
} from "@phdiniiz/comercialTime";
```

#### **Benefícios da Migração:**

- ✅ **Importação simplificada** - Todas as funções em um local
- ✅ **Melhor organização** - Estrutura mais limpa e intuitiva
- ✅ **Compatibilidade total** - Suporte ESM e CommonJS
- ✅ **Manutenção facilitada** - Código centralizado
- ✅ **Inicialização rápida** - Sistema otimizado para não bloquear a tela

#### **Arquivos Removidos:**
- ❌ `src/main.ts` - Funcionalidades migradas para `index.ts`

#### **Arquivos Atualizados:**
- ✅ `src/index.ts` - Arquivo principal com todas as funcionalidades
- ✅ `src/index.cjs.ts` - Versão CommonJS atualizada

### 🔧 **Compatibilidade**

**A migração mantém 100% de compatibilidade com versões anteriores:**

```typescript
// ✅ Funciona exatamente igual
import { inicializar } from "@phdiniiz/comercialTime";
await inicializar("America/Sao_Paulo");
```

**Nenhuma mudança é necessária no código existente!**

## 📖 Exemplos

### Exemplo Completo

```typescript
import { 
  HorarioComercial, 
  horaParaMinutos, 
  normalizarDia,
  getTimeInTimezone,
  inicializar,
  inicializarRapido,
  obterInfoTimezone
} from '@phdiniiz/comercialTime';

// ✨ NOVO: Inicializar o módulo com timezone obrigatório
console.log('🚀 Inicializando módulo...');
const resultadoInicializacao = await inicializarRapido('America/Sao_Paulo');
console.log('✅ Módulo inicializado:', resultadoInicializacao.sucesso);

// ✨ NOVO: Obter informações do timezone
const infoTimezone = obterInfoTimezone();
console.log('🌍 Informações do timezone:', infoTimezone);

// ✨ NOVO: Configurar horário comercial com timezone (Method Chaining)
const horario = new HorarioComercial({
  segunda: { abertura: '08:00', fechamento: '18:00' },
  terca: { abertura: '08:00', fechamento: '18:00' },
  quarta: { abertura: '08:00', fechamento: '18:00' },
  quinta: { abertura: '08:00', fechamento: '18:00' },
  sexta: { abertura: '08:00', fechamento: '18:00' },
  sabado: { abertura: '09:00', fechamento: '13:00' }
})
.setTimezone('America/Sao_Paulo'); // ✨ NOVO: Method chaining

console.log('Timezone atual:', horario.getTimezone()); // ✨ NOVO
console.log('Hora atual no timezone:', getTimeInTimezone());

// ✨ NOVO: Verificar status atual automaticamente
console.log('Status atual (openedNow):', horario.openedNow);

// Verificar status detalhado
const status = {
  estaAberto: horario.estaAberto(),
  openedNow: horario.openedNow, // ✨ NOVO
  proximaAbertura: horario.proximaAbertura(),
  proximoFechamento: horario.proximoFechamento(),
  minutosRestantes: horario.minutosRestantesHoje()
};

console.log('Status completo:', status);

// Adicionar 2 horas úteis
const agora = new Date();
const em2Horas = horario.adicionarMinutosUteis(agora, 120);
console.log('Em 2 horas úteis:', em2Horas);

// Usar utilitários
const minutos = horaParaMinutos('14:30');
const dia = normalizarDia('segunda');
console.log('Minutos:', minutos, 'Dia:', dia);

// Trabalhar com feriados
const feriados = horario.obterFeriados();
console.log('Total de feriados:', feriados.length);

const feriadosFuturos = horario.obterFeriadosFuturos();
console.log('Feriados futuros:', feriadosFuturos.length);

// Verificar se uma data específica é feriado
const feriado = horario.obterFeriadoPorData('2025-01-01');
if (feriado) {
  console.log(`Feriado: ${feriado.nome} - ${feriado.observacoes}`);
}

// Trabalhar com sistema modular (importação unificada)
import comercialTime, { incluir, inicializarCronJobFeriados } from '@phdiniiz/comercialTime';

// Configurar com feriados nacionais + estaduais de SP e RJ
const horarioModular = incluir({ 
  nacionais: true, 
  estaduais: ["SP", "RJ"] 
});

// Acessar feriados específicos
const feriadosNacionais = horarioModular.nacionais();
const feriadosSP = horarioModular.estaduais("SP");
const feriadosRJ = horarioModular.estaduais("RJ");

console.log('Feriados nacionais:', feriadosNacionais.length);
console.log('Feriados SP:', feriadosSP.length);
console.log('Feriados RJ:', feriadosRJ.length);

// Exemplos com diferentes localizações
import { incluir } from '@phdiniiz/comercialTime';

// Portugal
const horarioPortugal = incluir({ 
  nacionais: true, 
  estaduais: "LIS", 
  location: "pt-PT" 
});
console.log('Feriados de Lisboa:', horarioPortugal.estaduais("LIS"));

// Estados Unidos
const horarioEUA = incluir({ 
  nacionais: true, 
  estaduais: "CA", 
  location: "en-US" 
});
console.log('Feriados da Califórnia:', horarioEUA.estaduais("CA"));

// Feriados personalizados (prioridade máxima)
process.env.PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON = JSON.stringify({
  nacionais: [
    {
      nome: "Dia da Empresa",
      data: "2025-03-15",
      observacoes: "Aniversário da nossa empresa - feriado corporativo."
    }
  ],
  estaduais: {
    "SP": [
      {
        nome: "Dia da Revolução Constitucionalista Personalizada",
        data: "2025-07-09",
        observacoes: "Nossa versão personalizada do feriado de SP."
      }
    ]
  }
});

const horarioPersonalizado = incluir({ nacionais: true });
console.log('Localização:', horarioPersonalizado.obterLocalizacaoUsada()); // "personalizado"
console.log('Usando personalizados:', horarioPersonalizado.estaUsandoFeriadosPersonalizados()); // true
```

### Exemplo com Rate Limiting

```typescript
import { AdvancedRateLimiter, RateLimiterManager } from '@phdiniiz/comercialTime';

// Rate limiter personalizado
const limiter = new AdvancedRateLimiter({
  maxRequests: 100,
  windowMs: 60000,
  debounceMs: 500,
  throttleMs: 200
});

// Verificar antes de processar
const result = limiter.isAllowed('user123');
if (result.allowed) {
  // Processar requisição
  console.log('Requisição processada');
} else {
  console.log(`Rate limit: ${result.reason}, retry em ${result.retryAfter}ms`);
}

// Usar manager para diferentes cenários
const manager = new RateLimiterManager();
const horarioResult = manager.checkHorarioComercial('user123');
const validacaoResult = manager.checkValidacao('user123');
```

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

### Padrões de Código

- **Clean Code**: Código limpo e legível
- **Clean Architecture**: Separação de responsabilidades
- **TDD**: Testes antes da implementação
- **TypeScript**: Tipagem forte
- **ESLint**: Linting automático
- **Prettier**: Formatação consistente

## 📄 Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 👨‍💻 Autor

**@phdiniiz/comercialTime**

- GitHub: [@PHDiniiz](https://github.com/PHDiniiz)
- NPM: [@phdiniiz/comercialTime](https://www.npmjs.com/package/@phdiniiz/comercialTime)

## 🙏 Agradecimentos

- Comunidade TypeScript
- Equipe do Node.js
- Contribuidores do projeto

## 📊 Estatísticas

![GitHub stars](https://img.shields.io/github/stars/phdiniiz/comercialHours?style=social)
![GitHub forks](https://img.shields.io/github/forks/phdiniz/comercialHours?style=social)
![GitHub issues](https://img.shields.io/github/issues/phdiniz/comercialHours)
![GitHub pull requests](https://img.shields.io/github/issues-pr/phdiniz/comercialHours)

---

**⭐ Se este projeto foi útil para você, considere dar uma estrela!**
