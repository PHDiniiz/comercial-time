# @phdiniiz/comercialTime

[![npm version](https://badge.fury.io/js/%40phdiniz%2FcomercialHours.svg)](https://badge.fury.io/js/%40phdiniz%2FcomercialHours)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Node.js Version](https://img.shields.io/badge/node-%3E%3D22.0.0-brightgreen.svg)](https://nodejs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.7.2-blue.svg)](https://www.typescriptlang.org/)

> **Ferramentas em TypeScript para horário comercial (pt-BR) — HorarioComercial**

Uma biblioteca completa e robusta para gerenciamento de horários comerciais em português brasileiro, implementada com Clean Architecture, validações de segurança e otimizações de performance.

## 🚀 Características

- ✅ **API em Português (pt-BR)** - Interface totalmente em português brasileiro
- ✅ **Clean Architecture** - Código organizado em camadas bem definidas
- ✅ **TypeScript First** - Tipagem forte e IntelliSense completo
- ✅ **Validações de Segurança** - Proteção contra XSS, SQL Injection, DoS
- ✅ **Rate Limiting Avançado** - Debounce, Throttle, Circuit Breaker
- ✅ **Performance Otimizada** - Cache inteligente e operações eficientes
- ✅ **Testes Automatizados** - Cobertura completa com Jest
- ✅ **ESM Nativo** - Suporte completo a módulos ES2024
- ✅ **Zero Dependencies** - Sem dependências externas

## 📦 Instalação

```bash
# Usando pnpm (recomendado)
pnpm add @phdiniiz/comercialTime

# Usando npm
npm install @phdiniiz/comercialTime

# Usando yarn
yarn add @phdiniiz/comercialTime
```

## 🚀 Inicialização com Timezone Obrigatório

### ⚠️ **IMPORTANTE: Timezone é Obrigatório**

A partir desta versão, o módulo **requer** que você especifique o timezone durante a inicialização. O padrão é **pt-BR (America/Sao_Paulo)**.

```typescript
import { inicializar } from "@phdiniiz/comercialTime";

// ✅ CORRETO: Inicializar com timezone específico
await inicializar("America/Sao_Paulo"); // Brasil (pt-BR)
await inicializar("America/New_York");  // EUA (en-US)
await inicializar("Europe/Lisbon");     // Portugal (pt-PT)

// ❌ INCORRETO: Tentar inicializar sem timezone
// await inicializar(); // ERRO: Timezone é obrigatório
```

### Inicialização por País

```typescript
import { 
  inicializarParaBrasil,
  inicializarParaEUA,
  inicializarParaPortugal 
} from "@phdiniiz/comercialTime";

// Inicialização específica por país
await inicializarParaBrasil();     // America/Sao_Paulo
await inicializarParaEUA();        // America/New_York
await inicializarParaPortugal();   // Europe/Lisbon
```

### ⚡ Inicialização Rápida

Para aplicações que precisam de inicialização mais rápida (sem aguardar atualização de feriados):

```typescript
import { inicializarRapido } from "@phdiniiz/comercialTime";

// Inicialização rápida - não inicia CRONJOB automaticamente
const resultado = await inicializarRapido("America/Sao_Paulo");
console.log("✅ Aplicação inicializada rapidamente:", resultado.sucesso);
```

## 🎯 Uso Básico

### Verificar se está aberto

```typescript
import { HorarioComercial } from '@phdiniiz/comercialTime';

// Configurar horário comercial com timezone
const horario = new HorarioComercial({
  segunda: { abertura: '08:00', fechamento: '18:00' },
  terca: { abertura: '08:00', fechamento: '18:00' },
  quarta: { abertura: '08:00', fechamento: '18:00' },
  quinta: { abertura: '08:00', fechamento: '18:00' },
  sexta: { abertura: '08:00', fechamento: '18:00' },
  sabado: { abertura: '09:00', fechamento: '13:00' }
})
.setTimezone('America/Sao_Paulo'); // ✨ NOVO: Method chaining

// ✨ NOVO: Verificar status atual automaticamente
console.log(horario.openedNow); // true/false - sempre atualizado

// Verificar se está aberto agora
console.log(horario.estaAberto()); // true/false

// Verificar em uma data específica
console.log(horario.estaAberto('2024-01-08 14:30')); // true/false
```

### Obter próximas aberturas/fechamentos

```typescript
// Próxima abertura
const proximaAbertura = horario.proximaAbertura();
console.log(proximaAbertura); // 2024-01-09T08:00:00.000Z

// Próximo fechamento
const proximoFechamento = horario.proximoFechamento();
console.log(proximoFechamento); // 2024-01-08T18:00:00.000Z

// Minutos restantes hoje
const minutosRestantes = horario.minutosRestantesHoje();
console.log(minutosRestantes); // 240 (4 horas)
```

### Adicionar minutos úteis

```typescript
// Adicionar 2 horas úteis a partir de agora
const novaData = horario.adicionarMinutosUteis(new Date(), 120);
console.log(novaData); // 2024-01-08T16:30:00.000Z

// Adicionar 1 dia útil
const umDiaUtil = horario.adicionarMinutosUteis(new Date(), 480); // 8 horas
console.log(umDiaUtil); // 2024-01-09T08:00:00.000Z
```

## 🌍 Sistema Modular de Feriados

### Importação Seletiva de Feriados

```typescript
import { incluir } from "@phdiniiz/comercialTime";

// Importar apenas feriados nacionais
const horarioNacional = incluir({ nacionais: true });

// Importar feriados nacionais + estaduais de SP
const horarioCompleto = incluir({ 
  nacionais: true, 
  estaduais: "SP" 
});

// Importar feriados de múltiplos estados
const horarioMultiEstados = incluir({ 
  nacionais: true, 
  estaduais: ["SP", "RJ", "MG"] 
});
```

### Localizações Disponíveis

#### 🇧🇷 **Brasil (pt-BR)**
- **Feriados Nacionais**: 9 feriados (Confraternização Universal, Tiradentes, etc.)
- **Estados**: SP, RJ, MG, RS, PR, SC, BA, PE, CE, GO

#### 🇵🇹 **Portugal (pt-PT)**
- **Feriados Nacionais**: 10 feriados (Dia da Liberdade, Dia de Portugal, etc.)
- **Regiões**: LIS, POR, BRA, COI, AVE, SET, FAR, LEI, VSE, GUA

#### 🇺🇸 **Estados Unidos (en-US)**
- **Feriados Nacionais**: 10 feriados (Independence Day, Thanksgiving, etc.)
- **Estados**: CA, NY, TX, FL, IL, MA, LA, HI, AK, NV

### Exemplos de Uso por Localização

```typescript
// Brasil (padrão)
const horarioBrasil = incluir({ nacionais: true, estaduais: "SP" });

// Portugal
const horarioPortugal = incluir({ 
  nacionais: true, 
  estaduais: "LIS", 
  location: "pt-PT" 
});

// Estados Unidos
const horarioEUA = incluir({ 
  nacionais: true, 
  estaduais: "CA", 
  location: "en-US" 
});
```

## 🎯 Feriados Personalizados (Prioridade Máxima)

O módulo suporta feriados personalizados através da variável de ambiente `PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON`. **Estes feriados têm prioridade máxima** sobre todos os outros.

```env
# .env (no seu projeto)
PERSONAL_LIST_OF_HOLLIDAYS_IN_JSON='{"nacionais":[{"nome":"Dia da Empresa","data":"2025-03-15","observacoes":"Aniversário da nossa empresa - feriado corporativo."}],"estaduais":{"SP":[{"nome":"Dia da Revolução Constitucionalista Personalizada","data":"2025-07-09","observacoes":"Nossa versão personalizada do feriado de SP."}]}}'
```

## ⏰ CRONJOB de Atualização Automática

### Sistema de Atualização de Feriados

O módulo inclui um sistema de CRONJOB para atualização automática de feriados nacionais e estaduais no start do projeto.

```typescript
import { 
  inicializar,
  inicializarCronJobFeriados, 
  executarAtualizacaoManual 
} from "@phdiniiz/comercialTime";

// ⚠️ IMPORTANTE: Inicializar primeiro com timezone
await inicializar("America/Sao_Paulo");

// Inicialização automática baseada no timezone configurado
inicializarCronJobFeriados();

// Atualização manual
await executarAtualizacaoManual();
```

## 🔒 Segurança

### Validações de Entrada

```typescript
import { InputValidator } from '@phdiniiz/comercialTime';

// Validação de horário
InputValidator.validateHorarioInput('14:30'); // ✅ true
InputValidator.validateHorarioInput('25:00'); // ❌ false
InputValidator.validateHorarioInput('08:00<script>'); // ❌ false (XSS bloqueado)
```

### Rate Limiting Avançado

```typescript
import { AdvancedRateLimiter } from '@phdiniiz/comercialTime';

const limiter = new AdvancedRateLimiter({
  maxRequests: 1000,        // 1000 requests por minuto
  windowMs: 60000,          // Janela de 1 minuto
  debounceMs: 100,          // 100ms de debounce
  throttleMs: 50,           // 50ms de throttle
  circuitBreakerThreshold: 5, // 5 falhas para abrir circuit breaker
  circuitBreakerTimeout: 30000 // 30 segundos de timeout
});

// Verificar se requisição é permitida
const result = limiter.isAllowed('user123');
if (result.allowed) {
  // Processar requisição
} else {
  console.log(`Bloqueado: ${result.reason}, retry em ${result.retryAfter}ms`);
}
```

## ⚡ Performance

### Cache Inteligente

```typescript
import { OptimizedHorarioComercialService } from '@phdiniiz/comercialTime';

const service = new OptimizedHorarioComercialService({
  ttl: 300000, // 5 minutos de cache
  maxSize: 1000 // Máximo 1000 entradas
});

// Primeira chamada: calcula e armazena no cache
const result1 = service.estaAberto('2024-01-08 14:30');

// Segunda chamada: retorna do cache (muito mais rápido)
const result2 = service.estaAberto('2024-01-08 14:30');
```

## 🧪 Testes

```bash
# Executar todos os testes
pnpm test

# Executar com cobertura
pnpm test -- --coverage

# Executar testes em modo watch
pnpm test -- --watch
```

### Cobertura de Testes

- **Branches**: 80%
- **Functions**: 80%
- **Lines**: 80%
- **Statements**: 80%

## 📚 API Completa

### HorarioComercial

```typescript
class HorarioComercial {
  constructor(horario: Record<DiaChave, Intervalo[]>)
  
  // Verificações
  estaAberto(data?: Date | string): boolean
  proximaAbertura(data?: Date | string): Date | null
  proximoFechamento(data?: Date | string): Date | null
  minutosRestantesHoje(data?: Date | string): number
  
  // ✨ NOVO: Status atual baseado no timezone
  get openedNow(): boolean
  
  // ✨ NOVO: Configuração de timezone (Method Chaining)
  setTimezone(timezone: string): this
  getTimezone(): string
  
  // Operações
  adicionarMinutosUteis(data: Date | string, minutos: number): Date
  obterHorario(): Record<string, readonly Intervalo[]>
  
  // Feriados
  obterFeriados(): readonly Feriado[]
  obterDatasFeriados(): readonly string[]
  obterFeriadoPorData(data: Date | string): Feriado | undefined
  obterFeriadosFuturos(): readonly Feriado[]
  obterFeriadosPassados(): readonly Feriado[]
}
```

## 🌍 Configuração de Timezone

### Configurar Timezone por Instância

```typescript
import { HorarioComercial, setTimezone, getCurrentTimezone } from '@phdiniiz/comercialTime';

// ✨ NOVO: Method chaining na instância (Recomendado)
const horarioBrasil = new HorarioComercial({
  segunda: { abertura: '08:00', fechamento: '18:00' }
})
.setTimezone('America/Sao_Paulo'); // Brasil

const horarioEUA = new HorarioComercial({
  segunda: { abertura: '09:00', fechamento: '17:00' }
})
.setTimezone('America/New_York'); // EUA

// Cada instância mantém seu próprio timezone
console.log(horarioBrasil.getTimezone()); // 'America/Sao_Paulo'
console.log(horarioEUA.getTimezone()); // 'America/New_York'
```

### Configuração via Arquivo .env

```bash
# .env
TIMEZONE=America/Sao_Paulo
```

```typescript
import { HorarioComercial } from '@phdiniiz/comercialTime';

// Carrega automaticamente o timezone do .env
const horario = new HorarioComercial({
  segunda: { abertura: '08:00', fechamento: '18:00' }
}).setTimezone(); // Sem parâmetro = usa TIMEZONE do .env

console.log(horario.getTimezone()); // 'America/Sao_Paulo' (do .env)
```

## 📋 Requisitos

- **Node.js**: >= 22.0.0
- **TypeScript**: >= 5.7.2
- **Suporte a ESM**: Obrigatório

## 🌍 Compatibilidade

### Sistemas Operacionais

- ✅ Windows 10/11
- ✅ macOS 10.15+
- ✅ Linux (Ubuntu 18.04+)

### Ambientes

- ✅ Node.js (ESM)
- ✅ Deno
- ✅ Bun
- ✅ Browsers modernos (com bundler)

### Frameworks

- ✅ Next.js 15+
- ✅ NestJS
- ✅ Express.js
- ✅ Fastify

## 📖 Exemplos

### Exemplo Completo

```typescript
import { 
  HorarioComercial, 
  inicializarRapido,
  obterInfoTimezone
} from '@phdiniiz/comercialTime';

// ✨ NOVO: Inicializar o módulo com timezone obrigatório
console.log('🚀 Inicializando módulo...');
const resultadoInicializacao = await inicializarRapido('America/Sao_Paulo');
console.log('✅ Módulo inicializado:', resultadoInicializacao.sucesso);

// ✨ NOVO: Obter informações do timezone
const infoTimezone = obterInfoTimezone();
console.log('🌍 Informações do timezone:', infoTimezone);

// ✨ NOVO: Configurar horário comercial com timezone (Method Chaining)
const horario = new HorarioComercial({
  segunda: { abertura: '08:00', fechamento: '18:00' },
  terca: { abertura: '08:00', fechamento: '18:00' },
  quarta: { abertura: '08:00', fechamento: '18:00' },
  quinta: { abertura: '08:00', fechamento: '18:00' },
  sexta: { abertura: '08:00', fechamento: '18:00' },
  sabado: { abertura: '09:00', fechamento: '13:00' }
})
.setTimezone('America/Sao_Paulo'); // ✨ NOVO: Method chaining

console.log('Timezone atual:', horario.getTimezone()); // ✨ NOVO
console.log('Status atual (openedNow):', horario.openedNow); // ✨ NOVO

// Verificar status detalhado
const status = {
  estaAberto: horario.estaAberto(),
  openedNow: horario.openedNow, // ✨ NOVO
  proximaAbertura: horario.proximaAbertura(),
  proximoFechamento: horario.proximoFechamento(),
  minutosRestantes: horario.minutosRestantesHoje()
};

console.log('Status completo:', status);

// Adicionar 2 horas úteis
const agora = new Date();
const em2Horas = horario.adicionarMinutosUteis(agora, 120);
console.log('Em 2 horas úteis:', em2Horas);

// Trabalhar com feriados
const feriados = horario.obterFeriados();
console.log('Total de feriados:', feriados.length);

const feriadosFuturos = horario.obterFeriadosFuturos();
console.log('Feriados futuros:', feriadosFuturos.length);

// Verificar se uma data específica é feriado
const feriado = horario.obterFeriadoPorData('2025-01-01');
if (feriado) {
  console.log(`Feriado: ${feriado.nome} - ${feriado.observacoes}`);
}
```

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

### Padrões de Código

- **Clean Code**: Código limpo e legível
- **Clean Architecture**: Separação de responsabilidades
- **TDD**: Testes antes da implementação
- **TypeScript**: Tipagem forte
- **ESLint**: Linting automático
- **Prettier**: Formatação consistente

## 📄 Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 👨‍💻 Autor

**@phdiniiz/comercialTime**

- GitHub: [@PHDiniiz](https://github.com/PHDiniiz)
- NPM: [@phdiniiz/comercialTime](https://www.npmjs.com/package/@phdiniiz/comercialTime)

## 🙏 Agradecimentos

- Comunidade TypeScript
- Equipe do Node.js
- Contribuidores do projeto

## 📊 Estatísticas

![GitHub stars](https://img.shields.io/github/stars/phdiniiz/comercialHours?style=social)
![GitHub forks](https://img.shields.io/github/forks/phdiniz/comercialHours?style=social)
![GitHub issues](https://img.shields.io/github/issues/phdiniz/comercialHours)
![GitHub pull requests](https://img.shields.io/github/issues-pr/phdiniz/comercialHours)

---

**⭐ Se este projeto foi útil para você, considere dar uma estrela!**
